# SMS Preferences Deployment File

terraform {
  required_version = ">= 0.12"
}

# Variables
variable "region" {
  default     = "us-west-2"
  description = "AWS Region"
}

variable "monthly_spend_limit" {
  default     = "100"
  description = "The max monthly spend"
}

variable "delivery_status_iam_role_arn" {
  default     = "example_role"
  description = "The IAM role for delivery status"
}

variable "delivery_status_success_sampling_rate" {
  default     = "50"
  description = "The percentage of successful SMS deliveries for which Amazon SNS will write logs in CloudWatch Logs"
}

variable "default_sender_id" {
  default     = "example_id"
  description = "A string, such as your business brand, that is displayed as the sender on the receiving device"
}

variable "default_sms_type" {
  default     = "Promotional"
  description = "The type of SMS message that you will send by default"
}

variable "usage_report_s3_bucket" {
  default     = "s3-usage-example-bucket"
  description = "The name of the Amazon S3 bucket to receive daily SMS usage reports from Amazon SNS"
}

# AWS Provider
provider "aws" {
  region = var.region
}

# S3 Backend
terraform {
  backend "s3" {
  }
}

module "example_preference" {
  source                                = "git@ghe.coxautoinc.com:cms-terraform/tf-sns.git//sms-preferences"
  monthly_spend_limit                   = var.monthly_spend_limit
  delivery_status_iam_role_arn          = var.delivery_status_iam_role_arn
  delivery_status_success_sampling_rate = var.delivery_status_success_sampling_rate
  default_sender_id                     = var.default_sender_id
  default_sms_type                      = var.default_sms_type
  usage_report_s3_bucket                = var.usage_report_s3_bucket
}
