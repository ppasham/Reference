# Platform Application Deployment File

terraform {
  required_version = ">= 0.12"
}

# Variables
variable "region" {
  default     = "us-west-2"
  description = "AWS Region"
}

variable "name" {
  default     = "example_platform"
  description = "The friendly name for the SNS platform application"
}

variable "platform" {
  default     = "APNS"
  description = "The platform that the app is registered with"
}

variable "platform_credential" {
  default     = "hidden_key"
  description = "Application Platform credential"
}

variable "platform_principal" {
  default     = "hidden_principal"
  description = "Application Platform principal"
}

# AWS Provider
provider "aws" {
  region = var.region
}

# S3 Backend
terraform {
  backend "s3" {
  }
}

module "example_plaform_application" {
  source                                   = "git@ghe.coxautoinc.com:cms-terraform/tf-sns.git//platform-application"
  name                                     = var.name
  platform                                 = var.platform
  platform_credential                      = var.platform_credential
  platform_principal                       = var.platform_principal
}
