# SNS Topic Terraform Deployment Script

terraform {
  required_version = ">= 0.12"
}

# Variables
variable "region" {
  default     = "us-west-2"
  description = "AWS Region"
}

variable "name" {
  default     = "example_topic"
  description = "The friendly name for the SNS topic"
}

variable "display_name" {
  default     = "example_topic"
  description = "The display name for the SNS topic"
}

variable "kms_master_key_id" {
  default     = "example_key"
  description = "The master key ID"
}

variable "delivery_policy" {
  default     = "example_delivery.json"
  description = "The SNS delivery policy"
}

variable "application_success_feedback_role_arn" {
  default     = "example_success_role"
  description = "The IAM role permitted to receive success feedback for this topic"
}

variable "application_failure_feedback_role_arn" {
  default     = "eample_faliure_role"
  description = "IAM role for failure feedback"
}

variable "application_success_feedback_sample_rate" {
  default     = "50"
  description = "Percentage of success to sample"
}

variable "protocol" {
  default     = "sqs"
  description = "The protocol to use"
}

variable "endpoint" {
  default      = "arn:aws:sqs:us-west-2:432981146916:example_queue"
}

variable "policy_file_name" {
  default     = "example_policy_file"
  description = "The name of the policy file"
}

variable "resource_arn" {
  default     = "arn:aws:iam::123456789012:sqs/example/example_queue"
  description = "The resource arn to include in the policy file"
}

# AWS Provider
provider "aws" {
  region = var.region
}

# S3 Backend
terraform {
  backend "s3" {
  }
}

module "example_topic" {
  source                                   = "git@ghe.coxautoinc.com:cms-terraform/tf-sns.git//topic"
  name                                     = var.name
  display_name                             = var.display_name
  kms_master_key_id                        = var.kms_master_key_id
  policy                                   = module.example_topic_policy.policy_id
  delivery_policy                          = var.delivery_policy
  application_success_feedback_role_arn    = var.application_success_feedback_role_arn
  application_failure_feedback_role_arn    = var.application_failure_feedback_role_arn
  application_success_feedback_sample_rate = var.application_success_feedback_sample_rate
}

module "example_topic_subscription" {
  source                                   = "git@ghe.coxautoinc.com:cms-terraform/tf-sns.git//topic-subscription"
  topic_arn                                = module.example_topic.arn
  protocol                                 = var.protocol
  endpoint                                 = var.endpoint
}

module "example_topic_policy" {
  source                                   = "git@ghe.coxautoinc.com:cms-terraform/tf-sns.git//topic-policy"
  topic_arn                                = module.example_topic.arn
  policy_file_name                         = var.policy_file_name
  resource_arn                             = var.resource_arn
}
