# tf-sns
AWS Simple Notification Service Terraform Module

## Simple Notification Service
Amazon Simple Notification Service (SNS) is a highly available, durable, secure, fully managed pub/sub messaging service that enables you to decouple microservices, distributed systems, and serverless applications. Amazon SNS provides topics for high-throughput, push-based, many-to-many messaging.

### Platform Application

```hcl
resource "aws_sns_platform_application" "sns_application" {
  name                             = var.name
  platform                         = var.platform
  platform_credential              = var.platform_credential
  platform_principal               = var.platform_principal
  event_delivery_failure_topic_arn = var.event_delivery_failure_topic_arn
  event_endpoint_created_topic_arn = var.event_endpoint_created_topic_arn
  event_endpoint_deleted_topic_arn = var.event_endpoint_deleted_topic_arn
  event_endpoint_updated_topic_arn = var.event_endpoint_updated_topic_arn
  failure_feedback_role_arn        = var.failure_feedback_role_arn
  success_feedback_role_arn        = var.success_feedback_role_arn
  success_feedback_sample_rate     = var.success_feedback_sample_rate
}
```
Conditions applied in this module have the following set:

Value                             | Type      | Value Type | Description
--------------------------------- | --------  | ---------- | -----------
`name`                            | Required  | string     | The friendly name for the SNS platform application
`platform`                           | Required  | string     | The platform that the app is registered with
`platform_credential`                 | Required  | string     | Application Platform credential
`platform_principal`                     | Optional  | string     | Application Platform principal
`event_delivery_failure_topic_arn`                           | Optional  | string     | SNS Topic triggered when a delivery to any of the platform endpoints associated with your platform application encounters a permanent failure
`event_endpoint_created_topic_arn`                           | Optional  | string     | SNS Topic triggered when a new platform endpoint is added to your platform application
`event_endpoint_deleted_topic_arn`                           | Optional  | string     | SNS Topic triggered when an existing platform endpoint is deleted from your platform application
`event_endpoint_updated_topic_arn`                           | Optional  | string     | SNS Topic triggered when an existing platform endpoint is changed from your platform application
`failure_feedback_role_arn`                           | Optional  | string     | The IAM role permitted to receive failure feedback for this application
`success_feedback_role_arn`                           | Optional  | string     | The IAM role permitted to receive success feedback for this application
`success_feedback_sample_rate`                           | Optional  | string     | The percentage of success to sample (0-100)

### SMS Preferences

```hcl
resource "aws_sns_sms_preferences" "sms_preferences" {
  monthly_spend_limit                   = var.monthly_spend_limit
  delivery_status_iam_role_arn          = var.delivery_status_iam_role_arn
  delivery_status_success_sampling_rate = var.delivery_status_success_sampling_rate
  default_sender_id                     = var.default_sender_id
  default_sms_type                      = var.default_sms_type
  usage_report_s3_bucket                = var.usage_report_s3_bucket
}
```

Conditions applied in this module have the following set:

Value                             | Type      | Value Type | Description
--------------------------------- | --------  | ---------- | -----------
`monthly_spend_limit`                           | Optional  | string     | The maximum amount in USD that you are willing to spend each month to send SMS messages.
`delivery_status_iam_role_arn`                           | Optional  | string     | The ARN of the IAM role that allows Amazon SNS to write logs about SMS deliveries in CloudWatch Logs
`delivery_status_success_sampling_rate`                           | Optional  | string     | The percentage of successful SMS deliveries for which Amazon SNS will write logs in CloudWatch Logs. The value must be between 0 and 100.
`default_sender_id`                           | Optional  | string     | A string, such as your business brand, that is displayed as the sender on the receiving device.
`default_sms_type`                           | Optional  | string     | The type of SMS message that you will send by default. Possible values are: Promotional, Transactional
`usage_report_s3_bucket`                           | Optional  | string     | The name of the Amazon S3 bucket to receive daily SMS usage reports from Amazon SNS.

### Topic

```hcl
resource "aws_sns_topic" "topic" {
  name                                     = var.name
  display_name                             = var.display_name
  kms_master_key_id                        = var.kms_master_key_id
  policy                                   = var.policy
  delivery_policy                          = var.delivery_policy
  application_success_feedback_role_arn    = var.application_success_feedback_role_arn
  application_failure_feedback_role_arn    = var.application_failure_feedback_role_arn
  application_success_feedback_sample_rate = var.application_success_feedback_sample_rate
  http_success_feedback_role_arn           = var.http_success_feedback_role_arn
  http_failure_feedback_role_arn           = var.http_failure_feedback_role_arn
  http_success_feedback_sample_rate        = var.http_success_feedback_sample_rate
  lambda_success_feedback_role_arn         = var.lambda_success_feedback_role_arn
  lambda_success_feedback_sample_rate      = var.lambda_success_feedback_sample_rate
  lambda_failure_feedback_role_arn         = var.lambda_failure_feedback_role_arn
  sqs_success_feedback_role_arn            = var.sqs_success_feedback_role_arn
  sqs_success_feedback_sample_rate         = var.sqs_success_feedback_sample_rate
  sqs_failure_feedback_role_arn            = var.sqs_failure_feedback_role_arn
  tags                                     = var.tags
}
```

Conditions applied in this module have the following set:

Value                             | Type      | Value Type | Description
--------------------------------- | --------  | ---------- | -----------
`name`                           | Optional  | string     | The friendly name for the SNS topic
`display_name`                           | Optional  | string     | The display name for the SNS topic
`policy`                           | Optional  | string     | The fully-formed AWS policy as JSON
`delivery_policy`                           | Optional  | string     | The SNS delivery policy
`application_success_feedback_role_arn`                           | Optional  | string     | The IAM role permitted to receive success feedback for this topic
`application_failure_feedback_role_arn`                           | Optional  | string     | IAM role for failure feedback
`application_success_feedback_sample_rate`                           | Optional  | string     | Percentage of success to sample
`http_success_feedback_role_arn`                           | Optional  | string     | The IAM role permitted to receive success feedback for this topic
`http_failure_feedback_role_arn`                           | Optional  | string     | IAM role for failure feedback
`http_success_feedback_sample_rate`                           | Optional  | string     | Percentage of success to sample
`lambda_success_feedback_role_arn`                           | Optional  | string     | The IAM role permitted to receive success feedback for this topic
`lambda_success_feedback_sample_rate`                           | Optional  | string     | Percentage of success to sample
`lambda_failure_feedback_role_arn`                           | Optional  | string     | IAM role for failure feedback
`sqs_success_feedback_role_arn`                           | Optional  | string     | The IAM role permitted to receive success feedback for this topic
`sqs_success_feedback_sample_rate`                           | Optional  | string     | Percentage of success to sample
`sqs_failure_feedback_role_arn`                           | Optional  | string     | IAM role for failure feedback
`tags`                           | Optional  | string     | Key-value map of resource tags


### Topic Policy

```hcl
resource "aws_sns_topic_policy" "policy" {
  arn    = var.topic_arn
  policy = templatefile ("./${var.policy_file_name}", {
    resource_arn = var.resource_arn
  })
}
```

Conditions applied in this module have the following set:

Value                             | Type      | Value Type | Description
--------------------------------- | --------  | ---------- | -----------
`arn`                             | Required  | string     | The ARN of the SNS topic
`policy_file_name`                | Required  | string     | The name of the policy file
`resource_arn`                    | Required  | string     | The resource arn for the policy file

### Topic Subscription

```hcl
resource "aws_sns_topic_subscription" "topic_subscription" {
  topic_arn                       = var.topic_arn
  protocol                        = var.protocol
  endpoint                        = var.endpoint
  endpoint_auto_confirms          = var.endpoint_auto_confirms
  confirmation_timeout_in_minutes = var.confirmation_timeout_in_minutes
  raw_message_delivery            = var.raw_message_delivery
  filter_policy                   = var.filter_policy
  delivery_policy                 = var.delivery_policy
}
```

Conditions applied in this module have the following set:

Value                             | Type      | Value Type | Description
--------------------------------- | --------  | ---------- | -----------
`topic_arn`                           | Optional  | string     | The ARN of the SNS topic to subscribe to
`protocol`                           | Optional  | string     | The protocol to use. The possible values for this are: sqs, sms, lambda, application
`endpoint`                           | Optional  | string     | The endpoint to send data to, the contents will vary with the protocol
`endpoint_auto_confirms`                           | Optional  | bool     | Boolean indicating whether the end point is capable of auto confirming subscription
`confirmation_timeout_in_minutes`                           | Optional  | integer   | Integer indicating number of minutes to wait in retying mode for fetching subscription arn before marking it as failure.
`raw_message_delivery`                           | Optional  | bool     | Boolean indicating whether or not to enable raw message delivery
`filter_policy`                           | Optional  | string     | JSON String with the filter policy that will be used in the subscription to filter messages seen by the target resource
`delivery_policy`                           | Optional  | string     | JSON String with the delivery policy (retries, backoff, etc.) that will be used in the subscription.
