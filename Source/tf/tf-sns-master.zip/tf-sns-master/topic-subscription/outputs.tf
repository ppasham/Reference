# Topic Subscription Output File

output "subscription_id" {
  value = aws_sns_topic_subscription.topic_subscription.id
}

output "subscription_arn" {
  value = aws_sns_topic_subscription.topic_subscription.arn
}

output "subscription_topic_arn" {
  value = aws_sns_topic_subscription.topic_subscription.topic_arn
}

output "subscription_endpoint" {
  value = aws_sns_topic_subscription.topic_subscription.endpoint
}
