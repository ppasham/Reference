# SNS Topic Subscription
#
############################################################################################
# Module maintainer: CMS Platform Engineering Services                                     #
# Contact: CMS-SuperSmashCrew@coxautoinc.com                                               #
#                                                                                          #
# Description: SNS Topic Subscription                                                      #
# README: https://ghe.coxautoinc.com/cms-terraform/tf-sns/blob/master/README.md            #
# ___________________                                                                      #
#                                                                                          #
#  Copyright 2019 Cox Automotive Incorporated                                              #
#  All Rights Reserved.                                                                    #
#                                                                                          #
############################################################################################

# Requirements
terraform {
  required_version = ">= 0.12"
}

# Variables
variable "topic_arn" {
  default = ""
}

variable "protocol" {
  default = ""
}

variable "endpoint" {
  default = ""
}

variable "endpoint_auto_confirms" {
  default = "false"
}

variable "confirmation_timeout_in_minutes" {
  default = "1"
}

variable "raw_message_delivery" {
  default = "false"
}

variable "filter_policy" {
  default = ""
}

variable "delivery_policy" {
  default = ""
}

resource "aws_sns_topic_subscription" "topic_subscription" {
  topic_arn                       = var.topic_arn
  protocol                        = var.protocol
  endpoint                        = var.endpoint
  endpoint_auto_confirms          = var.endpoint_auto_confirms
  confirmation_timeout_in_minutes = var.confirmation_timeout_in_minutes
  raw_message_delivery            = var.raw_message_delivery
  filter_policy                   = var.filter_policy
  delivery_policy                 = var.delivery_policy
}
