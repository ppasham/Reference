# SMS Platform Application
#
############################################################################################
# Module maintainer: CMS Platform Engineering Services                                     #
# Contact: CMS-SuperSmashCrew@coxautoinc.com                                               #
#                                                                                          #
# Description: SMS Platform Application                                                    #
# README: https://ghe.coxautoinc.com/cms-terraform/tf-sns/blob/master/README.md            #
# ___________________                                                                      #
#                                                                                          #
#  Copyright 2019 Cox Automotive Incorporated                                              #
#  All Rights Reserved.                                                                    #
#                                                                                          #
############################################################################################

# Requirements
terraform {
  required_version = ">= 0.12"
}

# Variables
variable "name" {
  default = ""
}

variable "platform" {
  default = ""
}

variable "platform_credential" {
  default = ""
}

variable "platform_principal" {
  default = ""
}

variable "event_delivery_failure_topic_arn" {
  default = ""
}

variable "event_endpoint_created_topic_arn" {
  default = ""
}

variable "event_endpoint_deleted_topic_arn" {
  default = ""
}

variable "event_endpoint_updated_topic_arn" {
  default = ""
}

variable "failure_feedback_role_arn" {
  default = ""
}

variable "success_feedback_role_arn" {
  default = ""
}

variable "success_feedback_sample_rate" {
  default = ""
}

resource "aws_sns_platform_application" "sns_application" {
  name                             = var.name
  platform                         = var.platform
  platform_credential              = var.platform_credential
  platform_principal               = var.platform_principal
  event_delivery_failure_topic_arn = var.event_delivery_failure_topic_arn
  event_endpoint_created_topic_arn = var.event_endpoint_created_topic_arn
  event_endpoint_deleted_topic_arn = var.event_endpoint_deleted_topic_arn
  event_endpoint_updated_topic_arn = var.event_endpoint_updated_topic_arn
  failure_feedback_role_arn        = var.failure_feedback_role_arn
  success_feedback_role_arn        = var.success_feedback_role_arn
  success_feedback_sample_rate     = var.success_feedback_sample_rate
}
