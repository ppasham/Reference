# Platform Application Outputs File

output "platform_id" {
  value = aws_sns_platform_application.sns_application.id
}

output "platform_arn" {
  value = aws_sns_platform_application.sns_application.arn
}
