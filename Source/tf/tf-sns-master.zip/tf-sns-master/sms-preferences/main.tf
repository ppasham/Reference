# SMS Preferences
#
############################################################################################
# Module maintainer: CMS Platform Engineering Services                                     #
# Contact: CMS-SuperSmashCrew@coxautoinc.com                                               #
#                                                                                          #
# Description: SMS Preferences                                                             #
# README: https://ghe.coxautoinc.com/cms-terraform/tf-sns/blob/master/README.md            #
# ___________________                                                                      #
#                                                                                          #
#  Copyright 2019 Cox Automotive Incorporated                                              #
#  All Rights Reserved.                                                                    #
#                                                                                          #
############################################################################################

# Requirements
terraform {
  required_version = ">= 0.12"
}

# Variables
variable "monthly_spend_limit" {
  default = ""
}

variable "delivery_status_iam_role_arn" {
  default = ""
}

variable "delivery_status_success_sampling_rate" {
  default = ""
}

variable "default_sender_id" {
  default = ""
}

variable "default_sms_type" {
  default = "Promotional"
}

variable "usage_report_s3_bucket" {
  default = ""
}

resource "aws_sns_sms_preferences" "sms_preferences" {
  monthly_spend_limit                   = var.monthly_spend_limit
  delivery_status_iam_role_arn          = var.delivery_status_iam_role_arn
  delivery_status_success_sampling_rate = var.delivery_status_success_sampling_rate
  default_sender_id                     = var.default_sender_id
  default_sms_type                      = var.default_sms_type
  usage_report_s3_bucket                = var.usage_report_s3_bucket
}
