# Sms Preferences Output File

output "topic_id" {
  value = aws_sns_sms_preferences.sms_preferences.arn
}
