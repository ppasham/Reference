# SNS Topic
#
############################################################################################
# Module maintainer: CMS Platform Engineering Services                                     #
# Contact: CMS-SuperSmashCrew@coxautoinc.com                                               #
#                                                                                          #
# Description: SNS Topic                                                                   #
# README: https://ghe.coxautoinc.com/cms-terraform/tf-sns/blob/master/README.md            #
# ___________________                                                                      #
#                                                                                          #
#  Copyright 2019 Cox Automotive Incorporated                                              #
#  All Rights Reserved.                                                                    #
#                                                                                          #
############################################################################################

# Requirements
terraform {
  required_version = ">= 0.12"
}

# Variables
variable "name" {
  default = ""
}

variable "display_name" {
  default = ""
}

variable "kms_master_key_id" {
  default = ""
}

variable "policy" {
  default = ""
}

variable "delivery_policy" {
  default = ""
}

variable "application_success_feedback_role_arn" {
  default = ""
}

variable "application_failure_feedback_role_arn" {
  default = ""
}

variable "application_success_feedback_sample_rate" {
  default = "0"
}

variable "http_success_feedback_role_arn" {
  default = ""
}

variable "http_failure_feedback_role_arn" {
  default = ""
}

variable "http_success_feedback_sample_rate" {
  default = "0"
}

variable "lambda_success_feedback_role_arn" {
  default = ""
}

variable "lambda_success_feedback_sample_rate" {
  default = "0"
}

variable "lambda_failure_feedback_role_arn" {
  default = ""
}

variable "sqs_success_feedback_role_arn" {
  default = ""
}

variable "sqs_success_feedback_sample_rate" {
  default = "0"
}

variable "sqs_failure_feedback_role_arn" {
  default = ""
}

variable "tags" {
  type        = map(string)
  default     = {}
}

resource "aws_sns_topic" "topic" {
  name                                     = var.name
  display_name                             = var.display_name
  kms_master_key_id                        = var.kms_master_key_id
  policy                                   = var.policy
  delivery_policy                          = var.delivery_policy
  application_success_feedback_role_arn    = var.application_success_feedback_role_arn
  application_failure_feedback_role_arn    = var.application_failure_feedback_role_arn
  application_success_feedback_sample_rate = var.application_success_feedback_sample_rate
  http_success_feedback_role_arn           = var.http_success_feedback_role_arn
  http_failure_feedback_role_arn           = var.http_failure_feedback_role_arn
  http_success_feedback_sample_rate        = var.http_success_feedback_sample_rate
  lambda_success_feedback_role_arn         = var.lambda_success_feedback_role_arn
  lambda_success_feedback_sample_rate      = var.lambda_success_feedback_sample_rate
  lambda_failure_feedback_role_arn         = var.lambda_failure_feedback_role_arn
  sqs_success_feedback_role_arn            = var.sqs_success_feedback_role_arn
  sqs_success_feedback_sample_rate         = var.sqs_success_feedback_sample_rate
  sqs_failure_feedback_role_arn            = var.sqs_failure_feedback_role_arn
  tags                                     = var.tags
}
