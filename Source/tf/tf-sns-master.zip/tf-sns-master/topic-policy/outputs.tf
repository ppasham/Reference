# Topic Policy Output File

output "policy_arn" {
  value = aws_sns_topic_policy.policy.arn
}
