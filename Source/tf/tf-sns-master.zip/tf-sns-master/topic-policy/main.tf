# SNS Topic Policy
#
############################################################################################
# Module maintainer: CMS Platform Engineering Services                                     #
# Contact: CMS-SuperSmashCrew@coxautoinc.com                                               #
#                                                                                          #
# Description: SNS Topic Policy                                                            #
# README: https://ghe.coxautoinc.com/cms-terraform/tf-sns/blob/master/README.md            #
# ___________________                                                                      #
#                                                                                          #
#  Copyright 2019 Cox Automotive Incorporated                                              #
#  All Rights Reserved.                                                                    #
#                                                                                          #
############################################################################################

# Requirements
terraform {
  required_version = ">= 0.12"
}

# Variables
variable "topic_arn" {
  default = ""
}

variable "policy_file_name" {
  default = ""
}

variable "resource_arn" {
  default = ""
}

resource "aws_sns_topic_policy" "policy" {
  arn    = var.topic_arn
  policy = templatefile ("./${var.policy_file_name}", {
    resource_arn = var.resource_arn
  })
}
