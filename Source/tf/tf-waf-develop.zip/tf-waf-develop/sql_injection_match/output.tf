# WAF SQL Injection Match Outputs
output "sql_injection_match_set_id" {
  value = aws_waf_sql_injection_match_set.sql_injection_match_set.id
}