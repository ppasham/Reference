# Terraform WAF Geo Match Instance Module
#
##########################################################################################
# Module maintainer: CMS Platform Engineering Services                                   #
# Contact: CMS-SuperSmashCrew@coxautoinc.com                                             #
#                                                                                        #
# Description: WAF Creation                                                              #
# README: https://ghe.coxautoinc.com/cms-terraform/tf-waf/blob/master/README.md          #
# ___________________                                                                    #
#                                                                                        #
#  Copyright 2019 Cox Automotive Incorporated                                            #
#  All Rights Reserved.                                                                  #
#                                                                                        #
##########################################################################################

terraform {
  required_version = ">= 0.12"
}

# Variables
variable "name" {
  default = ""
}

variable "geo_matches" {
  type = list(object({
    type = string
    value = string
  }))
}

# Resources
resource "aws_waf_geo_match_set" "geo_match_set" {
  name = var.name

  dynamic "geo_match_constraint" {
    for_each = var.geo_matches
    content {
      type = geo_match_constraint.value["type"]
      value = geo_match_constraint.value["value"]
    }
  }
}