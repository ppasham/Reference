# WAF Geo Match Output
output "geo_match_set_id" {
  value = aws_waf_geo_match_set.geo_match_set.id
}