# Terraform WAF Web ACL Instance Module
#
##########################################################################################
# Module maintainer: CMS Platform Engineering Services                                   #
# Contact: CMS-SuperSmashCrew@coxautoinc.com                                             #
#                                                                                        #
# Description: WAF Creation                                                              #
# README: https://ghe.coxautoinc.com/cms-terraform/tf-waf/blob/master/README.md          #
# ___________________                                                                    #
#                                                                                        #
#  Copyright 2019 Cox Automotive Incorporated                                            #
#  All Rights Reserved.                                                                  #
#                                                                                        #
##########################################################################################

terraform {
  required_version = ">= 0.12"
}

# Variables
variable "name" {
  default = ""
}

variable "metric_name" {
  default = ""
}

variable "default_action" {
  default = ""
}

variable "rules" {
  type = list(object({
    action = object({
      type = string
    })

    priority = number
    rule_id = string
    type = string
  }))
}

# Resources
resource "aws_waf_web_acl" "web_acl" {
  name = var.name
  metric_name = var.metric_name
  default_action {
    type = var.default_action
  }

  dynamic "rules" {
    for_each = var.rules
    content {
      action {
        type = rules.value["action"]["type"]
      }
      priority = rules.value["priority"]
      rule_id = rules.value["rule_id"]
      type = rules.value["type"]
    }
  }
}