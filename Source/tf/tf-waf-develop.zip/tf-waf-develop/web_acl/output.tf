# WAF Web ACL Outputs
output "web_acl_id" {
  value = aws_waf_web_acl.web_acl.id
}

output "web_acl_arn" {
  value = aws_waf_web_acl.web_acl.arn
}