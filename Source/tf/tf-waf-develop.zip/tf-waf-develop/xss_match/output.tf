# WAF XSS Match Set Output
output "xss_match_set_id" {
  value = aws_waf_xss_match_set.xss_match_set.id
}