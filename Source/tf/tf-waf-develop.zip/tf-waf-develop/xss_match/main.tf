# Terraform WAF XSS Match Set Instance Module
#
##########################################################################################
# Module maintainer: CMS Platform Engineering Services                                   #
# Contact: CMS-SuperSmashCrew@coxautoinc.com                                             #
#                                                                                        #
# Description: WAF Creation                                                              #
# README: https://ghe.coxautoinc.com/cms-terraform/tf-waf/blob/master/README.md          #
# ___________________                                                                    #
#                                                                                        #
#  Copyright 2019 Cox Automotive Incorporated                                            #
#  All Rights Reserved.                                                                  #
#                                                                                        #
##########################################################################################

terraform {
  required_version = ">= 0.12"
}

# Variables
variable "name" {
  default = ""
}

variable "match_tuples" {
  type = list(object({
    text_transform = string
    field_match = object({
      type = string
      data = string
    })
  }))
}

# Resources
resource "aws_waf_xss_match_set" "xss_match_set" {
  name = var.name

  dynamic "xss_match_tuples" {
    for_each = var.match_tuples
    content {
      text_transformation = xss_match_tuples.value["text_transform"]
      field_to_match {
        type = xss_match_tuples.value["field_match"]["type"]
        data = xss_match_tuples.value["field_match"]["data"] == "" ? null : xss_match_tuples.value["field_match"]["data"]
      }
    }
  }
}