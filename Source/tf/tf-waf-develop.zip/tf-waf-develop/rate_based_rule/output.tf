# WAF Rate Based Rule Output
output "rate_based_rule" {
  value = aws_waf_rate_based_rule.rate_based_rule.id
}