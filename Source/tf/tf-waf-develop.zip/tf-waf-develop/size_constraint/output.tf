# WAF Size Constraint Outputs
output "size_contraint_id" {
  value = aws_waf_size_constraint_set.size_constraint_set.id
}