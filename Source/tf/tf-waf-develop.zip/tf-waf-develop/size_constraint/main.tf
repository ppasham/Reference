# Terraform WAF Size Constraint Instance Module
#
##########################################################################################
# Module maintainer: CMS Platform Engineering Services                                   #
# Contact: CMS-SuperSmashCrew@coxautoinc.com                                             #
#                                                                                        #
# Description: WAF Creation                                                              #
# README: https://ghe.coxautoinc.com/cms-terraform/tf-waf/blob/master/README.md          #
# ___________________                                                                    #
#                                                                                        #
#  Copyright 2019 Cox Automotive Incorporated                                            #
#  All Rights Reserved.                                                                  #
#                                                                                        #
##########################################################################################

terraform {
  required_version = ">= 0.12"
}

# Variables
variable "name" {
  default = ""
}

variable "size_constraints" {
  type = list(object({
    text_transform      = string
    comparison_operator = string
    size                = string
    field_match = object({
      type = string
      data = string
    })
  }))
}

# Resources
resource "aws_waf_size_constraint_set" "size_constraint_set" {
  name = var.name

  dynamic "size_constraints" {
    for_each = var.size_constraints
    content {
      text_transformation = size_constraints.value["text_transform"]
      comparison_operator = size_constraints.value["comparison_operator"]
      size = size_constraints.value["size"]
      field_to_match {
        type = size_constraints.value["field_match"]["type"]
        data = size_constraints.value["field_match"]["data"] == "" ? null : size_constraints.value["field_match"]["data"]
      }
    }
  }
}