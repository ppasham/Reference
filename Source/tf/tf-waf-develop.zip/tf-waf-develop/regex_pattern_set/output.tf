# WAF Regex Pattern Set Output
output "regex_pattern_set" {
  value = aws_waf_regex_pattern_set.regex_pattern_set.id
}