# WAF IPSet Output
output "ipset_id" {
  value = aws_waf_ipset.ipset.id
}

output "ipset_arn" {
  value = aws_waf_ipset.ipset.arn
}