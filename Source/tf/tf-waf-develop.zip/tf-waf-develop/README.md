# DEPRECATED. Use cms-terraform/tf-waf-v2 intead

# tf-waf

AWS WAF Terraform Module

## Description

Terraform module which creates an AWS WAF with associated ipsets, rules, acl's, etc.  

### NOTE
_There are two separate repositories for WAF and WAFRegional implemetation. You are currently viewing the WAF module repository. The WAFRegional repository can be found [here](https://ghe.coxautoinc.com/cms-terraform/tf-wafregional)._  

## Usage

### Byte Match Set

```hcl
resource "aws_waf_byte_match_set" "byte_match_set" {
  name = var.name

  dynamic "byte_match_tuples" {
    for_each = var.match_tuples
    content {
      text_transformation = byte_match_tuples.value["text_transform"]
      target_string = byte_match_tuples.value["target_string"]
      positional_constraint = byte_match_tuples.value["positional_constraint"]
      field_to_match {
        type = byte_match_tuples.value["field_match"]["type"]
        data = byte_match_tuples.value["field_match"]["data"] == "" ? null : byte_match_tuples.value["field_match"]["data"]
      }
    }
  }
}
```

Creates an AWS WAF ByteMatchSet that identifies a part of a web request that you want to inspect.

| Condition | Setting | Description |
|-----------|---------|-------------|
| name | Enabled | The name or description of the Byte Match Set. |
| byte_match_tuples | Enabled | Specifies the bytes (typically a string that corresponds with ASCII characters) that you want to search for in web requests, the location in requests that you want to search, and other settings. |

### Geo Match Set

```hcl
resource "aws_waf_geo_match_set" "geo_match_set" {
  name = var.name

  dynamic "geo_match_constraint" {
    for_each = var.geo_matches
    content {
      type = geo_match_constraint.value["type"]
      value = geo_match_constraint.value["value"]
    }
  }
}
```

Creates an GeoMatchSet , which you use to specify which web requests you want to allow or block based on the country that the requests originate from.

| Condition | Setting | Description |
|-----------|---------|-------------|
| name | Enabled | The name or description of the GeoMatchSet. |
| geo_match_constraint | Enabled | The GeoMatchConstraint objects which contain the country that you want AWS WAF to search for. |

### IPSet

```hcl
resource "aws_waf_ipset" "ipset" {
  name = var.name

  dynamic "ip_set_descriptors" {
    for_each = var.set_descriptors
    content {
      type = ip_set_descriptors.value["type"]
      value = ip_set_descriptors.value["value"]
    }
  }
}
```

Contains one or more IP addresses or blocks of IP addresses specified in Classless Inter-Domain Routing (CIDR) notation.

| Condition | Setting | Description |
|-----------|---------|-------------|
| name | Enabled | The name or description of the IPSet. |
| ip_set_descriptors | Enabled | One or more pairs specifying the IP address type (IPV4 or IPV6) and the IP address range (in CIDR format) from which web requests originate. |

### Rate Based Rule

```hcl
resource "aws_waf_rate_based_rule" "rate_based_rule" {
  metric_name = var.metric_name
  name = var.name
  rate_key = var.rate_key
  rate_limit = var.rate_limit

  dynamic "predicates" {
    for_each = var.predicates
    content {
      data_id = predicates.value["data_id"]
      negated = predicates.value["negated"]
      type = predicates.value["type"]
    }
  }
}
```

A rate-based rule tracks the rate of requests for each originating IP address, and triggers the rule action when the rate exceeds a limit that you specify on the number of requests in any 5-minute time span.

| Condition | Setting | Description |
|-----------|---------|-------------|
| name | Enabled | The name or description of the Rate Based Rule. |
| metric_name | Enabled | The name or description for the Amazon CloudWatch metric of this rule. |
| rate_key | Enabled | The IP to monitor. |
| rate_limit | Enabled | The maximum number of requests, which have an identical value in the field specified by the RateKey, allowed in a five-minute period. Minimum value is 100. |
| predicates | Enabled | The objects to include in a rule. |

### Regex Match Set

```hcl
resource "aws_waf_regex_match_set" "regex_match_set" {
  name = var.name

  dynamic "regex_match_tuple" {
    for_each = var.match_tuples
    content {
      regex_pattern_set_id = regex_match_tuple.value["regex_pattern_set_id"]
      text_transformation = regex_match_tuple.value["text_transform"]

      field_to_match {
        type = regex_match_tuple.value["field_match"]["type"]
        data = regex_match_tuple["field_match"]["data"] == "" ? null : regex_match_tuple["field_match"]["data"]
      }
    }
  }
}
```

Contains one or more regular expressions.

| Condition | Setting | Description |
|-----------|---------|-------------|
| name | Enabled | The name or description of the Regex Match Set. |
| regex_match_tuple | Enabled |  The regular expression pattern that you want AWS WAF to search for in web requests, the location in requests that you want AWS WAF to search, and other settings. |

### Regex Pattern Set

```hcl
resource "aws_waf_regex_pattern_set" "regex_pattern_set" {
  name = var.name
  regex_pattern_strings = var.pattern_strings
}
```

Contains one or more regular expressions.

| Condition | Setting | Description |
|-----------|---------|-------------|
| name | Enabled | The name or description of the Regex Pattern Set. |
| regex_pattern_strings | Enabled | A list of regular expression (regex) patterns that you want AWS WAF to search for. |

### Rule

```hcl
resource "aws_waf_rule" "rule" {
  name = var.name
  metric_name = var.metric_name

  dynamic "predicates" {
    for_each = var.predicates
    content {
      data_id = predicates.value["data_id"]
      negated = predicates.value["negated"]
      type = predicates.value["type"]
    }
  }
}
```

A single rule, which you can use in a WebACL or RuleGroup to identify web requests that you want to allow, block, or count.

| Condition | Setting | Description |
|-----------|---------|-------------|
| name | Enabled | The name or description of the rule. |
| metric_name | Enabled | The name or description for the Amazon CloudWatch metric of this rule. |
| predicates | Enabled | The objects to include in a rule. |

### Size Constraint Set

```hcl
resource "aws_waf_size_constraint_set" "size_constraint_set" {
  name = var.name

  dynamic "size_constraints" {
    for_each = var.size_constraints
    content {
      text_transformation = size_constraints.value["text_transform"]
      comparison_operator = size_constraints.value["comparison_operator"]
      size = size_constraints.value["size"]
      field_to_match {
        type = size_constraints.value["field_match"]["type"]
        data = size_constraints.value["field_match"]["data"] == "" ? null : size_constraints.value["field_match"]["data"]
      }
    }
  }
}
```

A rule statement that compares a number of bytes against the size of a request component, using a comparison operator, such as greater than (>) or less than (<).

| Condition | Setting | Description |
|-----------|---------|-------------|
| name | Enabled | The name or description of the Size Constraint Set. |
| size_constraints | Enabled | Specifies the parts of web requests that you want to inspect the size of. |

### SQL Injection Match Set

```hcl
resource "aws_waf_sql_injection_match_set" "sql_injection_match_set" {
  name = var.name

  dynamic "sql_injection_match_tuples" {
    for_each = var.match_tuples
    content {
      text_transformation = sql_injection_match_tuples.value["text_transform"]
      field_to_match {
        type = sql_injection_match_tuples.value["field_match"]["type"]
        data = sql_injection_match_tuples.value["field_match"]["data"] == "" ? null : sql_injection_match_tuples.value["field_match"]["data"]
      }
    }
  }
}
```

A SQL injection match condition identifies the part of web requests, such as the URI or the query string, that you want AWS WAF to inspect.

| Condition | Setting | Description |
|-----------|---------|-------------|
| name | Enabled | The name or description of the SQL Injection Match Set. |
| sql_injection_match_tuples | Enabled | The parts of web requests that you want AWS WAF to inspect for malicious SQL code and, if you want AWS WAF to inspect a header, the name of the header. |

### Web ACL

```hcl
resource "aws_waf_web_acl" "web_acl" {
  name = var.name
  metric_name = var.metric_name
  default_action {
    type = var.default_action
  }

  dynamic "rules" {
    for_each = var.rules
    content {
      action {
        type = rules.value["action"]["type"]
      }
      priority = rules.value["priority"]
      rule_id = rules.value["rule_id"]
      type = rules.value["type"]
    }
  }
}
```

A Web ACL defines a collection of rules to use to inspect and control web requests.

| Condition | Setting | Description |
|-----------|---------|-------------|
| name | Enabled | The name or description of the web ACL. |
| metric_name | Enabled | The name or description for the Amazon CloudWatch metric of this web ACL. |
| rules | Enabled | Configuration blocks containing rules to associate with the web ACL and the settings for each rule. Detailed below. |

### XSS Match Set

```hcl
resource "aws_waf_xss_match_set" "xss_match_set" {
  name = var.name

  dynamic "xss_match_tuples" {
    for_each = var.match_tuples
    content {
      text_transformation = xss_match_tuples.value["text_transform"]
      field_to_match {
        type = xss_match_tuples.value["field_match"]["type"]
        data = xss_match_tuples.value["field_match"]["data"] == "" ? null : xss_match_tuples.value["field_match"]["data"]
      }
    }
  }
}
```

A rule statement that defines a cross-site scripting (XSS) match search for AWS WAF to apply to web requests.

| Condition | Setting | Description |
|-----------|---------|-------------|
| name | Enabled | The name or description of the XSS Match Set. |
| xss_match_tuples | Enabled | The parts of web requests that you want to inspect for cross-site scripting attacks. |
