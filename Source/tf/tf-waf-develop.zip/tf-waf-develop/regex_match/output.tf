# WAF Regex Match Set Output
output "regex_match_set" {
  value = aws_waf_regex_match_set.regex_match_set.id
}