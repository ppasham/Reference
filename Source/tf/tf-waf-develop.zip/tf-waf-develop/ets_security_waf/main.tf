# Terraform WAF Instance Module
#
##########################################################################################
# Module maintainer: CMS Platform Engineering Services                                   #
# Contact: CMS-SuperSmashCrew@coxautoinc.com                                             #
#                                                                                        #
# Description: WAF Creation                                                              #
# README: https://ghe.coxautoinc.com/cms-terraform/tf-waf/blob/master/README.md          #
# ___________________                                                                    #
#                                                                                        #
#  Copyright 2019 Cox Automotive Incorporated                                            #
#  All Rights Reserved.                                                                  #
#                                                                                        #
##########################################################################################

terraform {
  required_version = ">= 0.12"
}

# Variables
variable "region" {
  default = "us-west-2"
}

variable "waf_prefix" {
  default = ""
}

variable "admin_remote_ipset_range" {
  default = ""
}

variable "blacklisted_ipset_range" {
  default = ""
}

# Modules
module "generic_size_constraints" {
  source = "git@ghe.coxautoinc.com:cms-terraform/tf-waf.git//size_constraint"
  name = "${var.waf_prefix}-generic-size-constraints"
  size_constraints = [
    {
      text_transform = "NONE"
      comparison_operator = "GT"
      size                = "4096"

      field_match = {
        type = "BODY"
        data = null
      }
    },
    {
      text_transform = "NONE"
      comparison_operator = "GT"
      size                = "4093"

      field_match = {
        type = "HEADER"
        data = "cookie"
      }
    },
    {
      text_transform = "NONE"
      comparison_operator = "GT"
      size                = "1024"

      field_match = {
        type = "QUERY_STRING"
        data = null
      }
    },
    {
      text_transform = "NONE"
      comparison_operator = "GT"
      size                = "512"

      field_match = {
        type = "URI"
        data = null
      }
    }
  ]
}

module "csrf_size_constraints" {
  source = "git@ghe.coxautoinc.com:cms-terraform/tf-waf.git//size_constraint"
  name = "${var.waf_prefix}-generic-size-constraints"
  size_constraints = [
    {
      text_transform = "NONE"
      comparison_operator = "EQ"
      size                = "36"

      field_match = {
        type = "HEADER"
        data = "x-csrf-token"
      }
    }
  ]
}

module "admin_remote_ipset" {
  source = "git@ghe.coxautoinc.com:cms-terraform/tf-waf.git//ipset"

  name = "${var.waf_prefix}-generic-match-admin-remote-ips"

  set_descriptors = [
    {
      type = "IPV4"
      value = var.admin_remote_ipset_range
    }
  ]
}

module "blacklisted_ipset" {
  source = "git@ghe.coxautoinc.com:cms-terraform/tf-waf.git//ipset"

  name = "${var.waf_prefix}-generic-blacklisted-ips"

  set_descriptors = [
    {
      type = "IPV4"
      value = var.blacklisted_ipset_range
    }
  ]
}

module "sql_injection_match_set" {
  source = "git@ghe.coxautoinc.com:cms-terraform/tf-waf.git//sql_injection_match"

  name = "${var.waf_prefix}-generic-detect-sqli"

  match_tuples = [
    {
      text_transform = "HTML_ENTITY_DECODE"

      field_match = {
        type = "BODY"
        data = null
      }
    },
    {
      text_transform = "URL_DECODE"

      field_match = {
        type = "BODY"
        data = null
      }
    },
    {
      text_transform = "HTML_ENTITY_DECODE"

      field_match = {
        type = "URI"
        data = null
      }
    },
    {
      text_transform = "URL_DECODE"

      field_match = {
        type = "URI"
        data = null
      }
    },
    {
      text_transform = "HTML_ENTITY_DECODE"

      field_match = {
        type = "QUERY_STRING"
        data = null
      }
    },
    {
      text_transform = "URL_DECODE"

      field_match = {
        type = "QUERY_STRING"
        data = null
      }
    },
    {
      text_transform = "HTML_ENTITY_DECODE"

      field_match = {
        type = "HEADER"
        data = "cookie"
      }
    },
    {
      text_transform = "URL_DECODE"

      field_match = {
        type = "HEADER"
        data = "cookie"
      }
    }
  ]
}

module "match_php_insecure_uri" {
  source = "git@ghe.coxautoinc.com:cms-terraform/tf-waf.git//byte_match"

  name = "${var.waf_prefix}-generic-match-php-insecure-uri"

  match_tuples = [
    {
      text_transform   = "URL_DECODE"
      target_string         = "php"
      positional_constraint = "ENDS_WITH"

      field_match = {
        type = "URI"
        data = null
      }
    },
    {
      text_transform   = "URL_DECODE"
      target_string         = "/"
      positional_constraint = "ENDS_WITH"

      field_match = {
      type = "URI"
      data = null
      }
    }
  ]
}

module "match_php_insecure_var_refs" {
  source = "git@ghe.coxautoinc.com:cms-terraform/tf-waf.git//byte_match"

  name = "${var.waf_prefix}-generic-match-php-insecure-var-refs"

  match_tuples = [
    {
      text_transform   = "URL_DECODE"
      target_string         = "_ENV["
      positional_constraint = "CONTAINS"

      field_match = {
        type = "QUERY_STRING"
        data = null
      }
    },
    {
      text_transform   = "URL_DECODE"
      target_string         = "auto_append_file="
      positional_constraint = "CONTAINS"

      field_match = {
        type = "QUERY_STRING"
        data = null
      }
    },
    {
      text_transform   = "URL_DECODE"
      target_string         = "disable_functions="
      positional_constraint = "CONTAINS"

      field_match = {
        type = "QUERY_STRING"
        data = null
      }
    },
    {
      text_transform   = "URL_DECODE"
      target_string         = "auto_prepend_file="
      positional_constraint = "CONTAINS"

      field_match = {
        type = "QUERY_STRING"
        data = null
      }
    },
    {
      text_transform   = "URL_DECODE"
      target_string         = "safe_mode="
      positional_constraint = "CONTAINS"

      field_match = {
        type = "QUERY_STRING"
        data = null
      }
    },
    {
      text_transform   = "URL_DECODE"
      target_string         = "_SERVER["
      positional_constraint = "CONTAINS"

      field_match = {
        type = "QUERY_STRING"
        data = null
      }
    },
    {
      text_transform   = "URL_DECODE"
      target_string         = "allow_url_include="
      positional_constraint = "CONTAINS"

      field_match = {
        type = "QUERY_STRING"
        data = null
      }
    },
    {
      text_transform   = "URL_DECODE"
      target_string         = "open_basedir="
      positional_constraint = "CONTAINS"

      field_match = {
        type = "QUERY_STRING"
        data = null
      }
    }
  ]
}

module "match_rfi_lfi_traversal" {
  source = "git@ghe.coxautoinc.com:cms-terraform/tf-waf.git//byte_match"

  name = "${var.waf_prefix}-generic-match-rfi-lfi-traversal"

  match_tuples = [
    {
      text_transform   = "HTML_ENTITY_DECODE"
      target_string         = "://"
      positional_constraint = "CONTAINS"

      field_match = {
        type = "QUERY_STRING"
        data = null
      }
    },
    {
      text_transform   = "HTML_ENTITY_DECODE"
      target_string         = "../"
      positional_constraint = "CONTAINS"

      field_match = {
        type = "QUERY_STRING"
        data = null
      }
    },
    {
      text_transform   = "URL_DECODE"
      target_string         = "://"
      positional_constraint = "CONTAINS"

      field_match = {
        type = "QUERY_STRING"
        data = null
      }
    },
    {
      text_transform   = "URL_DECODE"
      target_string         = "../"
      positional_constraint = "CONTAINS"

      field_match = {
        type = "QUERY_STRING"
        data = null
      }
    },
    {
      text_transform   = "HTML_ENTITY_DECODE"
      target_string         = "://"
      positional_constraint = "CONTAINS"

      field_match = {
        type = "URI"
        data = null
      }
    },
    {
      text_transform   = "HTML_ENTITY_DECODE"
      target_string         = "../"
      positional_constraint = "CONTAINS"

      field_match = {
        type = "URI"
        data = null
      }
    },
    {
      text_transform   = "URL_DECODE"
      target_string         = "://"
      positional_constraint = "CONTAINS"

      field_match = {
        type = "URI"
        data = null
      }
    },
    {
      text_transform   = "URL_DECODE"
      target_string         = "../"
      positional_constraint = "CONTAINS"

      field_match = {
        type = "URI"
        data = null
      }
    }
  ]
}

module "match_ssi" {
  source = "git@ghe.coxautoinc.com:cms-terraform/tf-waf.git//byte_match"

  name = "${var.waf_prefix}-generic-match-ssi"

  match_tuples = [
    {
      text_transform   = "LOWERCASE"
      target_string         = ".cfg"
      positional_constraint = "ENDS_WITH"

      field_match = {
        type = "URI"
        data = null
      }
    },
    {
      text_transform   = "LOWERCASE"
      target_string         = ".backup"
      positional_constraint = "ENDS_WITH"

      field_match = {
        type = "URI"
        data = null
      }
    },
    {
      text_transform   = "LOWERCASE"
      target_string         = ".ini"
      positional_constraint = "ENDS_WITH"

      field_match = {
        type = "URI"
        data = null
      }
    },
    {
      text_transform   = "LOWERCASE"
      target_string         = ".conf"
      positional_constraint = "ENDS_WITH"

      field_match = {
        type = "URI"
        data = null
      }
    },
    {
      text_transform   = "LOWERCASE"
      target_string         = ".log"
      positional_constraint = "ENDS_WITH"

      field_match = {
        type = "URI"
        data = null
      }
    },
    {
      text_transform   = "LOWERCASE"
      target_string         = ".bak"
      positional_constraint = "ENDS_WITH"

      field_match = {
        type = "URI"
        data = null
      }
    },
    {
      text_transform   = "LOWERCASE"
      target_string         = ".config"
      positional_constraint = "ENDS_WITH"

      field_match = {
        type = "URI"
        data = null
      }
    },
    {
      text_transform   = "URL_DECODE"
      target_string         = "/includes"
      positional_constraint = "STARTS_WITH"

      field_match = {
        type = "URI"
        data = null
      }
    }
  ]
}

module "xss_match_set" {
  source = "git@ghe.coxautoinc.com:cms-terraform/tf-waf.git//xss_match"

  name = "${var.waf_prefix}-generic-detect-xss"

  match_tuples = [
    {
      text_transform = "HTML_ENTITY_DECODE"

      field_match = {
        type = "BODY"
        data = null
      }
    },
    {
      text_transform = "URL_DECODE"

      field_match = {
        type = "BODY"
        data = null
      }
    },
    {
      text_transform = "HTML_ENTITY_DECODE"

      field_match = {
        type = "URI"
        data = null
      }
    },
    {
      text_transform = "URL_DECODE"

      field_match = {
        type = "URI"
        data = null
      }
    },
    {
      text_transform = "HTML_ENTITY_DECODE"

      field_match = {
        type = "QUERY_STRING"
        data = null
      }
    },
    {
      text_transform = "URL_DECODE"

      field_match = {
        type = "QUERY_STRING"
        data = null
      }
    },
    {
      text_transform = "HTML_ENTITY_DECODE"

      field_match = {
        type = "HEADER"
        data = "cookie"
      }
    },
    {
      text_transform = "URL_DECODE"

      field_match = {
        type = "HEADER"
        data = "cookie"
      }
    }
  ]
}