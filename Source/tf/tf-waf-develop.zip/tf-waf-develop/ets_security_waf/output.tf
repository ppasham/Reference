# WAF Output
output "generic_size_constraints_id" {
  value = module.generic_size_constraints.size_contraint_id
}

output "csrf_size_constraints_id" {
  value = module.csrf_size_constraints.size_contraint_id
}

output "admin_remote_ipset_arn" {
  value = module.admin_remote_ipset.ipset_arn
}

output "admin_remote_ipset_id" {
  value = module.admin_remote_ipset.ipset_id
}

output "blacklisted_ipset_arn" {
  value = module.blacklisted_ipset.ipset_arn
}

output "blacklisted_ipset_id" {
  value = module.blacklisted_ipset.ipset_id
}

output "sql_injection_match_set_id" {
  value = module.sql_injection_match_set.sql_injection_match_set_id
}

output "match_php_insecure_uri_id" {
  value = module.match_php_insecure_uri.byte_match_set_id
}

output "match_php_insecure_var_refs_id" {
  value = module.match_php_insecure_var_refs.byte_match_set_id
}

output "match_rfi_lfi_traversal_id" {
  value = module.match_rfi_lfi_traversal.byte_match_set_id
}

output "match_ssi_id" {
  value = module.match_ssi.byte_match_set_id
}

output "xss_match_set" {
  value = module.xss_match_set.xss_match_set_id
}