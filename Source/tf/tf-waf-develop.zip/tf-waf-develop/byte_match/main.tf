# Terraform WAF Byte Match Instance Module
#
##########################################################################################
# Module maintainer: CMS Platform Engineering Services                                   #
# Contact: CMS-SuperSmashCrew@coxautoinc.com                                             #
#                                                                                        #
# Description: WAF Creation                                                              #
# README: https://ghe.coxautoinc.com/cms-terraform/tf-waf/blob/master/README.md          #
# ___________________                                                                    #
#                                                                                        #
#  Copyright 2019 Cox Automotive Incorporated                                            #
#  All Rights Reserved.                                                                  #
#                                                                                        #
##########################################################################################

terraform {
  required_version = ">= 0.12"
}

# Variables
variable "name" {
  default = ""
}

variable "match_tuples" {
  type = list(object({
    text_transform = string
    target_string = string
    positional_constraint = string
    field_match = object({
      type = string
      data = string
    })
  }))
}

# Resources
resource "aws_waf_byte_match_set" "byte_match_set" {
  name = var.name

  dynamic "byte_match_tuples" {
    for_each = var.match_tuples
    content {
      text_transformation = byte_match_tuples.value["text_transform"]
      target_string = byte_match_tuples.value["target_string"]
      positional_constraint = byte_match_tuples.value["positional_constraint"]
      field_to_match {
        type = byte_match_tuples.value["field_match"]["type"]
        data = byte_match_tuples.value["field_match"]["data"] == "" ? null : byte_match_tuples.value["field_match"]["data"]
      }
    }
  }
}