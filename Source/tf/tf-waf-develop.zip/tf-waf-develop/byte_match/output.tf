# WAF Byte Match Output
output "byte_match_set_id" {
  value = aws_waf_byte_match_set.byte_match_set.id
}