# WAF Module

terraform {
  required_version = ">= 0.12"
}

# Variables
variable "region" {
  default = "us-west-2"
}


provider "aws" {
  region = var.region
}

provider "alks" {
  url = "https://alks.coxautoinc.com/rest"
}



variable "waf_prefix" {
  default = "test-waf"
}

variable "admin_remote_ipset_range" {
  default = "0.0.0.0/0"
}

variable "blacklisted_ipset_range" {
  default = "0.0.0.0/0"
}

variable "size_constraint_set_name_1" {
  default = "size_constraint_set_1"
}

variable "size_constraint_set_name_2" {
  default = "size_constraint_set_2"
}

variable "sql_injection_match_set_name_1" {
  default = "sql_injection_match_set_1"
}

variable "byte_match_set_name_1" {
  default = "byte_match_set_1"
}

variable "size_constraint_set_constraints_1" {
  default = [
    {
      text_transform = "NONE"
      comparison_operator = "GT"
      size = "4096"
      field_match = {
        type = "BODY"
        data = null
      }
    },
    {
      text_transform = "NONE"
      comparison_operator = "GT"
      size = "4093"
      field_match = {
        type = "HEADER"
        data = "cookie"
      }
    },
    {
      text_transform = "NONE"
      comparison_operator = "GT"
      size = "1024"
      field_match = {
        type = "QUERY_STRING"
        data = ""
      }
    }
  ]
}

variable "size_constraint_set_constraints_2" {
  default = [
    {
      text_transform = "NONE"
      comparison_operator = "GT"
      size = "4096"
      field_match = {
        type = "BODY"
        data = null
      }
    },
    {
      text_transform = "NONE"
      comparison_operator = "GT"
      size = "4093"
      field_match = {
        type = "HEADER"
        data = "cookie"
      }
    },
    {
      text_transform = "NONE"
      comparison_operator = "GT"
      size = "1024"
      field_match = {
        type = "QUERY_STRING"
        data = ""
      }
    }
  ]
}

variable "sql_injection_match_set_tuples_1" {
  default = [
    {
      text_transform = "HTML_ENTITY_DECODE"
      field_match = {
        type = "BODY"
        data = null
      }
    },
    {
      text_transform = "URL_DECODE"
      field_match = {
        type = "URI"
        data = null
      }
    },
    {
      text_transform = "URL_DECODE"
      field_match = {
        type = "HEADER"
        data = "cookie"
      }
    }
  ]
}

variable "byte_match_set_tuples_1" {
  default = [
    {
      text_transform = "URL_DECODE"
      target_string = "/admin"
      positional_constraint = "STARTS_WITH"
      field_match = {
        type = "URI"
        data = null
      }
    },
    {
      text_transform = "URL_DECODE"
      target_string = "example-session-id"
      positional_constraint = "CONTAINS"
      field_match = {
        type = "HEADER"
        data = "cookie"
      }
    }
  ]
}

# WAF Creation
module "ets_security_waf" {
  source = "git@ghe.coxautoinc.com:cms-terraform/tf-waf.git//ets_security_waf"
  waf_prefix = var.waf_prefix
  admin_remote_ipset_range = var.admin_remote_ipset_range
  blacklisted_ipset_range = var.blacklisted_ipset_range
}

module "size_constraint_1" {
  source = "git@ghe.coxautoinc.com:cms-terraform/tf-waf.git//size_constraint"
  name = var.size_constraint_set_name_1
  size_constraints = var.size_constraint_set_constraints_1
}

module "size_constraint_2" {
  source = "git@ghe.coxautoinc.com:cms-terraform/tf-waf.git//size_constraint"
  name = var.size_constraint_set_name_2
  size_constraints = var.size_constraint_set_constraints_2
}

module "sql_injection_match_set" {
  source = "git@ghe.coxautoinc.com:cms-terraform/tf-waf.git//sql_injection_match"
  name = var.sql_injection_match_set_name_1
  match_tuples = var.sql_injection_match_set_tuples_1
}

module "byte_match_set" {
  source = "git@ghe.coxautoinc.com:cms-terraform/tf-waf.git//byte_match"
  name = var.byte_match_set_name_1
  match_tuples = var.byte_match_set_tuples_1
}