# CMS Monitoring Terraform Module

This moudule contains a fully-configured monitoring module that leverages PagerDuty, New Relic and Splunk Terraform providers. 
The module will deploy the correct workflow depending on the environment variable that is specified:
* **Resources**
  * Non-Prod and Pre-Prod Alert Policies that tie into Dev Team Slack or Teams Channel
  * Non-Prod and Pre-Prod New Relic Synthetic Secure Credentials
  * New Relic Synthetics for all Environments
    * New Relic Synthetic Monitor Script
  * New Relic Application settings for all Environments
  * New Relic Workload for all Environments
  * New Relic Static and Baseline Query Alerts for all Environments
  * Splunk Alerting for all Environments that tie into Dev Team Slack or Teams Channel
* **Production Only Resources** (Only deployed when var.environment is specified as **prd**)
  * PagerDuty Resources
  * PagerDuty Service
  * PagerDuty Service Integrations
  * PagerDuty Service Extensions
  * PagerDuty Slack Connection (Production Alerts will forward from NewRelic/Splunk through PagerDuty to Orginization Slack Channel)
  * PagerDuty Service Event Rules
  * PagerDuty Team
  * PagerDuty Team Membership
  * PagerDuty Schedule (Primary, Secondary, Manager)
   * Secondary Schedule be backup to current week and will be next in line to be primary on call the following week
  * PagerDuty Escalation Polcies
  * PagerDuty Service Dependencies
  * New Relic Production Alert Policy that ties into the PagerDuty Service (uses email integration)
  * New Relic Muting Rule
  * New Relic Synthetic Secure Credential for Production
  * New Relic Service Level Resource

## Table of Contents

1) [Terraform Providers](#terraform-providers)<br>

2) [List Objects](#list-objects)<br>

3) [Validation and Standards](#validation-and-standards)<br>

4) [Variables and Definitions](#variables-and-definitions)<br>

5) [List Object Block References](#list-object-block-references)<br>

6) [PagerDuty Config](#pagerduty-config)<br>

7) [New Relic Synthetic Monitor Reference](#new-relic-synthetic-monitor-reference)

8) [Example](example/main.tf)<br>

9) [Production Workflow of an Incident](#production-workflow-of-an-incident)<br>

10) [NRQL Examples](#nrql-examples)<br>
 
## Features of Monitoring Module

### Terraform Providers (**REQUIRED**)

This module requries that all providers are present for Splunk, PagerDuty and Terraform:
* Splunk Provider
```tf
  provider "splunk" {
    url        = var.splunk_url
    auth_token = var.splunk_auth_token
  }
```
* New Relic Provider
```tf
  provider "newrelic" {
    api_key = var.newrelic_api_key
  }
```
* Github Provider
```tf
  provider "github" {
    token = var.github_token
    base_url = "https://ghe.coxautoinc.com/"
    owner = "CMS-PE" # Github Org
}
```
* PagerDuty Provider
  * **user_token** This token provides access to the PagerDuty Slack connection automation. 
    * In the web app, navigate to User Icon -> My Profile -> User Settings.
    * In the section API Access, click Create API User Token.
    * Enter a Description to help you identify the key later.
    * Click Create Key.
    * Then Token will need approved to create Slack Connection
    * In the web app, navigate to Integrations at the top -> Authorize Integration
    * Use SSO logon -> coxauto as subdomain

```tf
  provider "pagerduty" {
    token      = var.pagerduty_token
    user_token = var.user_token
  }
```

### List Objects

This module leverages list objects to create most resources. These list objects can be used multiple times to create a number of resources and each object is required:
 * ```tf
   variable "newrelic_synthetics" {
    type = list(object({
    function  = string
    type      = string
    frequency = string
    locations = list(string)
    }))
    default     = []
   }
   ```
 * Example of useage of list obejcts in deploy.tf file:
   ```tf
   locals{
    newrelic_synthetics = [
      {
        function  = "logon-external"
        type      = "SCRIPT_BROWSER"
        frequency = "5"
        locations = ["AWS_US_EAST_1", "AWS_US_WEST_1"]
      },
      {
        function  = "logon-internal"
        type      = "SCRIPT_API"
        frequency = "5"
        locations = ["AWS_US_EAST_1", "AWS_US_WEST_1"]
      }
     ]
    }
   ```

### Validation and Standards

This module includes validation blocks for certain variables to standardize naming and module use:
 * Environment 
   * var.environment must be one of qa, pp or prd
 * Workload 
   * var.workload is required and can only use the following: -, a-z, A-Z and 0-9
 * Component 
   * var.component is required and can only use the following: -, a-z, A-Z and 0-9
 * Coxauto CIID 
   * var.coxauto_ci_id is required and include a valid Catalog ID, starting with a capital CI
 * New Relic Muting Rule 
   * var.newrelic_muting_rule **function** object can only use the following: -, a-z, A-Z and 0-9
 * New Relic Static Query Alerts 
   * var.nrql_static_query_alerts **function** object can only use the following: -, a-z, A-Z and 0-9
 * New Relic Baseline Query Alerts 
   * var.nrql_baseline_query_alerts **function** object can only use the following: -, a-z, A-Z and 0-9
 * New Relic Secure Credentials for Prodcution 
   * var.newrelic_synthetics_secure_credentials_prd **key** object can only use the following: -, a-z, A-Z and 0-9
 * New Relic Secure Credentials for Non-Prod and Pre-Prod 
   * var.newrelic_synthetics_secure_credentials_np **key** object can only use the following: -, a-z, A-Z and 0-9
 * New Relic Synthetics 
   * var.synthetics **function** object can only use the following: -, a-z, A-Z and 0-9
 * New Relic Application Settings 
   * var.newrelic_application_settings **function** object can only use the following: -, a-z, A-Z and 0-9
 * New Relic Service Levels 
   * var.newrelic_service_levels **function** object can only use the following: -, a-z, A-Z and 0-9
 * Splunk Alerts 
   * var.splunk_alerts **name** object can only use the following: -, a-z, A-Z and 0-9

## Variables and Definitions

Value                             | Type     | Requirements | Value Type | Description
--------------------------------- | -------- | ---------- | ---------- | -----------
`environment`                           | Required | qa, pp, prd        | string     | The environment to deploy to.
`workload`                           | Required | variable can only use the following: -, a-z, A-Z and 0-9    | string    | The Workload to monitor.
`component_name`                           | Required | variable can only use the following: -, a-z, A-Z and 0-9      | string     | The name of the Componet to Monitor.
`application_sub_name`                           | Optional | variable can only use the following: -, a-z, A-Z and 0-9     | string   | Optional Identifer to add to naming
`team_slack_url`                           | Optional | n/a        | string     | Team specific Slack URL
`team_slack_channel`                           | Optional | n/a        | string     | Team specific Slack Channel
`team_teams_url`                           | Optional | n/a        | string     | Team specific Teams URL
`coxauto_ci_id`                           | Required | The Catalog ID must be included and a valid Catalog ID, starting with a capital CI        | string     | Coxauto Catalog ID
`script_location`                           | Optional | n/a        | list(any)    | The Script location to be applied to synthetics
`script_variables`                           | Optional | n/a        | any    | The Script Variables to be applied to synthetics
`create_workload`                           | Optional| n/a       | number     | Variable to specify if workload should be created (Workload Created by Default)
`engineer_on_call_users_id`                 | Required | n/a        | List (String)    | The list of user id's that need to be added to the primary on-call schedule
`manager_on_call_users_id`                 | Required | n/a        | List (String)    | The list of user id's that need to be added to the manager on-call schedule
`statuspage`                           | Optional| n/a       | number     | Variable to specify if StatusPage.io integration should be created (Integration *not* created by Default)
`incident_workspace_id`                           | Optional| n/a       | string     | Variable to specify the Incident Slack Channel workspace ID (Defualt is #CMS-Incidents)
`incident_channel_id`                           | Optional| n/a       | string     | Variable to specify the Incidents Slack Channel (Defualt is #CMS-Incidents)
`pagerduty_service_dependencies`              | Optional | n/a  | list(any)   | Include outside dependencies to be included in PagerDuty for the PagerDuty Service

## List Object Block References

* **NRQL Static Query Alerts** - Static Query alerts are static in nature and do not adjust to the behavior of your data.
  ```tf
  function                       = "" (eg. transaction-error, 500-error)
  description                    = ""
  runbook_url                    = ""
  value_function                 = ""
  fill_option                    = ""
  fill_value                     = ""
  aggregation_window             = ""
  aggregation_method             = ""
  aggregation_delay              = ""
  expiration_duration            = ""
  query                          = ""
  critical_operator              = ""
  critical_threshold             = ""
  critical_threshold_duration    = ""
  critical_threshold_occurrences = ""
  warning_operator               = ""
  warning_threshold              = ""
  warning_threshold_duration     = ""
  warning_threshold_occurrences  = ""
  ```

* **NRQL Baseline Query Alerts** - Baseline Alerts are dynamic in nature and adjust to the behavior of your data.
  ```tf
  function                       = "" (eg. transaction-error, 500-error)
  description                    = ""
  runbook_url                    = ""
  aggregation_method             = ""
  aggregation_delay              = ""
  baseline_direction             = ""
  query                          = ""
  critical_operator              = ""
  critical_threshold             = ""
  critical_threshold_duration    = ""
  critical_threshold_occurrences = ""
  warning_operator               = ""
  warning_threshold              = ""
  warning_threshold_duration     = ""
  warning_threshold_occurrences  = ""
  ```

* **Splunk Alerts** - Splunk alerts are configured to alert on a search condition that provides a certain result.
  ```tf
  name                   = ""
  description            = ""
  dispatch_max_time      = ""
  dispatch_max_count     = ""
  dispatch_earliest_time = ""
  dispatch_latest_time   = ""
  alert_severity         = ""
  alert_comparator       = ""
  alert_expires          = ""
  alert_threshold        = ""
  alert_condition        = ""
  cron_schedule          = ""
  disabled               = ""
  search                 = ""
  ```

* **Newrelic Synthetics Secure Credentials NP** - You can use secure credentials with synthetic monitoring to store critical information, such as passwords, API keys, usernames, etc. This prevents scripted monitor users from viewing, updating, or deleting these values unless they have explicit permissions in New Relic.
  ```tf
  key   = ""
  value = ""
  ```

* **Newrelic Synthetics Secure Credentials PRD** - You can use secure credentials with synthetic monitoring to store critical information, such as passwords, API keys, usernames, etc. This prevents scripted monitor users from viewing, updating, or deleting these values unless they have explicit permissions in New Relic.
  ```tf
  key   = ""
  value = ""
  ```

* **Newrelic Synthetics** - Synthetics simulate user traffic to proactively detect and resolve outages and poor performance of URLs, APIs, and critical services before customers notice.
  ```tf
  function  = "" (eg. logon-external, logon-internal)
  type      = ""
  frequency = ""
  locations = []
  ```

* **Newrelic Application Settings** - Application settings is used to create an APDEX score for an application. Apdex is an industry standard to measure users' satisfaction with the response time of web applications and services. It's a simplified Service Level Agreement (SLA) solution that helps you see how satisfied users are with your app through metrics such as Apdex score and dissatisfaction percentage instead of easily skewed traditional metrics such as average response time.
  ```tf
  function                    = "" (eg. apdex)
  app_apdex_threshold         = ""
  end_user_apdex_threshold    = ""
  enable_real_user_monitoring = ""
  ```

* **Newrelic Service Levels** - Service levels are used to measure the performance of a service from the end user (or client application) point of view. For instance, a Service Level can represent whether a video loaded quickly enough, or whether a directions service returned at least one possible route between two points.
  ```tf
  guid               = ""
  function           = "" (eg. external-transactions, internal-transactions)
  description        = ""
  valid_events_from  = ""
  valid_events_where = ""
  bad_events_from    = ""
  bad_events_where   = ""
  objective_target   = ""
  time_window_count  = ""
  time_window_unit   = ""
  ```

## New Relic Synthetic Monitor Reference
Multiple New Relic Synthetic can be created using the list object blocks. When using a script and script varibles that link to the synthetic monitor they will need to be in order because of the count.index being used. <br>
The example below will create the first monitor with the first script location template and the first set of script variables. The second list object will create the second monitor with the second script location and the second set of script variables.
* ```tf
  newrelic_synthetics = [
    {
      function  = "logon-internal"
      type      = "SCRIPT_BROWSER"
      frequency = "5"
      locations = ["AWS_US_EAST_1", "AWS_US_WEST_1"]
    },
    {
      name      = function  = "logon-external"
      type      = "SCRIPT_API"
      frequency = "5"
      locations = ["AWS_US_EAST_1", "AWS_US_WEST_1"]
    }
  ]
  script_location = ["test1.tpl", "test2.tpl"]
  script_variables = [
    {
      variable1 = "synthetic1"
      variable2 = "$secure.CREDENTIAL1"
    },
    {
      variable1 = "synthetic2"
      variable2 = "synthetic2"
      variable3 = "synthetic2"
    }
  ]
  ```

## PagerDuty Config
* PagerDuty Service
  * Each Pagerduty Service will be the "source of truth" for alerts from New Relic and Splunk
  * Each Service will come with a Service Integration that can be added to Jenkins for Deployment information
    * The code block below can be added to the Jenkinsfile and integration key can be found in the service integrations tab:
    * ```pagerdutyChangeEvent(integrationKey: '$INTEGRATION_KEY')```
  * Statuspage.io integration is avalible with the var.statuspage variable
  * Email Integration will be created to receive alerts from Splunk and New Relic
* PagerDuty Slack Connection
  * The slack connection will forward incidents from PagerDuty to the orginization incident channel
* PagerDuty Service Event Rules
  * Event rules can be added to alter the behavior of each indident that is sent to PagerDuty
* PagerDuty Team and Team Membership 
  * Each deploy creates a PagerDuty team to be used with the PagerDuty service
* PagerDuty Schedule and Escaltion Policy
  * There will be three scheudules: Primary, Secondary and Manager
  * The Escalation policy with be set to alert primary -> after 15 minues alert secondary -> after 15 minutes alert manager -> repeat loop one time if manager doesnt answer
* PagerDuty Service Dependency
  * When provided other services that this service being deployed uses it will create a map of dependencies in PagerDuty
  * **PagerDuty will automatically update other services with the dependency of being "used by" to complete the dependency graph for all services**

## Production Workflow of an Incident
The module will standardize the workflow of incidents so teams will all share the same workflow.
* Each Alert will flow from New Relic/Splunk into PagerDuty which will create a PagerDuty incident.
  * **If started manually via Slack /pd trigger command it will create a PagerDuty incident and skip all New Relic and PagerDuty Rules**
  * The PagerDuty incident will then be tied to a ServiceNow incident and share details both ways (PD -> SNOw and SNOW -> PD)
  * Notifications of Productions Incidents will only be in a specific **Orginization Slack Chat** and from **PagerDuty**
  * Priority will be set by the responder on PagerDuty which will then start a backend flow:
    * P5 & P4 - No workflow
    * P3 - Stakeholders Notified and Bridge Opened
    * P2 - EOC Engaged
    * P1 - EOC and Mims Engaged

![Workflow](utils/workflow_diagram.jpeg)

## NRQL Examples
* Monitor Failing in Both Locations
  * SELECT count(*) FROM SyntheticCheck WHERE monitorName = '*APP NAME*' WHERE result = 'FAILED' AND (locationLabel = 'Columbus, OH, USA') and (locationLabel = 'San Francisco, CA, USA')
* Host CPU Alerts
  * SELECT average(cpuPercent) FROM SystemSample WHERE hostname = '*HOSTNAME*'
* Host Memory Alerts
  * SELECT average(memoryUsedPercent) FROM SystemSample WHERE hostname = '*HOSTNAME*'
* Disk Usage
  * SELECT latest(diskUsedPercent) FROM StorageSample WHERE device = 'C:' AND hostname = '*HOSTNAME*'
* SQS Alerting
  * SELECT sum(`provider.approximateNumberOfMessagesVisible.Sum`) FROM QueueSample WHERE provider = 'SqsQueue' AND aws.arn = '*AWS ARN*'
* Lambda Alerting
  * SELECT sum(`provider.errors.Sum`) FROM ServerlessSample WHERE provider LIKE 'LambdaFunction%' AND aws.arn = '*AWS ARN*'
* SQL Blocked Processes
  * SELECT sum(`instance.blockedProcessesCount`) from MssqlInstanceSample where hostname = '*HOSTNAME*'

## Related Online Documentation
[Splunk Terraform Provider](https://registry.terraform.io/providers/splunk/splunk/latest/docs)<br>
[New Relic Terraform Provider](https://registry.terraform.io/providers/newrelic/newrelic/latest/docs)<br>
[PagerDuty Terraform Provider](https://registry.terraform.io/providers/PagerDuty/pagerduty/latest/docs)<br>

TODO:
 * Add Artifactory Webhook extension to show deployed artifacts in PagerDuty Events (https://registry.terraform.io/providers/jfrog/artifactory/latest/docs/resources/artifactory_artifact_webhook, https://github.com/jfrog/partner-integrations/tree/main/PagerDuty/Artifactory)
 * Develop a Plan for using Github Provider
 * Update with optional(string) (Terraform testing should be out next release)
