output "pagerduty_integration_email" {
  value = join("", pagerduty_service_integration.email_integration[*].integration_email)
}

output "pagerduty_service_id" {
  value = join("", pagerduty_service.pd_service[*].id)
}

output "newrelic_policy_np" {
  value = join("", newrelic_alert_policy.qa[*].id)
}

output "newrelic_policy_pp" {
  value = join("", newrelic_alert_policy.pp[*].id)
}

output "newrelic_policy_prd" {
  value = join("", newrelic_alert_policy.prd[*].id)
}
