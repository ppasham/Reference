# Requirements
terraform {
  required_version = ">= 1.3.0"
  required_providers {
    newrelic = {
      source = "newrelic/newrelic"
    }
    pagerduty = {
      source = "pagerduty/pagerduty"
    }
    github = {
      source  = "integrations/github"
      version = "~> 4.0"
    }
  }
}

variable "environment" {
  default     = ""
  type        = string
  description = "The environment for the service (ex. qa, pp, prd)"

  validation {
    condition     = var.environment == "qa" || var.environment == "pp" || var.environment == "prd"
    error_message = "The Environment Name must be one of lowercase np, pp or prd."
  }
}

variable "workload" {
  default     = ""
  type        = string
  description = "The name of the workload (ex. TMS, AT, SMX, FXS)"

  validation {
    condition     = length(var.workload) > 0 && can(regex("^[-0-9A-Za-z]+$", var.workload))
    error_message = "The Workload is required for use in this module and can only use the following: -, a-z, A-Z and 0-9."
  }
}

variable "component" {
  default     = ""
  type        = string
  description = "The name of the component (ex. AddressValidation)"

  validation {
    condition     = length(var.component) > 0 && can(regex("^[-0-9A-Za-z]+$", var.component))
    error_message = "The Component Name is required for use in this module and can only use the following: -, a-z, A-Z and 0-9."
  }
}

variable "application_sub_name" {
  default     = ""
  type        = string
  description = "Optional name to add (SQL, L2)"
}

variable "team_slack_url" {
  default     = ""
  type        = string
  description = "Optional variable to specify a team slack URL to send Notifications"
}

variable "team_slack_channel" {
  default     = ""
  type        = string
  description = "Optional variable to specify team slack channel to send notifications"
}

variable "team_teams_url" {
  default     = ""
  type        = string
  description = "Optional variable to specify a team teams URL to send Notifications"
}

variable "coxauto_ci_id" {
  default     = ""
  type        = string
  description = "Cox Auto Catalog ID from Service Now for the Application"

  validation {
    condition     = length(var.coxauto_ci_id) > 0 && substr(var.coxauto_ci_id, 0, 2) == "CI"
    error_message = "The Catalog ID must be included and a valid Catalog ID must be used, starting with a capital \"CI\"."
  }
}

variable "engineer_on_call_users_id" {
  type        = list(string)
  description = "(Only Applied in Production) The list of user id's that need to be added to the primary on-call schedule"
  default     = []
}

variable "manager_on_call_users_id" {
  type        = list(string)
  description = "(Only Applied in Production) The list of user id's that need to be added to the manager on-call schedule"
  default     = []
}

variable "pagerduty_event_rules" {
  type = list(object({
    condition_operator    = string
    subcondition_operator = string
    subcondition_value    = string
    subcondition_path     = string
    priority_value        = string
  }))
  description = "(Only Applied in Production) The Pagerduty Event rules to route different alerts based on priority"
  default     = []
}

variable "newrelic_muting_rule" {
  type = list(object({
    function           = string
    start_time         = string
    end_time           = string
    repeat             = string
    weekly_repeat_days = list(string)
  }))
  description = "(Only Applied in Production) The New Relic Muting rules to apply on the alerting policy to mute alerts during certain time windows (Release Window)"
  default     = []

  validation {
    condition     = alltrue([for o in var.newrelic_muting_rule : can(regex("^[-0-9A-Za-z]+$", o.function))])
    error_message = "For New Relic Muting rules the name variable can only use the following: -, a-z, A-Z and 0-9."
  }
}

variable "nrql_static_query_alerts" {
  type = list(object({
    function                       = string
    description                    = string
    runbook_url                    = string
    violation_time_limit_seconds   = optional(string, "3600")
    fill_option                    = optional(string, "static")
    fill_value                     = optional(string, "1.0")
    aggregation_window             = optional(string, "60")
    aggregation_method             = string
    aggregation_delay              = optional(string, "120")
    expiration_duration            = optional(string, "120")
    query                          = string
    critical_operator              = string
    critical_threshold             = string
    critical_threshold_duration    = string
    critical_threshold_occurrences = string
    warning_operator               = string
    warning_threshold              = string
    warning_threshold_duration     = string
    warning_threshold_occurrences  = string
  }))
  description = "Optional New Relic Static Query Alerts"
  default     = []

  validation {
    condition     = alltrue([for o in var.nrql_static_query_alerts : can(regex("^[-0-9A-Za-z]+$", o.function))])
    error_message = "For New Relic Static Query Alerts the name variable can only use the following: -, a-z, A-Z and 0-9."
  }
}

variable "nrql_baseline_query_alerts" {
  type = list(object({
    function                       = string
    description                    = string
    runbook_url                    = string
    violation_time_limit_seconds   = optional(string, "3600")
    aggregation_method             = string
    aggregation_delay              = optional(string, "120")
    baseline_direction             = string
    query                          = string
    critical_operator              = string
    critical_threshold             = string
    critical_threshold_duration    = string
    critical_threshold_occurrences = string
    warning_operator               = string
    warning_threshold              = string
    warning_threshold_duration     = string
    warning_threshold_occurrences  = string
  }))
  description = "Optional New Relic Baseline Query Alerts"
  default     = []

  validation {
    condition     = alltrue([for o in var.nrql_baseline_query_alerts : can(regex("^[-0-9A-Za-z]+$", o.function))])
    error_message = "For New Relic Baseline Query Alerts the name variable can only use the following: -, a-z, A-Z and 0-9."
  }
}

variable "newrelic_synthetics_secure_credentials_np" {
  type = list(object({
    key         = string
    value       = string
    description = string
  }))
  description = "Optional New Relic Secure Credential for Non-Prod Synthetics"
  sensitive   = true
  default     = []

  validation {
    condition     = alltrue([for o in var.newrelic_synthetics_secure_credentials_np : can(regex("^[-0-9A-Za-z]+$", o.key))])
    error_message = "For New Relic Secure Credentials the key variable can only use the following: -, a-z, A-Z and 0-9."
  }
}

variable "newrelic_synthetics_secure_credentials_prd" {
  type = list(object({
    key         = string
    value       = string
    description = string
  }))
  description = "Optional New Relic Secure Credential for Production Synthetics"
  sensitive   = true
  default     = []

  validation {
    condition     = alltrue([for o in var.newrelic_synthetics_secure_credentials_prd : can(regex("^[-0-9A-Za-z]+$", o.key))])
    error_message = "For New Relic Secure Credentials the key variable can only use the following: -, a-z, A-Z and 0-9."
  }
}

variable "newrelic_synthetics" {
  type = list(object({
    enable_screenshot_on_failure_and_script = optional(string, "true")
    function                                = string
    period                                  = string
    runtime_type_version                    = string
    runtime_type                            = string
    script_language                         = optional(string, "JAVASCRIPT")
    type                                    = string
    locations_public                        = optional(list(string), ["US_EAST_1", "US_WEST_1"])
  }))
  description = "Optional New Relic Synthetic to create"
  default     = []

  validation {
    condition     = alltrue([for o in var.newrelic_synthetics : can(regex("^[-0-9A-Za-z]+$", o.function))])
    error_message = "For New Relic Synthetics the name variable can only use the following: -, a-z, A-Z and 0-9."
  }
}

variable "script_location" {
  default     = []
  description = "Optional location for Synthetic scripts to be applied to synthetic monitor"
  type        = list(any)
}

variable "script_variables" {
  default     = {}
  description = "Optional script variables to be applied to the script for the synthetic monitor"
  type        = any
}

variable "newrelic_application_settings" {
  type = list(object({
    function                    = string
    app_apdex_threshold         = string
    end_user_apdex_threshold    = string
    enable_real_user_monitoring = optional(string, "true")
  }))
  description = "Optional New Relic Application settings to apply for APM that exsits in New Relic One (ex. Apdex)"
  default     = []

  validation {
    condition     = alltrue([for o in var.newrelic_application_settings : can(regex("^[-0-9A-Za-z]+$", o.function))])
    error_message = "For New Relic Application Settings the name variable can only use the following: -, a-z, A-Z and 0-9."
  }
}

variable "newrelic_service_levels" {
  type = list(object({
    guid               = string
    function           = string
    description        = string
    valid_events_from  = string
    valid_events_where = string
    bad_events_from    = string
    bad_events_where   = string
    objective_target   = string
    time_window_count  = string
    time_window_unit   = string
  }))
  description = "(Only Applied in Production) Optional New Relic SLO/SLI Levels to Create"
  default     = []

  validation {
    condition     = alltrue([for o in var.newrelic_service_levels : can(regex("^[-0-9A-Za-z]+$", o.function))])
    error_message = "For New Relic Service Levels the name variable can only use the following: -, a-z, A-Z and 0-9."
  }
}

variable "create_workload" {
  default     = 1
  description = "Specify if the new relic workload should be created with this deploy"
  type        = number
}

variable "statuspage" {
  default     = 0
  description = "(Only Applied in Production) Specify if StatusPage.io extenstion should be created under the created PagerDuty Service (Default is to not create the extension)"
  type        = number
}

variable "incident_workspace_id" {
  default     = "T02LRKTL7"
  description = "(Only Applied in Production) The workspace id to create a slack channel notification from PagerDuty Service (Default is Cox workspace ID)"
  type        = string
}

variable "incident_channel_id" {
  default     = "C0296MZD8DA"
  description = "(Only Applied in Production) The incident channel id to create a slack channel notification from PagerDuty Service (Default is CMS-Incidents Channel)"
  type        = string
}

variable "pagerduty_service_dependencies" {
  default     = []
  description = "The PagerDuty Business Services that are dependencies of this service"
  type        = list(any)
}

variable "github_code_repo" {
  default     = ""
  description = "The Code repo for sending change events to PagerDuty"
  type        = string
}

variable "github_integration" {
  default     = 1
  description = "(Only Applied in Production) Specify if the Github Change events will be sent to PagerDuty"
  type        = number
}

locals {
  pagerduty_team_name                    = var.application_sub_name != "" ? upper(join("-", ["CMS", var.workload, var.component, var.application_sub_name])) : upper(join("-", ["CMS", var.workload, var.component]))
  pagerduty_schedule_name_primary        = var.application_sub_name != "" ? upper(join("-", ["CMS", var.workload, var.component, var.application_sub_name, "Primary"])) : upper(join("-", ["CMS", var.workload, var.component, "Primary"]))
  pagerduty_schedule_name_secondary      = var.application_sub_name != "" ? upper(join("-", ["CMS", var.workload, var.component, var.application_sub_name, "Secondary"])) : upper(join("-", ["CMS", var.workload, var.component, "Secondary"]))
  pagerduty_schedule_name_manager        = var.application_sub_name != "" ? upper(join("-", ["CMS", var.workload, var.component, var.application_sub_name, "Manager"])) : upper(join("-", ["CMS", var.workload, var.component, "Manager"]))
  pagerduty_escalation_policy            = var.application_sub_name != "" ? upper(join("-", ["CMS", var.workload, var.component, var.application_sub_name, "Escalation-Policy"])) : upper(join("-", ["CMS", var.workload, var.component, "Escalation-Policy"]))
  pagerduty_service_name                 = var.application_sub_name != "" ? upper(join("-", ["CMS", var.workload, var.component, var.application_sub_name])) : upper(join("-", ["CMS", var.workload, var.component]))
  application_name                       = upper(join("-", ["CMS", var.workload, var.component, var.environment]))
  application_sub_name                   = var.application_sub_name != "" ? upper(join("-", ["CMS", var.workload, var.component, var.application_sub_name, var.environment])) : upper(join("-", ["CMS", var.workload, var.component, var.environment]))
  workload_email_integration             = lower(join("-", ["CMS", var.workload, var.component, "email@coxauto.pagerduty.com"]))
  application_sub_name_email_integration = var.application_sub_name != "" ? lower(join("-", ["CMS", var.workload, var.component, var.application_sub_name, "email@coxauto.pagerduty.com"])) : lower(join("-", ["CMS", var.workload, var.component, "email@coxauto.pagerduty.com"]))
  new_relic_policy_name                  = lower(join("-", ["CMS", var.workload, var.component, var.environment]))
  new_relic_policy_sub_name              = var.application_sub_name != "" ? lower(join("-", ["CMS", var.workload, var.component, var.application_sub_name, var.environment])) : lower(join("-", ["CMS", var.workload, var.component, var.environment]))
  new_relic_channel_name_slack           = lower(join("-", ["CMS", var.workload, var.component, var.environment, "slack"]))
  new_relic_channel_sub_name_slack       = var.application_sub_name != "" ? lower(join("-", ["CMS", var.workload, var.component, var.application_sub_name, var.environment, "slack"])) : lower(join("-", ["CMS", var.workload, var.component, var.environment, "slack"]))
  new_relic_channel_name_teams           = lower(join("-", ["CMS", var.workload, var.component, var.environment, "teams"]))
  new_relic_channel_sub_name_teams       = var.application_sub_name != "" ? lower(join("-", ["CMS", var.workload, var.component, var.application_sub_name, var.environment, "teams"])) : lower(join("-", ["CMS", var.workload, var.component, var.environment, "teams"]))
  newrelic_workload                      = var.application_sub_name != "" ? upper(join("-", ["CMS", var.workload, var.component, var.application_sub_name, var.environment])) : upper(join("-", ["CMS", var.workload, var.component, var.environment]))
}

data "pagerduty_extension_schema" "webhook" {
  name = "Generic V2 Webhook"
}

data "pagerduty_vendor" "newrelic" {
  name = "New Relic"
}

data "pagerduty_vendor" "github" {
  name = "Github"
}

data "newrelic_alert_policy" "cms_policy" {
  name       = local.application_sub_name != "" ? local.application_sub_name : local.application_name
  depends_on = [newrelic_alert_policy.qa, newrelic_alert_policy.pp, newrelic_alert_policy.prd]
}

data "newrelic_account" "account_id" {
  account_id = var.environment == "qa" || var.environment == "pp" ? "2767861" : "1842316"
}

data "pagerduty_service" "service" {
  count = length(var.pagerduty_service_dependencies)
  name  = var.pagerduty_service_dependencies[count.index]
}

#-------------------------------------------------------------------------------
# PagerDuty Service and Extension Configurations
#-------------------------------------------------------------------------------
resource "pagerduty_service" "pd_service" {
  count             = var.environment == "prd" ? 1 : 0
  name              = local.pagerduty_service_name
  description       = var.coxauto_ci_id
  escalation_policy = pagerduty_escalation_policy.cms_escalation[count.index].id
  alert_creation    = "create_alerts_and_incidents"
  alert_grouping_parameters {
    type = "time"
    config {
      timeout = 0
    }
  }
}

resource "pagerduty_service_integration" "apiv2" {
  count   = var.environment == "prd" ? 1 : 0
  name    = "API V2 Integration"
  type    = "events_api_v2_inbound_integration"
  service = pagerduty_service.pd_service[count.index].id
}

resource "pagerduty_service_integration" "github_integration" {
  count   = var.environment == "prd" ? var.github_integration : 0
  name    = "Github"
  service = pagerduty_service.pd_service[count.index].id
  vendor  = data.pagerduty_vendor.github.id
}

resource "github_repository_webhook" "pd_integration" {
  count      = var.environment == "prd" ? var.github_integration : 0
  repository = var.github_code_repo

  configuration {
    url          = "https://events.pagerduty.com/integration/${pagerduty_service_integration.github_integration[count.index].integration_key}/change/enqueue"
    content_type = "x-www-form-urlencoded"
    insecure_ssl = "0"
  }

  active = true

  events = ["pull_request"]
}

resource "pagerduty_service_integration" "newrelic_integration" {
  count   = var.environment == "prd" ? 1 : 0
  name    = "CMS-NEW-RELIC-PRD"
  service = pagerduty_service.pd_service[count.index].id
  vendor  = data.pagerduty_vendor.newrelic.id
}

resource "pagerduty_extension" "statuspage" {
  count             = var.environment == "prd" ? var.statuspage : 0
  name              = "Statuspage.io"
  endpoint_url      = "https://webhooks.statuspage.io/pagerduty_webhooks/create"
  extension_schema  = data.pagerduty_extension_schema.webhook.id
  extension_objects = [pagerduty_service.pd_service[count.index].id]
}

resource "pagerduty_slack_connection" "slack" {
  count             = var.environment == "prd" ? 1 : 0
  source_id         = join("", pagerduty_service.pd_service[*].id)
  source_type       = "service_reference"
  workspace_id      = var.incident_workspace_id
  channel_id        = var.incident_channel_id
  notification_type = "responder"
  config {
    events = [
      "incident.triggered",
      "incident.acknowledged",
      "incident.escalated",
      "incident.resolved",
      "incident.reassigned",
      "incident.annotated",
      "incident.unacknowledged",
    ]
  }
}

resource "pagerduty_service_event_rule" "event_rule" {
  count   = var.environment == "prd" ? length(var.pagerduty_event_rules) : 0
  service = join("", pagerduty_service.pd_service[*].id)
  conditions {
    operator = var.pagerduty_event_rules[count.index].condition_operator
    subconditions {
      operator = var.pagerduty_event_rules[count.index].subcondition_operator
      parameter {
        value = var.pagerduty_event_rules[count.index].subcondition_value
        path  = var.pagerduty_event_rules[count.index].subcondition_path
      }
    }
  }
  actions {
    priority {
      value = var.pagerduty_event_rules[count.index].priority_value
    }
  }
}

resource "pagerduty_team" "pagerduty_team" {
  count = var.environment == "prd" ? 1 : 0
  name  = local.pagerduty_team_name
}

resource "pagerduty_team_membership" "pagerduty_team" {
  count   = var.environment == "prd" ? length(var.engineer_on_call_users_id) : 0
  user_id = var.engineer_on_call_users_id[count.index]
  team_id = pagerduty_team.pagerduty_team[0].id
  role    = "manager"
}

resource "pagerduty_schedule" "pagerduty_schedule_primary" {
  count     = var.environment == "prd" ? 1 : 0
  name      = local.pagerduty_schedule_name_primary
  time_zone = "UTC"

  layer {
    name                         = "Primary"
    start                        = "2022-01-07T07:00:00-12:00"
    rotation_virtual_start       = "2022-01-07T07:00:00-12:00"
    rotation_turn_length_seconds = 604800
    users                        = var.engineer_on_call_users_id
  }

  lifecycle {
    ignore_changes = [
      # Ignore changes because of start date
      layer[0].start
    ]
  }
}

resource "pagerduty_schedule" "pagerduty_schedule_secondary" {
  count     = var.environment == "prd" ? 1 : 0
  name      = local.pagerduty_schedule_name_secondary
  time_zone = "UTC"

  layer {
    name                         = "Secondary"
    start                        = "2022-01-07T07:00:00-12:00"
    rotation_virtual_start       = "2022-01-07T07:00:00-12:00"
    rotation_turn_length_seconds = 604800
    users                        = concat(slice(var.engineer_on_call_users_id, 1, length(var.engineer_on_call_users_id)), [element(var.engineer_on_call_users_id, 0)])
  }

  lifecycle {
    ignore_changes = [
      # Ignore changes because of start date
      layer[0].start
    ]
  }
}

resource "pagerduty_schedule" "pagerduty_schedule_manager" {
  count     = var.environment == "prd" ? 1 : 0
  name      = local.pagerduty_schedule_name_manager
  time_zone = "UTC"

  layer {
    name                         = "Manager"
    start                        = "2022-01-07T07:00:00-12:00"
    rotation_virtual_start       = "2022-01-07T07:00:00-12:00"
    rotation_turn_length_seconds = 604800
    users                        = var.manager_on_call_users_id
  }

  lifecycle {
    ignore_changes = [
      # Ignore changes because of start date
      layer[0].start
    ]
  }
}

resource "pagerduty_escalation_policy" "cms_escalation" {
  count     = var.environment == "prd" ? 1 : 0
  name      = local.pagerduty_escalation_policy
  num_loops = 1
  teams     = [pagerduty_team.pagerduty_team[count.index].id]

  rule {
    escalation_delay_in_minutes = 10
    target {
      type = "schedule_reference"
      id   = pagerduty_schedule.pagerduty_schedule_primary[count.index].id
    }
  }

  rule {
    escalation_delay_in_minutes = 15
    target {
      type = "schedule_reference"
      id   = pagerduty_schedule.pagerduty_schedule_secondary[count.index].id
    }
  }

  rule {
    escalation_delay_in_minutes = 15
    target {
      type = "schedule_reference"
      id   = pagerduty_schedule.pagerduty_schedule_manager[count.index].id
    }
  }
}

resource "pagerduty_service_integration" "email_integration" {
  count             = var.environment == "prd" ? 1 : 0
  name              = local.application_sub_name != "" ? local.application_sub_name : local.application_name
  type              = "generic_email_inbound_integration"
  integration_email = local.application_sub_name != "" ? local.application_sub_name_email_integration : local.workload_email_integration
  service           = pagerduty_service.pd_service[count.index].id
}

resource "pagerduty_service_dependency" "service_dependency" {
  count = var.environment == "prd" && var.pagerduty_service_dependencies != "" ? length(var.pagerduty_service_dependencies) : 0
  dependency {
    dependent_service {
      id   = pagerduty_service.pd_service[0].id
      type = "service"
    }
    supporting_service {
      id   = data.pagerduty_service.service[count.index].id
      type = "service"
    }
  }
}

#-------------------------------------------------------------------------------
# New Relic Notification Configuration
#-------------------------------------------------------------------------------
resource "newrelic_alert_policy" "prd" {
  count               = var.environment == "prd" ? 1 : 0
  name                = upper(local.application_sub_name != "" ? local.application_sub_name : local.application_name)
  incident_preference = "PER_POLICY"
}

resource "newrelic_alert_channel" "pagerduty" {
  count = var.environment == "prd" ? 1 : 0
  name  = local.application_sub_name != "" ? local.application_sub_name : local.application_name
  type  = "pagerduty"

  config {
    service_key = pagerduty_service_integration.newrelic_integration[count.index].integration_key
  }
}

resource "newrelic_alert_policy_channel" "channel_policy" {
  count       = var.environment == "prd" ? 1 : 0
  policy_id   = newrelic_alert_policy.prd[count.index].id
  channel_ids = [newrelic_alert_channel.pagerduty[count.index].id]
}

resource "newrelic_alert_policy" "qa" {
  count               = var.environment == "qa" ? 1 : 0
  name                = upper(local.new_relic_policy_sub_name != "" ? local.new_relic_policy_sub_name : local.new_relic_policy_name)
  incident_preference = "PER_POLICY"
}

resource "newrelic_alert_channel" "slack_channel_qa" {
  count = (length(var.team_slack_url) > 0) && var.environment == "qa" ? 1 : 0

  name = local.new_relic_channel_sub_name_slack != "" ? local.new_relic_channel_sub_name_slack : local.new_relic_channel_name_slack
  type = "slack"

  config {
    url     = var.team_slack_url
    channel = var.team_slack_channel
  }
}

resource "newrelic_alert_policy_channel" "channel_policy_slack_qa" {
  count       = (length(var.team_slack_url) > 0) && var.environment == "qa" ? 1 : 0
  policy_id   = newrelic_alert_policy.qa[count.index].id
  channel_ids = [newrelic_alert_channel.slack_channel_qa[count.index].id]
}

resource "newrelic_alert_channel" "teams_channel_qa" {
  count = (length(var.team_teams_url) > 0) && var.environment == "qa" ? 1 : 0

  lifecycle {
    ignore_changes = [config]
  }
  name = local.new_relic_channel_sub_name_teams != "" ? local.new_relic_channel_sub_name_teams : local.new_relic_channel_name_teams
  type = "webhook"

  config {
    base_url       = var.team_teams_url
    payload_type   = "application/json"
    payload_string = <<EOF
    {
      "title": "New Relic Alert: $CONDITION_NAME in $POLICY_NAME",
      "text": "$EVENT_DETAILS"
    }
    EOF
  }
}

resource "newrelic_alert_policy_channel" "channel_policy_teams_qa" {
  count       = (length(var.team_teams_url) > 0) && var.environment == "qa" ? 1 : 0
  policy_id   = newrelic_alert_policy.qa[count.index].id
  channel_ids = [newrelic_alert_channel.teams_channel_qa[count.index].id]
}

resource "newrelic_alert_policy" "pp" {
  count               = var.environment == "pp" ? 1 : 0
  name                = upper(local.new_relic_policy_sub_name != "" ? local.new_relic_policy_sub_name : local.new_relic_policy_name)
  incident_preference = "PER_POLICY"
}

resource "newrelic_alert_channel" "slack_channel_pp" {
  count = (length(var.team_slack_url) > 0) && var.environment == "pp" ? 1 : 0

  name = local.new_relic_channel_sub_name_slack != "" ? local.new_relic_channel_sub_name_slack : local.new_relic_channel_name_slack
  type = "slack"

  config {
    url     = var.team_slack_url
    channel = var.team_slack_channel
  }
}

resource "newrelic_alert_policy_channel" "channel_policy_slack_pp" {
  count       = (length(var.team_slack_url) > 0) && var.environment == "pp" ? 1 : 0
  policy_id   = newrelic_alert_policy.pp[count.index].id
  channel_ids = [newrelic_alert_channel.slack_channel_pp[count.index].id]
}

resource "newrelic_alert_channel" "teams_channel_pp" {
  count = (length(var.team_teams_url) > 0) && var.environment == "pp" ? 1 : 0

  lifecycle {
    ignore_changes = [config]
  }
  name = local.new_relic_channel_sub_name_teams != "" ? local.new_relic_channel_sub_name_teams : local.new_relic_channel_name_teams
  type = "webhook"

  config {
    base_url       = var.team_teams_url
    payload_type   = "application/json"
    payload_string = <<EOF
    {
      "title": "New Relic Alert: $CONDITION_NAME in $POLICY_NAME",
      "text": "$EVENT_DETAILS"
    }
    EOF
  }
}

resource "newrelic_alert_policy_channel" "channel_policy_teams_pp" {
  count       = (length(var.team_teams_url) > 0) && var.environment == "pp" ? 1 : 0
  policy_id   = newrelic_alert_policy.pp[count.index].id
  channel_ids = [newrelic_alert_channel.teams_channel_pp[count.index].id]
}

#-------------------------------------------------------------------------------
# New Relic Muting Rules
#-------------------------------------------------------------------------------
resource "newrelic_alert_muting_rule" "alert_mute" {
  count   = var.environment == "prd" ? length(var.newrelic_muting_rule) : 0
  name    = var.application_sub_name != "" ? lower(join("-", ["CMS", var.workload, var.component, var.application_sub_name, var.newrelic_muting_rule[count.index].function, var.environment, "muting-rule"])) : upper(join("-", ["CMS", var.workload, var.component, var.newrelic_muting_rule[count.index].function, var.environment, "muting-rule"]))
  enabled = true
  condition {
    conditions {
      attribute = "policyId"
      operator  = "EQUALS"
      values    = [join("", newrelic_alert_policy.prd[*].id)]
    }
    conditions {
      attribute = "targetId"
      operator  = "EQUALS"
      values    = ["Muted"]
    }
    operator = "AND"
  }
  schedule {
    start_time         = var.newrelic_muting_rule[count.index].start_time
    end_time           = var.newrelic_muting_rule[count.index].end_time
    time_zone          = "America/Los_Angeles"
    repeat             = var.newrelic_muting_rule[count.index].repeat
    weekly_repeat_days = var.newrelic_muting_rule[count.index].weekly_repeat_days
  }

  lifecycle {
    ignore_changes = [
      # Ignore changes because of start date
      schedule[0].start_time,
      schedule[0].end_time
    ]
  }
}

#-------------------------------------------------------------------------------
# New Relic Secure Credentials
#-------------------------------------------------------------------------------
resource "newrelic_synthetics_secure_credential" "secure_credential_np" {
  count       = var.environment == "qa" || var.environment == "pp" ? length(var.newrelic_synthetics_secure_credentials_np) : 0
  key         = upper(var.newrelic_synthetics_secure_credentials_np[count.index].key)
  value       = var.newrelic_synthetics_secure_credentials_np[count.index].value
  description = var.newrelic_synthetics_secure_credentials_np[count.index].description
}

resource "newrelic_synthetics_secure_credential" "secure_credential_prd" {
  count       = var.environment == "prd" ? length(var.newrelic_synthetics_secure_credentials_prd) : 0
  key         = upper(var.newrelic_synthetics_secure_credentials_prd[count.index].key)
  value       = var.newrelic_synthetics_secure_credentials_prd[count.index].value
  description = var.newrelic_synthetics_secure_credentials_prd[count.index].description
}

#-------------------------------------------------------------------------------
# New Relic Synthetics
#-------------------------------------------------------------------------------
resource "newrelic_synthetics_script_monitor" "cms_monitor_qa" {
  count                                   = var.environment == "qa" || var.environment == "pp" ? length(var.newrelic_synthetics) : 0
  enable_screenshot_on_failure_and_script = var.newrelic_synthetics[count.index].enable_screenshot_on_failure_and_script
  locations_public                        = var.newrelic_synthetics[count.index].locations_public
  name                                    = var.application_sub_name != "" ? lower(join("-", ["CMS", var.workload, var.component, var.application_sub_name, var.newrelic_synthetics[count.index].function, var.environment, "synthetic"])) : upper(join("-", ["CMS", var.workload, var.component, var.newrelic_synthetics[count.index].function, var.environment, "synthetic"]))
  period                                  = var.newrelic_synthetics[count.index].period
  runtime_type_version                    = var.newrelic_synthetics[count.index].runtime_type_version
  runtime_type                            = var.newrelic_synthetics[count.index].runtime_type
  script_language                         = var.newrelic_synthetics[count.index].script_language
  status                                  = "ENABLED"
  type                                    = var.newrelic_synthetics[count.index].type
  script                                  = templatefile(var.script_location[count.index], tomap(var.script_variables[count.index]))
  tag {
    key    = "component"
    values = [var.component]
  }
}

resource "newrelic_synthetics_script_monitor" "cms_monitor_prd" {
  count                                   = var.environment == "prd" ? length(var.newrelic_synthetics) : 0
  enable_screenshot_on_failure_and_script = var.newrelic_synthetics[count.index].enable_screenshot_on_failure_and_script
  locations_public                        = var.newrelic_synthetics[count.index].locations_public
  name                                    = var.application_sub_name != "" ? lower(join("-", ["CMS", var.workload, var.component, var.application_sub_name, var.newrelic_synthetics[count.index].function, var.environment, "synthetic"])) : upper(join("-", ["CMS", var.workload, var.component, var.newrelic_synthetics[count.index].function, var.environment, "synthetic"]))
  period                                  = var.newrelic_synthetics[count.index].period
  runtime_type_version                    = var.newrelic_synthetics[count.index].runtime_type_version
  runtime_type                            = var.newrelic_synthetics[count.index].runtime_type
  script_language                         = var.newrelic_synthetics[count.index].script_language
  status                                  = "ENABLED"
  type                                    = var.newrelic_synthetics[count.index].type
  script                                  = templatefile(var.script_location[count.index], tomap(var.script_variables[count.index]))
  tag {
    key    = "component"
    values = [var.component]
  }
}

#-------------------------------------------------------------------------------
# New Relic Application Settings
#-------------------------------------------------------------------------------
resource "newrelic_application_settings" "app" {
  count                       = var.newrelic_application_settings != "" ? length(var.newrelic_application_settings) : 0
  name                        = var.application_sub_name != "" ? lower(join("-", ["CMS", var.workload, var.component, var.application_sub_name, var.newrelic_application_settings[count.index].function, var.environment, "application-setting"])) : upper(join("-", ["CMS", var.workload, var.component, var.newrelic_application_settings[count.index].function, var.environment, "application-setting"]))
  app_apdex_threshold         = var.newrelic_application_settings[count.index].app_apdex_threshold
  end_user_apdex_threshold    = var.newrelic_application_settings[count.index].end_user_apdex_threshold
  enable_real_user_monitoring = var.newrelic_application_settings[count.index].enable_real_user_monitoring
}

#-------------------------------------------------------------------------------
# New Relic Workload
#-------------------------------------------------------------------------------
resource "newrelic_workload" "cms_workload" {
  count             = var.create_workload
  name              = local.newrelic_workload
  account_id        = data.newrelic_account.account_id.id
  scope_account_ids = [data.newrelic_account.account_id.id]
  entity_search_query {
    query = "`tags.label.Environment` = '${var.environment}' AND `tags.label.coxauto:ci-id` = '${var.coxauto_ci_id}'"
  }
}

#-------------------------------------------------------------------------------
# New Relic Static Query Alerts
#-------------------------------------------------------------------------------
resource "newrelic_nrql_alert_condition" "static_nrql_alerts_qa" {
  count                          = var.environment == "qa" || var.environment == "pp" ? length(var.nrql_static_query_alerts) : 0
  policy_id                      = data.newrelic_alert_policy.cms_policy.id
  type                           = "static"
  name                           = var.application_sub_name != "" ? lower(join("-", ["CMS", var.workload, var.component, var.application_sub_name, var.nrql_static_query_alerts[count.index].function, var.environment, "static-alert"])) : upper(join("-", ["CMS", var.workload, var.component, var.nrql_static_query_alerts[count.index].function, var.environment, "static-alert"]))
  description                    = var.nrql_static_query_alerts[count.index].description
  runbook_url                    = var.nrql_static_query_alerts[count.index].runbook_url
  enabled                        = true
  violation_time_limit_seconds   = var.nrql_static_query_alerts[count.index].violation_time_limit_seconds
  fill_option                    = var.nrql_static_query_alerts[count.index].fill_option
  fill_value                     = var.nrql_static_query_alerts[count.index].fill_value
  aggregation_window             = var.nrql_static_query_alerts[count.index].aggregation_window
  aggregation_method             = var.nrql_static_query_alerts[count.index].aggregation_method
  aggregation_delay              = var.nrql_static_query_alerts[count.index].aggregation_delay
  expiration_duration            = var.nrql_static_query_alerts[count.index].expiration_duration
  open_violation_on_expiration   = true
  close_violations_on_expiration = true

  nrql {
    query = var.nrql_static_query_alerts[count.index].query
  }

  critical {
    operator              = var.nrql_static_query_alerts[count.index].critical_operator
    threshold             = var.nrql_static_query_alerts[count.index].critical_threshold
    threshold_duration    = var.nrql_static_query_alerts[count.index].critical_threshold_duration
    threshold_occurrences = var.nrql_static_query_alerts[count.index].critical_threshold_occurrences
  }

  warning {
    operator              = var.nrql_static_query_alerts[count.index].warning_operator
    threshold             = var.nrql_static_query_alerts[count.index].warning_threshold
    threshold_duration    = var.nrql_static_query_alerts[count.index].warning_threshold_duration
    threshold_occurrences = var.nrql_static_query_alerts[count.index].warning_threshold_occurrences
  }
}

resource "newrelic_nrql_alert_condition" "static_nrql_alerts_prd" {
  count                          = var.environment == "prd" ? length(var.nrql_static_query_alerts) : 0
  policy_id                      = join("", newrelic_alert_policy.prd[*].id)
  type                           = "static"
  name                           = var.application_sub_name != "" ? lower(join("-", ["CMS", var.workload, var.component, var.application_sub_name, var.nrql_static_query_alerts[count.index].function, var.environment, "static-alert"])) : upper(join("-", ["CMS", var.workload, var.component, var.nrql_static_query_alerts[count.index].function, var.environment, "static-alert"]))
  description                    = var.nrql_static_query_alerts[count.index].description
  runbook_url                    = var.nrql_static_query_alerts[count.index].runbook_url
  enabled                        = true
  violation_time_limit_seconds   = var.nrql_static_query_alerts[count.index].violation_time_limit_seconds
  fill_option                    = var.nrql_static_query_alerts[count.index].fill_option
  fill_value                     = var.nrql_static_query_alerts[count.index].fill_value
  aggregation_window             = var.nrql_static_query_alerts[count.index].aggregation_window
  aggregation_method             = var.nrql_static_query_alerts[count.index].aggregation_method
  aggregation_delay              = var.nrql_static_query_alerts[count.index].aggregation_delay
  expiration_duration            = var.nrql_static_query_alerts[count.index].expiration_duration
  open_violation_on_expiration   = true
  close_violations_on_expiration = true

  nrql {
    query = var.nrql_static_query_alerts[count.index].query
  }

  critical {
    operator              = var.nrql_static_query_alerts[count.index].critical_operator
    threshold             = var.nrql_static_query_alerts[count.index].critical_threshold
    threshold_duration    = var.nrql_static_query_alerts[count.index].critical_threshold_duration
    threshold_occurrences = var.nrql_static_query_alerts[count.index].critical_threshold_occurrences
  }

  warning {
    operator              = var.nrql_static_query_alerts[count.index].warning_operator
    threshold             = var.nrql_static_query_alerts[count.index].warning_threshold
    threshold_duration    = var.nrql_static_query_alerts[count.index].warning_threshold_duration
    threshold_occurrences = var.nrql_static_query_alerts[count.index].warning_threshold_occurrences
  }
}

#-------------------------------------------------------------------------------
# New Relic Baseline Query Alerts
#-------------------------------------------------------------------------------
resource "newrelic_nrql_alert_condition" "baseline_nrql_alerts_qa" {
  count                        = var.environment == "qa" || var.environment == "pp" ? length(var.nrql_baseline_query_alerts) : 0
  policy_id                    = data.newrelic_alert_policy.cms_policy.id
  type                         = "baseline"
  name                         = var.application_sub_name != "" ? lower(join("-", ["CMS", var.workload, var.component, var.application_sub_name, var.nrql_baseline_query_alerts[count.index].function, var.environment, "baseline-alert"])) : upper(join("-", ["CMS", var.workload, var.component, var.nrql_baseline_query_alerts[count.index].function, var.environment, "baseline-alert"]))
  description                  = var.nrql_baseline_query_alerts[count.index].description
  runbook_url                  = var.nrql_baseline_query_alerts[count.index].runbook_url
  violation_time_limit_seconds = var.nrql_baseline_query_alerts[count.index].violation_time_limit_seconds
  aggregation_method           = var.nrql_baseline_query_alerts[count.index].aggregation_method
  aggregation_delay            = var.nrql_baseline_query_alerts[count.index].aggregation_delay
  baseline_direction           = var.nrql_baseline_query_alerts[count.index].baseline_direction

  nrql {
    query = var.nrql_baseline_query_alerts[count.index].query
  }

  critical {
    operator              = var.nrql_baseline_query_alerts[count.index].critical_operator
    threshold             = var.nrql_baseline_query_alerts[count.index].critical_threshold
    threshold_duration    = var.nrql_baseline_query_alerts[count.index].critical_threshold_duration
    threshold_occurrences = var.nrql_baseline_query_alerts[count.index].critical_threshold_occurrences
  }

  warning {
    operator              = var.nrql_baseline_query_alerts[count.index].warning_operator
    threshold             = var.nrql_baseline_query_alerts[count.index].warning_threshold
    threshold_duration    = var.nrql_baseline_query_alerts[count.index].warning_threshold_duration
    threshold_occurrences = var.nrql_baseline_query_alerts[count.index].warning_threshold_occurrences
  }
}

resource "newrelic_nrql_alert_condition" "baseline_nrql_alerts_prd" {
  count                        = var.environment == "prd" ? length(var.nrql_baseline_query_alerts) : 0
  policy_id                    = join("", newrelic_alert_policy.prd[*].id)
  type                         = "baseline"
  name                         = var.application_sub_name != "" ? lower(join("-", ["CMS", var.workload, var.component, var.application_sub_name, var.nrql_baseline_query_alerts[count.index].function, var.environment, "baseline-alert"])) : upper(join("-", ["CMS", var.workload, var.component, var.nrql_baseline_query_alerts[count.index].function, var.environment, "baseline-alert"]))
  description                  = var.nrql_baseline_query_alerts[count.index].description
  runbook_url                  = var.nrql_baseline_query_alerts[count.index].runbook_url
  violation_time_limit_seconds = var.nrql_baseline_query_alerts[count.index].violation_time_limit_seconds
  aggregation_method           = var.nrql_baseline_query_alerts[count.index].aggregation_method
  aggregation_delay            = var.nrql_baseline_query_alerts[count.index].aggregation_delay
  baseline_direction           = var.nrql_baseline_query_alerts[count.index].baseline_direction

  nrql {
    query = var.nrql_baseline_query_alerts[count.index].query
  }

  critical {
    operator              = var.nrql_baseline_query_alerts[count.index].critical_operator
    threshold             = var.nrql_baseline_query_alerts[count.index].critical_threshold
    threshold_duration    = var.nrql_baseline_query_alerts[count.index].critical_threshold_duration
    threshold_occurrences = var.nrql_baseline_query_alerts[count.index].critical_threshold_occurrences
  }

  warning {
    operator              = var.nrql_baseline_query_alerts[count.index].warning_operator
    threshold             = var.nrql_baseline_query_alerts[count.index].warning_threshold
    threshold_duration    = var.nrql_baseline_query_alerts[count.index].warning_threshold_duration
    threshold_occurrences = var.nrql_baseline_query_alerts[count.index].warning_threshold_occurrences
  }
}
#-------------------------------------------------------------------------------
# New Relic SLO/SLI Configuration
#-------------------------------------------------------------------------------
resource "newrelic_service_level" "service_level" {
  count       = var.environment == "prd" ? length(var.newrelic_service_levels) : 0
  guid        = var.newrelic_service_levels[count.index].guid
  name        = var.application_sub_name != "" ? lower(join("-", ["CMS", var.workload, var.component, var.application_sub_name, var.newrelic_service_levels[count.index].function, var.environment, "service-level"])) : upper(join("-", ["CMS", var.workload, var.component, var.newrelic_service_levels[count.index].function, var.environment, "service-level"]))
  description = var.newrelic_service_levels[count.index].description

  events {
    account_id = data.newrelic_account.account_id.id
    valid_events {
      from  = var.newrelic_service_levels[count.index].valid_events_from
      where = var.newrelic_service_levels[count.index].valid_events_where
    }
    bad_events {
      from  = var.newrelic_service_levels[count.index].bad_events_from
      where = var.newrelic_service_levels[count.index].bad_events_where
    }
  }

  objective {
    target = var.newrelic_service_levels[count.index].objective_target
    time_window {
      rolling {
        count = var.newrelic_service_levels[count.index].time_window_count
        unit  = var.newrelic_service_levels[count.index].time_window_unit
      }
    }
  }
}
