Echo Hello World
Echo ${variable1}
Echo ${variable2}
