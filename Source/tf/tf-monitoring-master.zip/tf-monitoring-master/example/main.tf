# Requirements
terraform {
  required_version = ">= 1.3.0"
  required_providers {
    newrelic = {
      source = "newrelic/newrelic"
    }
    pagerduty = {
      source = "pagerduty/pagerduty"
    }
    github = {
      source  = "integrations/github"
      version = "~> 4.0"
    }
  }
}

variable "environment" {
  default     = "pp"
  description = "The environment for the service (ex. qa, pp, prd)"
}

variable "workload" {
  default     = "ncdev"
  description = "The name of the Workload (ex. TMS, AT)"
}

variable "component" {
  default     = "test"
  description = "The name of the Component (ex. address-validation, kofax)"
}

variable "application_sub_name" {
  default     = ""
  description = "Optional Name to add to policies and services"
}

variable "team_slack_channel" {
  default     = "#ncdev"
  description = "Optional variable to specify a slack URL to send dev Team Notifications"
}

variable "team_slack_url" {
  default     = "testing.com"
  description = "Team slack channel URL"
}

#variable "team_teams_url" {
#  default     = "https://testingteams.com"
#  description = "Optional variable to specify a teams URL to send Prod Team Notifications"
#}

variable "engineer_on_call_users_id" {
  type    = list(string)
  default = ["P91WWWF"]
}

variable "manager_on_call_users_id" {
  type    = list(string)
  default = ["P91WWWF"]
}

variable "coxauto_ci_id" {
  default = "CI767676"
}

variable "pagerduty_service_dependencies" {
  default = ["CMS-DEVOPS-ALERTS"]
}

variable "github_code_repo" {
  default = "Monitoring-Deployment"
}

locals {
  newrelic_synthetics_secure_credentials_prd = [
    {
      key         = "Credential1Test"
      value       = "qwerty"
      description = "testing"
    },
    {
      key        = "Credential2Test"
      value      = "12345"
      description = "testing"
    }
  ]
  pagerduty_event_rules = [
    {
      condition_operator    = "and"
      subcondition_operator = "contains"
      subcondition_value    = "disk space"
      subcondition_path     = "summary"
      priority_value        = "P5"
    },
    {
      condition_operator    = "or"
      subcondition_operator = "contains"
      subcondition_value    = "disk space"
      subcondition_path     = "summary"
      priority_value        = "P5"
    }
  ]
  newrelic_synthetics = [
    {
      function             = "logon-internal"
      period               = "EVERY_HOUR"
      runtime_type_version = "100"
      runtime_type         = "CHROME_BROWSER"
      type                 = "SCRIPT_BROWSER"
      locations_public     = ["US_EAST_1", "US_WEST_1"]
    },
    {
      function             = "logon-external"
      period               = "EVERY_HOUR"
      runtime_type_version = "16.10"
      runtime_type         = "NODE_API"
      type                 = "SCRIPT_API"
      locations_public     = ["US_EAST_2", "US_WEST_2"]
    }
  ]
  script_location = ["test1.tpl", "test2.tpl"]
  script_variables = [
    {
      variable1 = "synthetic1"
      variable2 = "$secure.CREDENTIAL1"
    },
    {
      variable1 = "synthetic2"
      variable2 = "synthetic2"
      variable3 = "synthetic2"
    }
  ]
  nrql_static_query_alerts = [
    {
      function    = "average-transaction-duration"
      description = "ncdev testing"
      runbook_url = "test.runbook.com"
      fill_option = "static"
      fill_value  = "1.0"
      aggregation_window             = "60"
      aggregation_method = "event_flow"
      aggregation_delay              = "120"
      expiration_duration            = "120"
      query                          = "SELECT average(duration) FROM Transaction where appName = 'Your App'"
      critical_operator              = "above"
      critical_threshold             = "0.002"
      critical_threshold_duration    = "600"
      critical_threshold_occurrences = "all"
      warning_operator               = "above"
      warning_threshold              = "0.0015"
      warning_threshold_duration     = "600"
      warning_threshold_occurrences  = "all"
    },
    {
      function                       = "average-transaction"
      description                    = "ncdev testing"
      runbook_url                    = "test.runbook.com"
      value_function                 = "single_value"
      fill_option                    = "static"
      fill_value                     = "1.0"
      aggregation_window             = "60"
      aggregation_method             = "event_flow"
      aggregation_delay              = "120"
      expiration_duration            = "120"
      query                          = "SELECT average(duration) FROM Transaction where appName = 'Your App'"
      critical_operator              = "above"
      critical_threshold             = "0.002"
      critical_threshold_duration    = "600"
      critical_threshold_occurrences = "all"
      warning_operator               = "above"
      warning_threshold              = "0.0015"
      warning_threshold_duration     = "600"
      warning_threshold_occurrences  = "all"
    }
  ]
  nrql_baseline_query_alerts = [
    {
      function                       = "percentile-transaction-check"
      description                    = "ncdev_test"
      runbook_url                    = "test.runbook.com"
      aggregation_method             = "event_flow"
      aggregation_delay              = "120"
      baseline_direction             = "upper_only"
      query                          = "SELECT percentile(duration, 95) FROM Transaction WHERE appName = 'ExampleAppName'"
      critical_operator              = "above"
      critical_threshold             = "2"
      critical_threshold_duration    = "600"
      critical_threshold_occurrences = "all"
      warning_operator               = "above"
      warning_threshold              = "1"
      warning_threshold_duration     = "600"
      warning_threshold_occurrences  = "all"
    }
  ]
  newrelic_muting_rule = [
    {
      function           = "after-hours"
      start_time         = "2021-01-28T0:00:00"
      end_time           = "2021-01-28T0:00:00"
      repeat             = "WEEKLY"
      weekly_repeat_days = ["SUNDAY", "MONDAY"]
    },
    {
      function           = "after-hours-sunday"
      start_time         = "2021-01-28T0:00:00"
      end_time           = "2021-01-28T0:00:00"
      repeat             = "WEEKLY"
      weekly_repeat_days = ["SUNDAY"]
    }
  ]
  splunk_alerts = [
    {
      name                   = "test-ncdev"
      description            = "Testing Deploy"
      dispatch_max_time      = "60"
      dispatch_max_count     = "15"
      dispatch_earliest_time = "rt-15m"
      dispatch_latest_time   = "rt-0m"
      alert_severity         = "5"
      alert_comparator       = "greater_than"
      alert_expires          = "60"
      alert_threshold        = ""
      alert_condition        = ""
      cron_schedule          = "*/5 * * * *"
      disabled               = "true"
      search                 = "index=main"
    }
  ]
  newrelic_service_levels = [
    {
      guid               = "MTg0MjMxNnxBUE18QVBQTElDQVRJT058MTUwMDMxNDU2"
      function           = "external-transactions"
      description        = "NCDEV-TEST-SLO"
      valid_events_from  = "Transaction"
      valid_events_where = "appName = 'Title API Relay - DevInt'"
      bad_events_from    = "TransactionError"
      bad_events_where   = "appName = 'Title API Relay - DevInt' AND error.expected is false"
      objective_target   = "99.00"
      time_window_count  = "7"
      time_window_unit   = "DAY"
    }
  ]
}

module "monitoring_example" {
  source      = "../monitoring"
  environment = var.environment
  team_slack_channel        = var.team_slack_channel
  team_slack_url            = var.team_slack_url
  workload                  = var.workload
  component                 = var.component
  application_sub_name      = var.application_sub_name
  engineer_on_call_users_id = var.engineer_on_call_users_id
  manager_on_call_users_id  = var.manager_on_call_users_id
  newrelic_muting_rule      = local.newrelic_muting_rule
  script_location           = local.script_location
  script_variables          = local.script_variables
  newrelic_synthetics       = local.newrelic_synthetics
  coxauto_ci_id             = var.coxauto_ci_id
  nrql_baseline_query_alerts                 = local.nrql_baseline_query_alerts
  nrql_static_query_alerts                   = local.nrql_static_query_alerts
  newrelic_synthetics_secure_credentials_prd = local.newrelic_synthetics_secure_credentials_prd
  pagerduty_service_dependencies             = var.pagerduty_service_dependencies
  newrelic_service_levels                    = local.newrelic_service_levels
  github_code_repo                           = var.github_code_repo
}
