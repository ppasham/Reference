output "guid" {
  value       = newrelic_workload.load.guid
  description = "The new workload GUID"
}

output "permalink" {
  value       = newrelic_workload.load.permalink
  description = "Permalink to the new workload"
}

output "composite_entity_search_query" {
  value = newrelic_workload.load.composite_entity_search_query
}

output "workload_id" {
  value       = newrelic_workload.load.workload_id
  description = "The new workload id"
}

output "all_entity_search_queries" {
  value       = local.all_entity_search_queries
  description = "Combined search query used to gather the workload resources"
}