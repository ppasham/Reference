#-------------------------------------------------------------------------------
# New Relic Workload
#
###########################################################################################
# Module maintainer: CMS Platform Engineering Services                                    #
# Contact: CMS-SuperSmashCrew@coxautoinc.com                                              #
#                                                                                         #
# Description: Terraform New Relic Workload Creation.                                     #
# README: https://ghe.coxautoinc.com/cms-terraform/tf-new-relic/blob/master/README.md     #
# ___________________                                                                     #
#                                                                                         #
#  Copyright 2021 Cox Automotive Incorporated                                             #
#  All Rights Reserved.                                                                   #
#                                                                                         #
###########################################################################################


terraform {
  required_providers {
    newrelic = {
      source = "newrelic/newrelic"
    }
  }
  required_version = ">= 0.13"
}

variable "workload_name" {
  description = "(Required) The workload's name."
}

variable "new_relic_account_id" {
  description = "(Required) The New Relic account ID where you want to create the workload."
}

variable "entity_guids" {
  default     = []
  type        = list(string)
  description = "(Optional) A list of NR entity GUIDs manually assigned to this workload."
}

variable "entity_names" {
  default     = []
  type        = list(string)
  description = "(Optional) A list of NR entity names to be assigned to this workload."
}

variable "scope_account_ids" {
  default     = []
  description = "(Optional) A list of account IDs that will be used to get entities from."
}

variable "resource_tags" {
  default     = {}
  type        = map(list(string))
  description = <<EOT
(Optional) Tag name and values as a list to identify AWS resources to be added to the new NR workload.

Example: if value is {Environment: ['NP', 'np', 'non-prod'], Product: ['SMX']} then resources that have
these tags with values matching any of the ones specified in the lists will be part of the workload
EOT
}

variable "entity_search_queries" {
  default     = []
  type        = list(string)
  description = <<EOT
(Optional) A list of raw NR query strings as defined in
https://registry.terraform.io/providers/newrelic/newrelic/latest/docs/resources/workload#nested-entity_search_query-blocks
EOT
}

locals {
  // this converts tags from var.resource_tags into one query in this form:
  // (`tags.label.TAG_NAME_1` = 'VAL_1') AND (`tags.label.TAG_NAME_2` = 'VAL_1' OR `tags.label.TAG_NAME_2` = 'VAL_2')
  resource_tags_query       = join(" AND ", [for tag, vals in var.resource_tags : "(${join(" OR ", [for v in vals : "`tags.label.${tag}` = '${v}'"])})"])
  names_queries             = [for name in var.entity_names : "name = '${name}'"]
  all_entity_search_queries = concat(var.entity_search_queries, local.names_queries, local.resource_tags_query != "" ? [local.resource_tags_query] : [])
}

data "newrelic_account" "acc" {
  account_id = var.new_relic_account_id
}

resource "newrelic_workload" "load" {
  name              = var.workload_name
  account_id        = data.newrelic_account.acc.id
  scope_account_ids = var.scope_account_ids
  entity_guids      = var.entity_guids

  dynamic "entity_search_query" {
    for_each = local.all_entity_search_queries
    content {
      query = entity_search_query.value
    }
  }
}

