# Terraform New Relic Infrastructure Alert
#
###########################################################################################
# Module maintainer: CMS Platform Engineering Services                                    #
# Contact: CMS-SuperSmashCrew@coxautoinc.com                                              #
#                                                                                         #
# Description: Terraform New Relic Infrastructure Alert Creation                          #
# README: https://ghe.coxautoinc.com/cms-terraform/tf-new-relic/blob/master/README.md     #
# ___________________                                                                     #
#                                                                                         #
#  Copyright 2019 Cox Automotive Incorporated                                             #
#  All Rights Reserved.                                                                   #
#                                                                                         #
###########################################################################################

# Requirements
terraform {
  required_providers {
    newrelic = {
      source = "newrelic/newrelic"
    }
  }
  required_version = ">= 0.13"
}

# Variables
variable "policy_id" {
  default     = ""
  description = "Alert Policy ID"
}

variable "alert_name" {
  default     = ""
  description = "The Infrastructure alert condition's name."
}

variable "alert_type" {
  default     = ""
  description = "The type of Infrastructure alert condition."
}

variable "integration_provider" {
  default     = ""
  description = "The integration provider for the alert condition."
}

variable "select_target" {
  default     = ""
  description = "The attribute name to identify the metric being targeted."
}

variable "comparison" {
  default     = ""
  description = "The operator used to evaluate the threshold value. Valid values are above, below, and equal."
}

variable "where_filter" {
  default     = ""
  description = "This identifies any Infrastructure host filters used; for example: hostname LIKE '%test%'."
}

variable "runbook_url" {
  default     = ""
  description = "Runbook URL to display in notifications."
}

variable "enabled" {
  default     = "true"
  description = "Whether the alert condition is turned on or off. Valid values are true and false. Defaults to true."
}

variable "duration" {
  default     = ""
  description = "Identifies the number of minutes the threshold must be passed or met for the alert to trigger. Threshold durations must be between 1 and 60 minutes."
}

variable "value" {
  default     = ""
  description = "The threshold value."
}

variable "time_function" {
  default     = ""
  description = "Indicates if the condition needs to be sustained or to just break the threshold once; all or any."
}

resource "newrelic_infra_alert_condition" "alert_condition" {
  policy_id            = var.policy_id
  name                 = var.alert_name
  type                 = var.alert_type
  integration_provider = var.integration_provider
  select               = var.select_target
  comparison           = var.comparison
  where                = var.where_filter
  runbook_url          = var.runbook_url
  enabled              = var.enabled

  critical {
    duration      = var.duration
    value         = var.value
    time_function = var.time_function
  }


}
