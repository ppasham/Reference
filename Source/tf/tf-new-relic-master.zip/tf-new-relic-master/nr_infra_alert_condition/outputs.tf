# Infrastructure Alert Condition ID

output "id" {
  value       = newrelic_infra_alert_condition.alert_condition.id
  description = "The new alert condition id"
}
