#-------------------------------------------------------------------------------
# Smart NewRelic Policy with Channels
#
###########################################################################################
# Module maintainer: CMS Platform Engineering Services                                    #
# Contact: CMS-SuperSmashCrew@coxautoinc.com                                              #
#                                                                                         #
# Description: Terraform New Relic Infrastructure Alert Creation                          #
# README: https://ghe.coxautoinc.com/cms-terraform/tf-new-relic/blob/master/README.md     #
# ___________________                                                                     #
#                                                                                         #
#  Copyright 2019 Cox Automotive Incorporated                                             #
#  All Rights Reserved.                                                                   #
#                                                                                         #
###########################################################################################


terraform {
  required_providers {
    newrelic = {
      source = "newrelic/newrelic"
    }
  }
  required_version = ">= 0.13"
}

variable "policy_name" {
  description = "The name of the NR policy"
}

variable "incident_preference" {
  default     = "PER_CONDITION"
  description = "The rollup strategy for the policy. Options include: PER_POLICY, PER_CONDITION, or PER_CONDITION_AND_TARGET."
}

variable "email_recipients" {
  description = "Optional: Comma delimited list of email addresses."
}

variable "pagerduty_service_key" {
  default     = null
  description = "Optional: Specifies the service key for integrating with Pagerduty."
}

variable "teams_webhook_url" {
  default     = null
  description = "Optional: The webhook URL of the teams channel"
}

locals {
  policy_name          = var.policy_name
  email_channel_name   = "${local.policy_name} - Email Notifications"
  email_resource_count = var.email_recipients == null ? 0 : (length(var.email_recipients) > 0 ? 1 : 0)

  teams_channel_name   = "${local.policy_name} - Teams Notifications"
  teams_resource_count = var.teams_webhook_url == null ? 0 : (length(var.teams_webhook_url) > 0 ? 1 : 0)

  pagerduty_channel_name   = "${local.policy_name} - Pagerduty Notifications"
  pagerduty_resource_count = var.pagerduty_service_key == null ? 0 : (length(var.pagerduty_service_key) > 0 ? 1 : 0)
}

resource "newrelic_alert_policy" "policy" {
  name                = local.policy_name
  incident_preference = var.incident_preference
}

# Create email channel if there are recipients
resource "newrelic_notification_destination" "email_destination" {
  count = local.email_resource_count
  name  = local.email_channel_name
  type  = "EMAIL"

  property {
    key   = "email"
    value = var.email_recipients
  }
}

resource "newrelic_notification_channel" "email_channel" {
  count          = local.email_resource_count
  name           = local.email_channel_name
  type           = "EMAIL"
  destination_id = newrelic_notification_destination.email_destination.0.id
  product        = "IINT"

  property {
    key   = "subject"
    value = "{{ issueTitle }} - Issue {{issueId}}"
  }
}

resource "newrelic_notification_destination" "teams_destination" {
  count = local.teams_resource_count
  name  = local.teams_channel_name
  type  = "WEBHOOK"

  property {
    key   = "url"
    value = var.teams_webhook_url
  }
}

// Create a notification channel to use in the workflow
resource "newrelic_notification_channel" "teams_channel" {
  count          = local.teams_resource_count
  name           = local.teams_channel_name
  type           = "WEBHOOK"
  destination_id = newrelic_notification_destination.teams_destination.0.id
  product        = "IINT"

  property {
    key   = "payload"
    value = <<EOF
      {
        "text" : "{{escape issueTitle}}",
        "title" : "New Relic Alert: {{escape accumulations.conditionName.[0]}} in {{escape accumulations.policyName.[0]}}"
      }
    EOF
    label = "Payload Template"
  }
}

resource "newrelic_notification_destination" "pagegduty_destination" {
  count = local.pagerduty_resource_count
  name  = local.pagerduty_channel_name
  type  = "PAGERDUTY_SERVICE_INTEGRATION"

  property {
    key   = "two_way_integration"
    value = "true"
  }

  auth_token {
    prefix = "Token token="
    token  = var.pagerduty_service_key
  }
}

resource "newrelic_notification_channel" "pagerduty_channel" {
  count          = local.pagerduty_resource_count
  name           = local.pagerduty_channel_name
  type           = "PAGERDUTY_SERVICE_INTEGRATION"
  destination_id = newrelic_notification_destination.pagegduty_destination.0.id
  product        = "IINT"

  property {
    key   = "summary"
    value = "{{ annotations.title.[0] }}"
  }
}


resource "newrelic_workflow" "policy_workflow" {
  name                  = local.policy_name
  muting_rules_handling = "NOTIFY_ALL_ISSUES"

  issues_filter {
    name = "Policy Filter"
    type = "FILTER"

    predicate {
      attribute = "labels.policyIds"
      operator  = "EXACTLY_MATCHES"
      values    = [newrelic_alert_policy.policy.id]
    }
  }

  dynamic "destination" {
    for_each = newrelic_notification_channel.email_channel
    content {
      channel_id = destination.value.id
    }
  }

  dynamic "destination" {
    for_each = newrelic_notification_channel.teams_channel
    content {
      channel_id = destination.value.id
    }
  }

  dynamic "destination" {
    for_each = newrelic_notification_channel.pagerduty_channel
    content {
      channel_id = destination.value.id
    }
  }

}