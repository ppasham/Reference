
output "policy_id" {
  value       = newrelic_alert_policy.policy.id
  description = "The new policy id"
}

output "email_channel_id" {
  value = newrelic_notification_channel.email_channel.*.id
}

output "email_destination_id" {
  value = newrelic_notification_destination.email_destination.*.id
}

output "pagerduty_channel_id" {
  value = newrelic_notification_channel.pagerduty_channel.*.id
}

output "pagerduty_destination_id" {
  value = newrelic_notification_destination.pagegduty_destination.*.id
}

output "teams_channel_id" {
  value = newrelic_notification_channel.teams_channel.*.id
}

output "teams_destination_id" {
  value = newrelic_notification_destination.teams_destination.*.id
}
