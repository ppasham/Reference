output "monitor_id" {
  value       = newrelic_synthetics_monitor.uptime.id
  description = "The new monitor id"
}