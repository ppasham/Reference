#-------------------------------------------------------------------------------
# New Relic Workload
#
###########################################################################################
# Module maintainer: CMS Platform Engineering Services                                    #
# Contact: CMS-SuperSmashCrew@coxautoinc.com                                              #
#                                                                                         #
# Description: Terraform New Relic Workload Creation.                                     #
# README: https://ghe.coxautoinc.com/cms-terraform/tf-new-relic/blob/master/README.md     #
# ___________________                                                                     #
#                                                                                         #
#  Copyright 2021 Cox Automotive Incorporated                                             #
#  All Rights Reserved.                                                                   #
#                                                                                         #
###########################################################################################


terraform {
  required_providers {
    newrelic = {
      source = "newrelic/newrelic"
    }
  }
  required_version = ">= 0.13"
}

variable "policy_id" {
  description = "The ID of the policy to connect the synthetic monitor to."
  type        = number
}

variable "runbook_url" {
  default     = null
  type        = string
  description = "Runbook URL to display in notifications."
}

variable "name" {
  type        = string
  description = "The human-readable identifier for the synthetic monitor."
}

variable "period" {
  type        = string
  default     = "EVERY_5_MINUTES"
  description = "The interval at which this monitor should run. Valid values are EVERY_MINUTE, EVERY_5_MINUTES, EVERY_10_MINUTES, EVERY_15_MINUTES, EVERY_30_MINUTES, EVERY_HOUR, EVERY_6_HOURS, EVERY_12_HOURS, or EVERY_DAY."
}

variable "uri" {
  type        = string
  description = "The URI the monitor runs against."
}

variable "custom_headers" {
  default     = {}
  type        = map(string)
  description = "Custom headers to use when accessing monitor on var.uri"
}

variable "validation_string" {
  default     = null
  type        = string
  description = "Validation text for monitor to search for at var.uri"
}

variable "verify_ssl" {
  default     = null
  type        = bool
  description = "Monitor should validate SSL certificate chain."
}

variable "type" {
  description = "The monitor type. Valid values are SIMPLE and BROWSER"
  default     = "SIMPLE"
}

variable "locations" {
  default     = ["US_WEST_2", "US_EAST_1"]
  description = "The locations the monitor will run from. Valid public locations are https://docs.newrelic.com/docs/synthetics/synthetic-monitoring/administration/synthetic-public-minion-ips/."
}

variable "extra_locations" {
  default     = null
  description = "The location the monitor will run from. Accepts a list of private location GUIDs."
  nullable    = true
}

variable "tags" {
  default     = {}
  type        = map(string)
  description = "The tags that will be associated with the monitor."
}

// Create alert condition with NRQL. This works but not as good as newrelic_synthetics_alert_condition
variable "use_nrql" {
  default     = false
  type        = bool
  description = "Use NRQL to generate alert condition"
}

resource "newrelic_synthetics_monitor" "uptime" {
  status            = "ENABLED"
  name              = var.name
  period            = var.period
  uri               = var.uri
  type              = var.type
  locations_public  = var.locations
  locations_private = var.extra_locations
  verify_ssl        = var.verify_ssl

  dynamic "tag" {
    for_each = var.tags
    content {
      key    = tag.key
      values = [tag.value]
    }
  }

  dynamic "custom_header" {
    for_each = var.custom_headers
    content {
      name  = custom_header.key
      value = custom_header.value
    }
  }
}

resource "newrelic_synthetics_alert_condition" "uptime" {
  count       = var.use_nrql ? 0 : 1
  policy_id   = var.policy_id
  name        = "${var.name} Alert Condition"
  monitor_id  = newrelic_synthetics_monitor.uptime.id
  runbook_url = var.runbook_url
}

resource "newrelic_nrql_alert_condition" "uptime" {
  count       = var.use_nrql ? 1 : 0
  policy_id   = var.policy_id
  name        = "${var.name} Alert Condition"
  runbook_url = var.runbook_url

  nrql {
    query = "SELECT filter(count(*), WHERE result = 'FAILED') FROM SyntheticCheck WHERE NOT isMuted AND entityGuid IN ('${newrelic_synthetics_monitor.uptime.id}') FACET entityGuid, location"
  }

  critical {
    operator              = "above"
    threshold             = 0
    threshold_duration    = 60
    threshold_occurrences = "at_least_once"
  }
}