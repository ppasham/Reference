## Notes
Got the example to work successfully make sure to have NR credentials in the shell environment.

```bash
env | grep NEW
NEW_RELIC_ACCOUNT_ID=2767861
NEW_RELIC_API_KEY=NRAK-25Z...TLM
```