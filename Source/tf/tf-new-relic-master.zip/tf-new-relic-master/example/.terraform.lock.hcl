# This file is maintained automatically by "terraform init".
# Manual edits may be lost in future updates.

provider "registry.terraform.io/newrelic/newrelic" {
  version = "3.30.0"
  hashes = [
    "h1:BAXl4XHFa9msWubTRvCnbq4YgDl2dxrHQ6TnO4F5ORY=",
    "zh:02be544ecb45dcb8c6ce815806a00848bec05bb565ae1ee7c1c3a4f66cc6f313",
    "zh:491ed716ca482a1dce56fd6291978bab3d249c6f8f6c5b728322859ba7802587",
    "zh:51034e6c72422c0d75155a1adba029d4553726dfd43bf0ed67531587f2cc614d",
    "zh:5c0bb0171dbd9c173e3fd17b517510c1335af3b60c8874a7ed7d5319c7af679d",
    "zh:71a38db14317c6ea0c305d8ec7cef2bf479257444f5c221b1b34c09b25ace51c",
    "zh:7ca20f6d82fd8ae2047e0fc0801d5f7055d9173b145a41117095456954f37020",
    "zh:7dabce6ead7d6076dbde4994a80fcf92a86c61dabe7f8d065c8abe320b592c6e",
    "zh:7e5d0a153586576988e8ed90745c05eee633dcba4109e75d899b14a6a3c317b4",
    "zh:99e26ca1e53fc680b1a6a0c7c61fa14ba79b9c2f34d4c48fbd1948f415ad7825",
    "zh:a5fae85f33bb483d56ded994f7291ff9dc4e895f2e6fa146bb7d1ba94e8f29e6",
    "zh:a80b7a6baf317b0475495efde0d6eed96c265b9f084cfced7c66cc8f5e258264",
    "zh:ab1aa20334c0ba933d3d7edb53fdfef86e96c4fe44d89f1f2f943557e266e520",
    "zh:b1f25f5d73a85535e059073a7bb084c65ed892c2e5dc26edf1854ad35bcf8757",
    "zh:e8b8f176bd50ab49819cbc93a63c20b4b39294175b13b06c7b76f368180ea4e6",
    "zh:e99f69175a52c6baba6c42c5555ef8ccd7157abb9c29f6ad2802b6f9c33f3aa6",
    "zh:f301a1457eb15c2bc9c2f68c8a0feb7c08a597ebbb591b79bc4fa743f436e491",
    "zh:fbd1fee2c9df3aa19cf8851ce134dea6e45ea01cb85695c1726670c285797e25",
    "zh:ff0ea5860286867c34b0c82621268d4fd2c901bf5e1eebe4a8827f3271bd1f6d",
  ]
}
