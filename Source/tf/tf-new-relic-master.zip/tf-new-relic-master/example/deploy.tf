# New Relic Terraform Module

terraform {
  required_providers {
    newrelic = {
      source = "newrelic/newrelic"
    }
  }
  required_version = ">= 0.13"
}

# Providers
provider "newrelic" {
  # Credentials are to be provided via env variables
  # https://registry.terraform.io/providers/newrelic/newrelic/latest/docs/guides/provider_configuration
  # declare -x NEW_RELIC_ACCOUNT_ID="2767861"
  # declare -x NEW_RELIC_API_KEY="NRAK-...."
  account_id = var.new_relic_account_id
  api_key    = var.new_relic_api_key
}

# Variables
variable "policy_name" {
  default     = "Test Policy Example"
  description = "The name of the policy"
}

variable "incident_preference" {
  default     = "PER_CONDITION"
  description = "The rollup strategy for the policy. Options include: PER_POLICY, PER_CONDITION, or PER_CONDITION_AND_TARGET. The default is PER_POLICY"
}


variable "recipients" {
  default     = "CMS-SuperSmashCrew@coxautoinc.com"
  description = "The email of each recipient for the alert"
}

variable "runbook_url" {
  default     = "https://runbookurl.com"
  description = "Runbook URL to display in notifications."
}

variable "locations" {
  default     = ["AWS_US_EAST_1", "AWS_US_WEST_1"]
  description = "Locations for script execution. Defaults to east and west coast AWS"
}

variable "health_url" {
  default     = "https://postman-echo.com/get"
  description = "The health url to use in the synthetics script"
}

variable "secret_key" {
  default     = "1234321"
  description = "The secret key to be used in the synthetics script"
}

variable "new_relic_account_id" {
  default     = "2767861"
  description = "NR Account ID: 2767861 - DealerTrack CMS NonProd, 1842316 - DealerTrack CMS Prod. If null, NEW_RELIC_ACCOUNT_ID env. variable is used instead"
}

variable "new_relic_api_key" {
  default     = null
  description = "NR API key. If null, NEW_RELIC_API_KEY env. variable is used instead"
}

variable "environment" {
  default = "NP"
}

variable "product" {
  default = "SAMPLE"
}

locals {
  tags = {
    Product     = var.product
    Environment = var.environment
  }
}

data "newrelic_account" "acc" {}

module "combined_policy_example" {
  source                = "../nr_alert_policy_and_channels"
  policy_name           = var.policy_name
  email_recipients      = var.recipients
  pagerduty_service_key = "FAKE"
  teams_webhook_url     = "https://fake.com"
}

module "combined_policy_example_min" {
  source           = "../nr_alert_policy_and_channels"
  policy_name      = "${var.policy_name}_min"
  email_recipients = "aaa@aaa.com"
}


# Infrastructure Alert Condition Creation
module "infra_alert_example" {
  source               = "../nr_infra_alert_condition"
  policy_id            = module.combined_policy_example.policy_id
  alert_name           = "Example_Infra_Alert"
  alert_type           = "infra_metric"
  integration_provider = "SqsQueue"
  select_target        = "provider.approximateNumberOfMessagesVisible.Sum"
  comparison           = "above"
  where_filter         = "hostname LIKE '%test%'"
  runbook_url          = var.runbook_url
  enabled              = "true"
  duration             = "60"
  value                = "0"
  time_function        = "all"
}



module "synthetics_monitor_example" {
  source      = "../nr_synthetic_check"
  policy_id   = module.combined_policy_example.policy_id
  name        = "Test Synthetics Check"
  uri         = var.health_url
  runbook_url = var.runbook_url
  tags        = local.tags
  custom_headers = {
    "API-Key" : "SOME_KEY"
  }
}



module "nr_workload" {
  source               = "../nr_workload"
  new_relic_account_id = data.newrelic_account.acc.account_id
  workload_name        = "Test Workload"
  entity_names         = ["Testing", "One", "Something"]
  resource_tags = {
    Environment = [var.environment, lower(var.environment)]
    Product     = [var.product]
  }
  entity_search_queries = ["`tags.label.Project` = '${var.product}'"]
  entity_guids          = [module.synthetics_monitor_example.monitor_id]
  scope_account_ids     = [data.newrelic_account.acc.account_id]
}


output "nr_workload_permalink" {
  value = module.nr_workload.permalink
}

output "nr_workload_composite_entity_search_query" {
  value = module.nr_workload.composite_entity_search_query
}

