# tf-lambda
CMS New Relic Terraform Modules

## Description
Terraform modules that help with creating New Relic resources related to monitoring of applications and services

## Usage

See [example](example/deploy.tf) for sample usage.

## Modules

This repository includes following modules.

### New Relic Alert Policy

Creates a New Relic [alert policy](https://docs.newrelic.com/docs/alerts-applied-intelligence/overview/#concepts-terms) and 
[workflow](https://docs.newrelic.com/docs/alerts-applied-intelligence/applied-intelligence/incident-workflows/incident-workflows/) 
Also conditionally created notification [destinations](https://docs.newrelic.com/docs/alerts-applied-intelligence/notifications/destinations/) and channels based on variables supplied. 
For example if `email_recipients` is provided then it will generate an email destination for alerts.  

```hcl

module "combined_policy_example" {
  source                = "git@ghe.coxautoinc.com:cms-terraform/tf-new-relic.git//nr_alert_policy_and_channels?ref=v.2.0.0"
  policy_name           = "The Best Policy"
  email_recipients      = "me@gmail.com"
  pagerduty_service_key = "FAKE"
  teams_webhook_url     = "https://fake.com"
}

```

<!-- BEGIN_TF_DOCS_POLICY_COMBINED -->
#### Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >= 0.13 |

#### Providers

| Name | Version |
|------|---------|
| <a name="provider_newrelic"></a> [newrelic](#provider\_newrelic) | n/a |

#### Modules

No modules.

#### Resources

| Name | Type |
|------|------|
| [newrelic_alert_policy.policy](https://registry.terraform.io/providers/newrelic/newrelic/latest/docs/resources/alert_policy) | resource |
| [newrelic_notification_channel.email_channel](https://registry.terraform.io/providers/newrelic/newrelic/latest/docs/resources/notification_channel) | resource |
| [newrelic_notification_channel.pagerduty_channel](https://registry.terraform.io/providers/newrelic/newrelic/latest/docs/resources/notification_channel) | resource |
| [newrelic_notification_channel.teams_channel](https://registry.terraform.io/providers/newrelic/newrelic/latest/docs/resources/notification_channel) | resource |
| [newrelic_notification_destination.email_destination](https://registry.terraform.io/providers/newrelic/newrelic/latest/docs/resources/notification_destination) | resource |
| [newrelic_notification_destination.pagegduty_destination](https://registry.terraform.io/providers/newrelic/newrelic/latest/docs/resources/notification_destination) | resource |
| [newrelic_notification_destination.teams_destination](https://registry.terraform.io/providers/newrelic/newrelic/latest/docs/resources/notification_destination) | resource |
| [newrelic_workflow.policy_workflow](https://registry.terraform.io/providers/newrelic/newrelic/latest/docs/resources/workflow) | resource |

#### Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_email_recipients"></a> [email\_recipients](#input\_email\_recipients) | Optional: Comma delimited list of email addresses. | `any` | n/a | yes |
| <a name="input_incident_preference"></a> [incident\_preference](#input\_incident\_preference) | The rollup strategy for the policy. Options include: PER\_POLICY, PER\_CONDITION, or PER\_CONDITION\_AND\_TARGET. | `string` | `"PER_CONDITION"` | no |
| <a name="input_pagerduty_service_key"></a> [pagerduty\_service\_key](#input\_pagerduty\_service\_key) | Optional: Specifies the service key for integrating with Pagerduty. | `any` | `null` | no |
| <a name="input_policy_name"></a> [policy\_name](#input\_policy\_name) | The name of the NR policy | `any` | n/a | yes |
| <a name="input_teams_webhook_url"></a> [teams\_webhook\_url](#input\_teams\_webhook\_url) | Optional: The webhook URL of the teams channel | `any` | `null` | no |

#### Outputs

| Name | Description |
|------|-------------|
| <a name="output_email_channel_id"></a> [email\_channel\_id](#output\_email\_channel\_id) | n/a |
| <a name="output_email_destination_id"></a> [email\_destination\_id](#output\_email\_destination\_id) | n/a |
| <a name="output_pagerduty_channel_id"></a> [pagerduty\_channel\_id](#output\_pagerduty\_channel\_id) | n/a |
| <a name="output_pagerduty_destination_id"></a> [pagerduty\_destination\_id](#output\_pagerduty\_destination\_id) | n/a |
| <a name="output_policy_id"></a> [policy\_id](#output\_policy\_id) | The new policy id |
| <a name="output_teams_channel_id"></a> [teams\_channel\_id](#output\_teams\_channel\_id) | n/a |
| <a name="output_teams_destination_id"></a> [teams\_destination\_id](#output\_teams\_destination\_id) | n/a |
<!-- END_TF_DOCS_POLICY_COMBINED -->

### New Relic Synthetic Check

Simple synthetic monitor that check URL for 200 response. It also connects the monitor to a policy from `policy_id` variable.

```hcl
module "synthetics_monitor" {
  source    = "git@ghe.coxautoinc.com:cms-terraform/tf-new-relic.git//nr_synthetic_check?ref=v.2.0.0"
  policy_id = "Policy_GUID"
  name      = "Test Synthetics Check"
  uri       = "https://postman-echo.com/get"
  runbook_url = "http://runbook.com"
  tags = {
    Identifier: "Test Synthetics Check"
  }
  custom_headers = {
    "API-Key": "SOME_KEY"
  }
}
```

<!-- BEGIN_TF_DOCS_CHECK -->
#### Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >= 0.13 |

#### Providers

| Name | Version |
|------|---------|
| <a name="provider_newrelic"></a> [newrelic](#provider\_newrelic) | n/a |

#### Modules

No modules.

#### Resources

| Name | Type |
|------|------|
| [newrelic_nrql_alert_condition.uptime](https://registry.terraform.io/providers/newrelic/newrelic/latest/docs/resources/nrql_alert_condition) | resource |
| [newrelic_synthetics_alert_condition.uptime](https://registry.terraform.io/providers/newrelic/newrelic/latest/docs/resources/synthetics_alert_condition) | resource |
| [newrelic_synthetics_monitor.uptime](https://registry.terraform.io/providers/newrelic/newrelic/latest/docs/resources/synthetics_monitor) | resource |

#### Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_custom_headers"></a> [custom\_headers](#input\_custom\_headers) | Custom headers to use when accessing monitor on var.uri | `map(string)` | `{}` | no |
| <a name="input_extra_locations"></a> [extra\_locations](#input\_extra\_locations) | The location the monitor will run from. Accepts a list of private location GUIDs. | `any` | `null` | no |
| <a name="input_locations"></a> [locations](#input\_locations) | The locations the monitor will run from. Valid public locations are https://docs.newrelic.com/docs/synthetics/synthetic-monitoring/administration/synthetic-public-minion-ips/. | `list` | <pre>[<br>  "US_WEST_2",<br>  "US_EAST_1"<br>]</pre> | no |
| <a name="input_name"></a> [name](#input\_name) | The human-readable identifier for the synthetic monitor. | `string` | n/a | yes |
| <a name="input_period"></a> [period](#input\_period) | The interval at which this monitor should run. Valid values are EVERY\_MINUTE, EVERY\_5\_MINUTES, EVERY\_10\_MINUTES, EVERY\_15\_MINUTES, EVERY\_30\_MINUTES, EVERY\_HOUR, EVERY\_6\_HOURS, EVERY\_12\_HOURS, or EVERY\_DAY. | `string` | `"EVERY_5_MINUTES"` | no |
| <a name="input_policy_id"></a> [policy\_id](#input\_policy\_id) | The ID of the policy to connect the synthetic monitor to. | `number` | n/a | yes |
| <a name="input_runbook_url"></a> [runbook\_url](#input\_runbook\_url) | Runbook URL to display in notifications. | `string` | `null` | no |
| <a name="input_tags"></a> [tags](#input\_tags) | The tags that will be associated with the monitor. | `map(string)` | `{}` | no |
| <a name="input_type"></a> [type](#input\_type) | The monitor type. Valid values are SIMPLE and BROWSER | `string` | `"SIMPLE"` | no |
| <a name="input_uri"></a> [uri](#input\_uri) | The URI the monitor runs against. | `string` | n/a | yes |
| <a name="input_use_nrql"></a> [use\_nrql](#input\_use\_nrql) | Use NRQL to generate alert condition | `bool` | `false` | no |
| <a name="input_validation_string"></a> [validation\_string](#input\_validation\_string) | Validation text for monitor to search for at var.uri | `string` | `null` | no |
| <a name="input_verify_ssl"></a> [verify\_ssl](#input\_verify\_ssl) | Monitor should validate SSL certificate chain. | `bool` | `null` | no |

#### Outputs

| Name | Description |
|------|-------------|
| <a name="output_monitor_id"></a> [monitor\_id](#output\_monitor\_id) | The new monitor id |
<!-- END_TF_DOCS_CHECK -->

### New Relic Infra Alert Condition
Create a New Relic Infrastructure Alert Condition. 

_Notice: This module is being deprecated soon._ 

```hcl
module "infra_alert_example" {
  source               = "git@ghe.coxautoinc.com:cms-terraform/tf-new-relic.git//nr_infra_alert_condition?ref=v.2.0.0"
  policy_id            = "Policy_GUID"
  alert_name           = "Example_Infra_Alert"
  alert_type           = "infra_metric"
  integration_provider = "SqsQueue"
  select_target        = "provider.approximateNumberOfMessagesVisible.Sum"
  comparison           = "above"
  where_filter         = "hostname LIKE '%test%'"
  enabled              = "true"
  duration             = "60"
  value                = "0"
  time_function        = "all"
}
```

<!-- BEGIN_TF_DOCS_INFRA -->
#### Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >= 0.13 |

#### Providers

| Name | Version |
|------|---------|
| <a name="provider_newrelic"></a> [newrelic](#provider\_newrelic) | n/a |

#### Modules

No modules.

#### Resources

| Name | Type |
|------|------|
| [newrelic_infra_alert_condition.alert_condition](https://registry.terraform.io/providers/newrelic/newrelic/latest/docs/resources/infra_alert_condition) | resource |

#### Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_alert_name"></a> [alert\_name](#input\_alert\_name) | The Infrastructure alert condition's name. | `string` | `""` | no |
| <a name="input_alert_type"></a> [alert\_type](#input\_alert\_type) | The type of Infrastructure alert condition. | `string` | `""` | no |
| <a name="input_comparison"></a> [comparison](#input\_comparison) | The operator used to evaluate the threshold value. Valid values are above, below, and equal. | `string` | `""` | no |
| <a name="input_duration"></a> [duration](#input\_duration) | Identifies the number of minutes the threshold must be passed or met for the alert to trigger. Threshold durations must be between 1 and 60 minutes. | `string` | `""` | no |
| <a name="input_enabled"></a> [enabled](#input\_enabled) | Whether the alert condition is turned on or off. Valid values are true and false. Defaults to true. | `string` | `"true"` | no |
| <a name="input_integration_provider"></a> [integration\_provider](#input\_integration\_provider) | The integration provider for the alert condition. | `string` | `""` | no |
| <a name="input_policy_id"></a> [policy\_id](#input\_policy\_id) | Alert Policy ID | `string` | `""` | no |
| <a name="input_runbook_url"></a> [runbook\_url](#input\_runbook\_url) | Runbook URL to display in notifications. | `string` | `""` | no |
| <a name="input_select_target"></a> [select\_target](#input\_select\_target) | The attribute name to identify the metric being targeted. | `string` | `""` | no |
| <a name="input_time_function"></a> [time\_function](#input\_time\_function) | Indicates if the condition needs to be sustained or to just break the threshold once; all or any. | `string` | `""` | no |
| <a name="input_value"></a> [value](#input\_value) | The threshold value. | `string` | `""` | no |
| <a name="input_where_filter"></a> [where\_filter](#input\_where\_filter) | This identifies any Infrastructure host filters used; for example: hostname LIKE '%test%'. | `string` | `""` | no |

#### Outputs

| Name | Description |
|------|-------------|
| <a name="output_id"></a> [id](#output\_id) | The new alert condition id |
<!-- END_TF_DOCS_INFRA -->

### New Relic Workload
This module attempt to make it easier to create workloads that attempt to group AWS resources by tags, but it also supports adding resource by names and via raw New Relic entity queries.

```tf
module "nr_workload" {
  source = "git@ghe.coxautoinc.com:cms-terraform/tf-new-relic.git//nr_workload?ref=v.2.0.0"
  new_relic_account_id = var.new_relic_account_id
  workload_name = "Test Workload"
  entity_names = ["Testing", "One", "Something"]
  resource_tags = {
    Environment = ["NP", "np"]
    Product = ["FXS"]
  }
  entity_search_queries = ["`tags.label.Project` = 'FXS'"]
  entity_guids = ["Mjc2Nzg2MXxJTkZSQXxOQXw3ODkxOTQzOTcxMTQzMzg2MDk0"]
  scope_account_ids = [var.new_relic_account_id]
}
```
See [example](./example/deploy.tf) for more details on possible usage.

<!-- BEGIN_TF_DOCS_WORKLOAD -->
#### Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >= 0.13 |

#### Providers

| Name | Version |
|------|---------|
| <a name="provider_newrelic"></a> [newrelic](#provider\_newrelic) | n/a |

#### Modules

No modules.

#### Resources

| Name | Type |
|------|------|
| [newrelic_workload.load](https://registry.terraform.io/providers/newrelic/newrelic/latest/docs/resources/workload) | resource |
| [newrelic_account.acc](https://registry.terraform.io/providers/newrelic/newrelic/latest/docs/data-sources/account) | data source |

#### Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_entity_guids"></a> [entity\_guids](#input\_entity\_guids) | (Optional) A list of NR entity GUIDs manually assigned to this workload. | `list(string)` | `[]` | no |
| <a name="input_entity_names"></a> [entity\_names](#input\_entity\_names) | (Optional) A list of NR entity names to be assigned to this workload. | `list(string)` | `[]` | no |
| <a name="input_entity_search_queries"></a> [entity\_search\_queries](#input\_entity\_search\_queries) | (Optional) A list of raw NR query strings as defined in<br>https://registry.terraform.io/providers/newrelic/newrelic/latest/docs/resources/workload#nested-entity_search_query-blocks | `list(string)` | `[]` | no |
| <a name="input_new_relic_account_id"></a> [new\_relic\_account\_id](#input\_new\_relic\_account\_id) | (Required) The New Relic account ID where you want to create the workload. | `any` | n/a | yes |
| <a name="input_resource_tags"></a> [resource\_tags](#input\_resource\_tags) | (Optional) Tag name and values as a list to identify AWS resources to be added to the new NR workload.<br><br>Example: if value is {Environment: ['NP', 'np', 'non-prod'], Product: ['SMX']} then resources that have<br>these tags with values matching any of the ones specified in the lists will be part of the workload | `map(list(string))` | `{}` | no |
| <a name="input_scope_account_ids"></a> [scope\_account\_ids](#input\_scope\_account\_ids) | (Optional) A list of account IDs that will be used to get entities from. | `list` | `[]` | no |
| <a name="input_workload_name"></a> [workload\_name](#input\_workload\_name) | (Required) The workload's name. | `any` | n/a | yes |

#### Outputs

| Name | Description |
|------|-------------|
| <a name="output_all_entity_search_queries"></a> [all\_entity\_search\_queries](#output\_all\_entity\_search\_queries) | Combined search query used to gather the workload resources |
| <a name="output_composite_entity_search_query"></a> [composite\_entity\_search\_query](#output\_composite\_entity\_search\_query) | n/a |
| <a name="output_guid"></a> [guid](#output\_guid) | The new workload GUID |
| <a name="output_permalink"></a> [permalink](#output\_permalink) | Permalink to the new workload |
| <a name="output_workload_id"></a> [workload\_id](#output\_workload\_id) | The new workload id |
<!-- END_TF_DOCS_WORKLOAD -->

## Contributions

Add additions and changes to the module should follow the [Terraform Module Development Guide](https://pages.ghe.coxautoinc.com/CMS-PE/Knowledge-Base/Terraform/Development_Guide.html).

To make sure Terraform files are properly formatted run this command
```bash
terraform fmt -recursive
```

To make sure changes in Terraform files are documented run this command. (Make sure to have `terraform-docs` command on PATH)
```bash
find . -type d -iname "nr_*" | xargs --max-lines=1 terraform-docs
```


## References