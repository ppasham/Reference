# Terraform SQS Queue Policy Deployment Script

terraform {
  required_version = ">= 0.12"
}

# Variables
variable "region" {
}

variable "queue_id" {
  default     = "example_policy"
  description = "The ID of the sqs queue."
}

variable "policy_file_name" {
  default     = "example_policy.json"
  description = "The name of the policy json file."
}

variable "resource_arn" {
  default     = "arn:aws:s3:::my-s3-bucket"
  description = "arn of resource to allow permissions within the policy. This is a variable that will be used in the resource setting in the json file. e.g. arn:aws:s3:::my-s3-bucket or arn:aws:s3:::*/*"
}

# AWS Provider
provider "aws" {
  region = var.region
}

# S3 Backend
terraform {
  backend "s3" {
  }
}

# SQS Queue Policy Creation
module "example_sqs_policy" {
  source           = "git@ghe.coxautoinc.com:cms-terraform/tf-sqs.git//sqs_queue_policy"
  queue_id         = var.queue_id
  policy_file_name = var.policy_file_name
  resource_arn     = var.resource_arn
}
