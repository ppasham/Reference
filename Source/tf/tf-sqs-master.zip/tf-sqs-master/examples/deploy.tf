# Terraform SQS Queue Deployment Script

terraform {
  required_version = ">= 0.12"
}

# Variables
/* variable "region" {
  default = "us-west-2"
} */

variable "queue_name" {
  default     = "example_queue"
  description = "This is the human-readable name of the queue. If omitted, Terraform will assign a random name."
}

variable "visibility_timeout_seconds" {
  default     = "30"
  description = "The visibility timeout for the queue. An integer from 0 to 43200 (12 hours)"
}

variable "message_retention_seconds" {
  default     = "345600"
  description = "The number of seconds Amazon SQS retains a message. Integer representing seconds, from 60 (1 minute) to 1209600 (14 days)"
}

variable "max_message_size" {
  default     = "262144"
  description = "The limit of how many bytes a message can contain before Amazon SQS rejects it. An integer from 1024 bytes (1 KiB) up to 262144 bytes (256 KiB)"
}

variable "delay_seconds" {
  default     = "0"
  description = "The time in seconds that the delivery of all messages in the queue will be delayed. An integer from 0 to 900 (15 minutes)"
}

variable "receive_wait_time_seconds" {
  default     = "0"
  description = "The time for which a ReceiveMessage call will wait for a message to arrive (long polling) before returning. An integer from 0 to 20 (seconds)"
}

variable "policy" {
  default     = "example_policy"
  description = "The JSON policy for the SQS queue"
}

variable "dlq_max_receive_count" {
  default     = 4
  description = "The Dead Letter Queue max receive count"
}

variable "dlq_queue_arn" {
  default     = "arn:aws:sqs:us-west-2:444455556666:example_queue"
  description = "For example purpose, this variable will not exist. replace this inline with module.example_queue_dlq.arn"
}

variable "fifo_queue" {
  default     = false
  description = "Boolean designating a FIFO queue"
}

variable "content_based_deduplication" {
  default     = false
  description = "Enables content-based deduplication for FIFO queues"
}

variable "kms_master_key_id" {
  default     = "coxauto_master_key"
  description = "The ID of an AWS-managed customer master key (CMK) for Amazon SQS or a custom CMK"
}

variable "kms_data_key_reuse_period_seconds" {
  default     = "300"
  description = "The length of time, in seconds, for which Amazon SQS can reuse a data key to encrypt or decrypt messages before calling AWS KMS again."
}

variable "tags" {
  type        = map(string)
  description = "A mapping of tags to assign to all resources"
  default     = { "environment" : "non-prod", "owner" : "example_owner" }
}

# AWS Provider
/* provider "aws" {
  region = var.region
} */

# S3 Backend
/* terraform {
  backend "s3" {
  }
} */

# SQS Queue Creation
module "example_queue" {
  source                            = "git@ghe.coxautoinc.com:cms-terraform/tf-sqs.git//queue"
  queue_name                        = var.queue_name
  visibility_timeout_seconds        = var.visibility_timeout_seconds
  message_retention_seconds         = var.message_retention_seconds
  max_message_size                  = var.max_message_size
  delay_seconds                     = var.delay_seconds
  receive_wait_time_seconds         = var.receive_wait_time_seconds
  policy                            = var.policy
  fifo_queue                        = var.fifo_queue
  content_based_deduplication       = var.content_based_deduplication
  kms_master_key_id                 = var.kms_master_key_id
  kms_data_key_reuse_period_seconds = var.kms_data_key_reuse_period_seconds
  tags                              = var.tags
}

# SQS Queue with Dead Letter Queue Creation
module "example_queue_dlq" {
  source                            = "git@ghe.coxautoinc.com:cms-terraform/tf-sqs.git//queue_with_dlq"
  queue_name                        = var.queue_name
  visibility_timeout_seconds        = var.visibility_timeout_seconds
  message_retention_seconds         = var.message_retention_seconds
  max_message_size                  = var.max_message_size
  delay_seconds                     = var.delay_seconds
  receive_wait_time_seconds         = var.receive_wait_time_seconds
  policy                            = var.policy
  dlq_queue_arn                     = var.dlq_queue_arn
  dlq_max_receive_count             = var.dlq_max_receive_count
  fifo_queue                        = var.fifo_queue
  content_based_deduplication       = var.content_based_deduplication
  kms_master_key_id                 = var.kms_master_key_id
  kms_data_key_reuse_period_seconds = var.kms_data_key_reuse_period_seconds
  tags                              = var.tags
}
