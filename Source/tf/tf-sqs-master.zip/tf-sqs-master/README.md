# tf-sqs
AWS SQS Queue Terraform Module

## Description

### Queue and DLQ Queue
AWS SQS Queue resource is used to create SQS Queues.

### Queue Policy
AWS SQS Queue policy is used to create policies for access to SQS queues.

## Usage

### Queue

```tf
resource "aws_sqs_queue" "queue" {
  name                              = var.queue_name
  visibility_timeout_seconds        = var.visibility_timeout_seconds
  message_retention_seconds         = var.message_retention_seconds
  max_message_size                  = var.max_message_size
  delay_seconds                     = var.delay_seconds
  receive_wait_time_seconds         = var.receive_wait_time_seconds
  policy                            = var.policy
  fifo_queue                        = var.fifo_queue
  content_based_deduplication       = var.content_based_deduplication

  kms_master_key_id                 = var.kms_master_key_id
  kms_data_key_reuse_period_seconds = var.kms_data_key_reuse_period_seconds

  tags                              = var.tags
}
```

Conditions applied in this module have the following set:


Value                             | Type     | Forces New | Value Type | Description
--------------------------------- | -------- | ---------- | ---------- | -----------
`name`                           | Optional | yes        | string     | This is the human-readable name of the queue.
`visibility_timeout_seconds`                           | Optional | no        | integer     | The visibility timeout for the queue. An integer from 0 to 43200 (12 hours). The default for this attribute is 30.
`message_retention_seconds`                           | Optional | no        | integer     | The number of seconds Amazon SQS retains a message. Integer representing seconds, from 60 (1 minute) to 1209600 (14 days).
`max_message_size`                           | Optional | no        | integer    | The limit of how many bytes a message can contain before Amazon SQS rejects it. An integer from 1024 bytes (1 KiB) up to 262144 bytes (256 KiB).
`delay_seconds`                           | Optional | no        | integer     | The time in seconds that the delivery of all messages in the queue will be delayed. An integer from 0 to 900 (15 minutes).
`receive_wait_time_seconds`                           | Optional | no       | integer     | The time for which a ReceiveMessage call will wait for a message to arrive (long polling) before returning. An integer from 0 to 20 (seconds).
`policy` | Optional | no | string | The JSON policy for the SQS queue.
`arn` | Computed | n/a | string | Provides ARN of queue that was created.
`id` | Computed | n/a | string | Provides ID of queue that was created.
`fifo_queue` | Optional | yes | bool | Boolean designating a FIFO queue.
`content_based_deduplication` | Optional | yes | bool | Enables content-based deduplication for FIFO queues.
`kms_master_key_id ` | Optional | yes | string | The ID of an AWS-managed customer master key (CMK) for Amazon SQS or a custom CMK.
`kms_data_key_reuse_period_seconds` | Optional | yes | integer | The length of time, in seconds, for which Amazon SQS can reuse a data key to encrypt or decrypt messages before calling AWS KMS again. An integer representing seconds, between 60 seconds (1 minute) and 86,400 seconds (24 hours).
`tags`                           | Optional | no        | map    | A mapping of tags to assign to the queue.


### Queue with Dead Letter Queue

```tf
resource "aws_sqs_queue" "queue" {
  name                              = var.queue_name
  visibility_timeout_seconds        = var.visibility_timeout_seconds
  message_retention_seconds         = var.message_retention_seconds
  max_message_size                  = var.max_message_size
  delay_seconds                     = var.delay_seconds
  receive_wait_time_seconds         = var.receive_wait_time_seconds
  policy                            = var.policy
  redrive_policy                    = "{\"deadLetterTargetArn\":\"${var.dlq_queue_arn}\",\"maxReceiveCount\":${var.dlq_max_receive_count}}"
  fifo_queue                        = var.fifo_queue
  content_based_deduplication       = var.content_based_deduplication

  kms_master_key_id                 = var.kms_master_key_id
  kms_data_key_reuse_period_seconds = var.kms_data_key_reuse_period_seconds

  tags                              = var.tags
}
```

Conditions applied in this module have the following set:

Value                             | Type     | Forces New | Value Type | Description
--------------------------------- | -------- | ---------- | ---------- | -----------
`name`                           | Optional | yes        | string     | This is the human-readable name of the queue.
`visibility_timeout_seconds`                           | Optional | no        | integer     | The visibility timeout for the queue. An integer from 0 to 43200 (12 hours). The default for this attribute is 30.
`message_retention_seconds`                           | Optional | no        | integer     | The number of seconds Amazon SQS retains a message. Integer representing seconds, from 60 (1 minute) to 1209600 (14 days).
`max_message_size`                           | Optional | no        | integer    | The limit of how many bytes a message can contain before Amazon SQS rejects it. An integer from 1024 bytes (1 KiB) up to 262144 bytes (256 KiB).
`delay_seconds`                           | Optional | no        | integer     | The time in seconds that the delivery of all messages in the queue will be delayed. An integer from 0 to 900 (15 minutes).
`receive_wait_time_seconds`                           | Optional | no       | integer     | The time for which a ReceiveMessage call will wait for a message to arrive (long polling) before returning. An integer from 0 to 20 (seconds).
`policy` | Optional | no | string | The JSON policy for the SQS queue.
`dlq_max_receive_count` | Required (for DLQ) | no | integer | The max receive count for the Dead Letter Queue.
`dlq_queue_arn` | Required (for DLQ) | no | string | The Dead Letter Queue ARN.
`arn` | Computed | n/a | string | Provides ARN of queue that was created.
`id` | Computed | n/a | string | Provides ID of queue that was created.
`fifo_queue` | Optional | yes | bool | Boolean designating a FIFO queue.
`content_based_deduplication` | Optional | yes | bool | Enables content-based deduplication for FIFO queues.
`kms_master_key_id ` | Optional | yes | string | The ID of an AWS-managed customer master key (CMK) for Amazon SQS or a custom CMK.
`kms_data_key_reuse_period_seconds` | Optional | yes | integer | The length of time, in seconds, for which Amazon SQS can reuse a data key to encrypt or decrypt messages before calling AWS KMS again. An integer representing seconds, between 60 seconds (1 minute) and 86,400 seconds (24 hours).
`tags`                           | Optional | no        | map    | A mapping of tags to assign to the queue.

### SQS Queue Policy

```tf
resource "aws_sqs_queue_policy" "queue_policy" {
  queue_url = var.queue_id

  policy = templatefile ("./${var.policy_file_name}", {
    resource_arn = var.resource_arn
  })
}

```
Conditions applied in this module have the following set:

Value                             | Type     | Forces New | Value Type | Description
--------------------------------- | -------- | ---------- | ---------- | -----------
`queue_id`                           | Required | n/a       | string     | The ID of the sqs queue.
`policy_file_name`                | Required   | n/a        | string     | The name of the policy json file.
`resource_arn`                    | Required   | n/a        | string     | arn of resource to allow permissions within the policy. This is a variable that will be used in the resource setting in the json file. e.g. arn:aws:s3:::my-s3-bucket"

<!-- BEGIN_TF_DOCS -->
## Requirements

No requirements.

## Providers

No providers.

## Modules

No modules.

## Resources

No resources.

## Inputs

No inputs.

## Outputs

No outputs.
<!-- END_TF_DOCS -->