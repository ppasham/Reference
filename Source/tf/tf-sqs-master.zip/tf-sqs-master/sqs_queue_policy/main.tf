# Terraform SQS Queue Policy Module
#
##########################################################################################
# Module maintainer: CMS Platform Engineering Services                                   #
# Contact: CMS-SuperSmashCrew@coxautoinc.com                                             #
#                                                                                        #
# Description: Terraform SQS Queue Policy Creation                                       #
# README: https://ghe.coxautoinc.com/cms-terraform/tf-sqs/blob/master/README.md          #
# ___________________                                                                    #
#                                                                                        #
#  Copyright 2019 Cox Automotive Incorporated                                            #
#  All Rights Reserved.                                                                  #
#                                                                                        #
##########################################################################################

# Requirements
terraform {
  required_version = ">= 0.12"
}

# Variables
variable "queue_id" {
  default = ""
}

variable "policy_file_name" {
  default = ""
}

variable "resource_arn" {
  default = ""
}

data "aws_caller_identity" "current" {}

resource "aws_sqs_queue_policy" "queue_policy" {
  queue_url = var.queue_id

  policy = templatefile("./${var.policy_file_name}", {
    resource_arn = var.resource_arn,
    account_id   = data.aws_caller_identity.current.account_id
  })
}
