# SQS output file

# SQS Queue ID
output "queue_id" {
  value = aws_sqs_queue.queue.id
}

# SQS Queue ARN
output "queue_arn" {
  value = aws_sqs_queue.queue.arn
}
