# Terraform DLQ SQS Module
#
###########################################################################################
# Module maintainer: CMS Platform Engineering Services                                    #
# Contact: CMS-SuperSmashCrew@coxautoinc.com                                              #
#                                                                                         #
# Description: Terraform SQS DLQ Queue Creation                                           #
# README: https://ghe.coxautoinc.com/cms-terraform/tf-sqs/blob/master/README.md           #
# ___________________                                                                     #
#                                                                                         #
#  Copyright 2019 Cox Automotive Incorporated                                             #
#  All Rights Reserved.                                                                   #
#                                                                                         #
###########################################################################################

# Requirements
terraform {
  required_version = ">= 0.12"
}

# Variables
variable "queue_name" {
  default = ""
}

variable "visibility_timeout_seconds" {
  default = "30"
}

variable "message_retention_seconds" {
  default = "345600"
}

variable "max_message_size" {
  default = "262144"
}

variable "delay_seconds" {
  default = "0"
}

variable "receive_wait_time_seconds" {
  default = "0"
}

variable "policy" {
  default = ""
}

variable "fifo_queue" {
  default = false
}

variable "content_based_deduplication" {
  default = false
}

variable "kms_master_key_id" {
  default = ""
}

variable "kms_data_key_reuse_period_seconds" {
  default = "300"
}

variable "tags" {
  type    = map(string)
  default = {}
}

# SQS Queue
resource "aws_sqs_queue" "queue" {
  name                        = var.queue_name
  visibility_timeout_seconds  = var.visibility_timeout_seconds
  message_retention_seconds   = var.message_retention_seconds
  max_message_size            = var.max_message_size
  delay_seconds               = var.delay_seconds
  receive_wait_time_seconds   = var.receive_wait_time_seconds
  policy                      = var.policy
  fifo_queue                  = var.fifo_queue
  content_based_deduplication = var.content_based_deduplication

  kms_master_key_id                 = var.kms_master_key_id
  kms_data_key_reuse_period_seconds = var.kms_data_key_reuse_period_seconds

  tags = var.tags
}
