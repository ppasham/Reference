# tf-route53
AWS Route53 Terraform Module

# Description
Terraform module which creates Private Route53 zones, Public Route53 zones, Route53 DNS Records, and Route53 Alias DNS Records

# Usage

### Private Route53 Zone

```hcl
data "aws_vpc" "vpc" {
  tags = {
    Environment = var.vpc_tag
  }
}

resource "aws_route53_zone" "private_zone" {
  name     = var.dns_name

  vpc {
    vpc_id = data.aws_vpc.vpc.id
  }

  tags     = var.tags
}
```

Creates a private DNS zone that is associated with a VPC

Conditions applied in this module have the following set:

Value    | Type     | Value Type | Description
-------- | -------- | ---------- | -----------
`name`   | Required | NA         | This is the name of the hosted zone.
`vpc_id` | Required | NA         | ID of the VPC to associate. 
`tags`   | Optional | Map String | A mapping of tags to assign to the zone.

### Public Route53 Zone

```hcl
resource "aws_route53_zone" "public_zone" {
  name = var.dns_name
  tags = var.tags
}
```

Creates a public DNS zone. In order to register a public Domain, you will need to manually use an email account to activate the public zone. [AWS Route53 Public Hosted Zone Doc](https://docs.aws.amazon.com/Route53/latest/DeveloperGuide/AboutHZWorkingWith.html)

Conditions applied in this module have the following set:

Value  | Type     | Value Type | Description                                                                        
------ | -------- | ---------- | -----------                                                                        
`name` | Required | NA         | This is the name of the hosted zone.                                               
`tags` | Optional | Map String | A mapping of tags to assign to the zone.  

### Route53 DNS Record

```hcl
data "aws_route53_zone" "zone_id" {
  name         = "${var.dns_name}."
  private_zone = true
}

resource "aws_route53_record" "record" {
  zone_id = data.aws_route53_zone.zone_id.zone_id
  name    = var.record_name
  type    = var.record_type
  ttl     = var.time_to_live
  records = [var.records]
}
```

Creates a simple DNS record to route to a specific Route53 zone

Conditions applied in this module have the following set:

Value     | Type     | Value Type | Description                                                                        
--------- | -------- | ---------- | -----------                                                                        
`zone_id` | Required | NA         | The ID of the hosted zone to contain this record.
`name`    | Required | NA         | This is the name of the hosted zone.                                               
`type`    | Required | NA         | The record type. Valid values are A, AAAA, CAA, CNAME, MX, NAPTR, NS, PTR, SOA, SPF, SRV and TXT.
`ttl`     | Required | NA         | The TTL of the record. 
`records` | Optional | NA         | A string list of records. To specify a single record value longer than 255 characters such as a TXT record for DKIM, add \"\" inside the Terraform configuration string (e.g. "first255characters\"\"morecharacters").

### Route53 Alias DNS Record

```hcl
data "aws_route53_zone" "zone_id" {
  name         = "${var.dns_name}."
  private_zone = true
}

resource "aws_route53_record" "alias_record" {
  zone_id                  = data.aws_route53_zone.zone_id.zone_id
  name                     = var.record_name
  type                     = var.record_type

  alias {
    name                   = var.alias_name
    zone_id                = var.alias_zone_id
    evaluate_target_health = var.target_health
  }
}
```

Creates an alias DNS record that ties to another AWS resource.

Conditions applied in this module have the following set:

Value     | Type     | Value Type | Description                                                                        
--------- | -------- | ---------- | -----------                                                                        
`zone_id` | Required | NA         | The ID of the hosted zone to contain this record.
`name`    | Required | NA         | This is the name of the hosted zone.                                                                                                                                                                 
`type`    | Required | NA         | The record type. Valid values are A, AAAA, CAA, CNAME, MX, NAPTR, NS, PTR, SOA, SPF, SRV and TXT.     
`alias`   | Required | Block      | Following supported settings:` name` - (Required) DNS domain name for a CloudFront distribution, S3 bucket, ELB, or another resource record set in this hosted zone. `zone_id` - (Required) Hosted zone ID for a CloudFront distribution, S3 bucket, ELB, or Route 53 hosted zone. `evaluate_target_health` - (Required) Set to true if you want Route 53 to determine whether to respond to DNS queries using this resource record set by checking the health of the resource record set.

# References
* [Terraform Private Route53 Zone](https://www.terraform.io/docs/providers/aws/r/route53_zone.html#private-zone)
* [Terraform Public Route53 Zone](https://www.terraform.io/docs/providers/aws/r/route53_zone.html#public-zone)
* [Terraform Route53 Record](https://www.terraform.io/docs/providers/aws/r/route53_record.html#simple-routing-policy)
* [Terraform Route53 Alias Record](https://www.terraform.io/docs/providers/aws/r/route53_record.html#alias-record)
