# Route53 Private Zone outputs file

# Private Zone ID output
output "private_zone_id" {
  value = aws_route53_zone.private_zone.id
}

# Private name servers output
output "private_name_servers" {
  value = aws_route53_zone.private_zone.name_servers
}
