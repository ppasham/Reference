# Terraform Route53 Private Zone Module
#
##########################################################################################
# Module maintainer: CMS Platform Engineering Services                                   #
# Contact: CMS-SuperSmashCrew@coxautoinc.com                                             #
#                                                                                        #
# Description: Route53 Private Zone Creation                                             #
# README: https://ghe.coxautoinc.com/cms-terraform/tf-route53/blob/master/README.md      #
# ___________________                                                                    #
#                                                                                        #
#  Copyright 2019 Cox Automotive Incorporated                                            #
#  All Rights Reserved.                                                                  #
#                                                                                        #
##########################################################################################

# Requirements
terraform {
  required_version = ">= 0.12"
}

# Variables
variable "vpc_tag" {
}

variable "dns_name" {
}

variable "tags" {
  type = map(string)
  default = {}
}

# Data Sources
# VPC ID
data "aws_vpc" "vpc" {
  tags = {
    Environment = var.vpc_tag
  }
}

# Private Route53 Zone
resource "aws_route53_zone" "private_zone" {
  name     = var.dns_name

  vpc {
    vpc_id = data.aws_vpc.vpc.id
  }

  tags     = var.tags
}
