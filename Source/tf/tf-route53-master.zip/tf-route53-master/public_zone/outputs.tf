# Route53 Public Zone outputs file

# Public Zone ID output
output "public_zone_id" {
  value = aws_route53_zone.public_zone.id
}

# Public name servers output
output "public_name_servers" {
  value = aws_route53_zone.public_zone.name_servers
}
