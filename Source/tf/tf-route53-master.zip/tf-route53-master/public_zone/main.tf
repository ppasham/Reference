# Terraform Route53 Public Zone Module
#
##########################################################################################
# Module maintainer: CMS Platform Engineering Services                                   #
# Contact: CMS-SuperSmashCrew@coxautoinc.com                                             #
#                                                                                        #
# Description: Route53 Public Zone Creation                                              #
# README: https://ghe.coxautoinc.com/cms-terraform/tf-route53/blob/master/README.md      #
# ___________________                                                                    #
#                                                                                        #
#  Copyright 2019 Cox Automotive Incorporated                                            #
#  All Rights Reserved.                                                                  #
#                                                                                        #
##########################################################################################

# Requirements
terraform {
  required_version = ">= 0.12"
}

# Variables
variable "dns_name" {
}

variable "tags" {
  type = map(string)
  default = {}
}

# Public Route53 Zone
resource "aws_route53_zone" "public_zone" {
  name = var.dns_name
  tags = var.tags
}
