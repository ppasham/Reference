# Terraform s3 Bucket Deployment Script
  
terraform {
  required_version = ">= 0.12"
}

# Variables
variable "region" {
  default     = "us-west-2"
  description = "AWS Region"
}

variable "private_vpc_tag" {
  default     = "np"
  description = "Tag used to identify VPC ID"
}

variable "private_dns_name" {
  default     = ".mydomaininternal.com"
  description = "name of dns"
}

variable "private_tags" {
  type        = map(string)
  default     = {
    Name        = "myprivatedns"
    Environment = "Test"
    Owner       =  "Me, Myself, & I"
  }
  description = "List of information to identify resource with tags"
}

variable "public_dns_name" {
  default     = "mydomain.com"
  description = "name of dns"
}

variable "public_tags" {
  type        = map(string)
  default     = {
    Name        = mypublicdns
    Environment = "Test"
    Owner       =  "Me, Myself, & I"
  }
  description = "List of information to identify resource with tags"
}

variable "alias_dns_name" {
  default     = "mydomaintest.com"
  description = "name of dns"
}

variable "alias_record_name" {
  default     = "mydnstest.mydomaintest.com"
  description = "Name of resource"
}

variable "alias_record_type" {
  default     = "A"
  description = "The record type. Valid values are A, AAAA, CAA, CNAME, MX, NAPTR, NS, PTR, SOA, SPF, SRV and TXT."
}

variable "alias_name" {
  default     = "myaliasdnstest.com"
  description = "Name of alias"
}

variable "alias_zone_id" {
  default     = "ABCDEFG123456"
  description = "Zone where alias is configured"
}

variable "target_health" {
  default     = "True"
  description = "True or False to configure resource health settings"
}

variable "dns_name" {
  default     = "mydnstest"
  description = "name of dns"
}

variable "record_name" {
  default     = "myawsserver-test.zxcvbndsaqwe.com"
  description = "Name of resource"
}

variable "record_type" {
  default     = "CNAME"
  description = "The record type. Valid values are A, AAAA, CAA, CNAME, MX, NAPTR, NS, PTR, SOA, SPF, SRV and TXT."
}

variable "time_to_live" {
  default     = "300"
  description = "The TTL of the record"
}

variable "records" {
  default     = "my.example.com"
  description = "A string list of records. To specify a single record value longer than 255 characters such as a TXT record for DKIM, add \"\" inside the Terraform configuration string (e.g. "first255characters\"\"morecharacters")"
}

# AWS Provider
provider "aws" {
  region = var.region
}

# S3 Backend
terraform {
  backend "s3" {
  }
}

# Private Zone Creation
module "private_zone" {
  source   = "git@ghe.coxautoinc.com:cms-terraform/tf-route53.git//private_zone"
  vpc_tag  = var.private_vpc_tag
  dns_name = var.private_dns_name
  tags     = var.tags
}

# Public Zone Creation
module "public_zone" {
  source   = "git@ghe.coxautoinc.com:cms-terraform/tf-route53.git//public_zone"
  dns_name = var.public_dns_name
  tags     = var.public_tags
}

# Alias Record Creation
module "dns_alias_record" {
  source        = "git@ghe.coxautoinc.com:cms-terraform/tf-route53.git//route53_alias_record"
  dns_name      = var.alias_dns_name
  record_name   = var.alias_record_name
  record_type   = var.alias_record_type
  alias_name    = var.alias_name
  alias_zone_id = var.alias_zone_id
  target_health = var.target_health
}

# Record Creation
module "dns_record" {
  source       = "git@ghe.coxautoinc.com:cms-terraform/tf-route53.git//route53_record"
  dns_name     = var.dns_name
  record_name  = var.record_name
  record_type  = var.record_type
  time_to_live = var.time_to_live
  records      = var.records
}
