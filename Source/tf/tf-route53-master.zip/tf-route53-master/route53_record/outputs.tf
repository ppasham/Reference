# Route53 record outputs

# Route53 name output
output "route53_name" {
  value = aws_route53_record.record.name
}

# Route53 fqdn output
output "route53_fqdn" {
  value = aws_route53_record.record.fqdn
}
