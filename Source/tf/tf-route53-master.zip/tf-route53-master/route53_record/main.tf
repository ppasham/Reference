# Terraform Route53 Record Module
#
##########################################################################################
# Module maintainer: CMS Platform Engineering Services                                   #
# Contact: CMS-SuperSmashCrew@coxautoinc.com                                             #
#                                                                                        #
# Description: Route53 Record Creation                                                   #
# README: https://ghe.coxautoinc.com/cms-terraform/tf-route53/blob/master/README.md      #
# ___________________                                                                    #
#                                                                                        #
#  Copyright 2019 Cox Automotive Incorporated                                            #
#  All Rights Reserved.                                                                  #
#                                                                                        #
##########################################################################################

# Requirements
terraform {
  required_version = ">= 0.12"
}

# Variables
variable "dns_name" {
}

variable "record_name" {
}

variable "record_type" {
}

variable "time_to_live" {
}

variable "records" {
}

# Data Sources
# Route53 Zone ID
data "aws_route53_zone" "zone_id" {
  name         = "${var.dns_name}."
  private_zone = true
}

# Route53 Record
resource "aws_route53_record" "record" {
  zone_id = data.aws_route53_zone.zone_id.zone_id
  name    = var.record_name
  type    = var.record_type
  ttl     = var.time_to_live
  records = [var.records]
}
