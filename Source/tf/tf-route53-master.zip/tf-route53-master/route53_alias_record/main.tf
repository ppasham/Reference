# Terraform Route53 Alias Record Module
#
##########################################################################################
# Module maintainer: CMS Platform Engineering Services                                   #
# Contact: CMS-SuperSmashCrew@coxautoinc.com                                             #
#                                                                                        #
# Description: Route53 Alias Record Creation                                             #
# README: https://ghe.coxautoinc.com/cms-terraform/tf-route53/blob/master/README.md      #
# ___________________                                                                    #
#                                                                                        #
#  Copyright 2019 Cox Automotive Incorporated                                            #
#  All Rights Reserved.                                                                  #
#                                                                                        #
##########################################################################################

# Requirements
terraform {
  required_version = ">= 0.12"
}

# Variables
variable "dns_name" {
}

variable "record_name" {
}

variable "record_type" {
}

variable "alias_name" {
}

variable "alias_zone_id" {
}

variable "target_health" {
}

# Data Sources
# Route53 Zone ID
data "aws_route53_zone" "zone_id" {
  name         = "${var.dns_name}."
}

# Route53 Alias Record
resource "aws_route53_record" "alias_record" {
  zone_id                  = data.aws_route53_zone.zone_id.zone_id
  name                     = var.record_name
  type                     = var.record_type

  alias {
    name                   = var.alias_name
    zone_id                = var.alias_zone_id
    evaluate_target_health = var.target_health
  }
}
