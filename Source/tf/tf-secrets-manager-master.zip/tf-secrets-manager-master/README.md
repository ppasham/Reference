# tf-secrets-manager
AWS Secrets Manager Terraform Module

## Description


## Usage

### Secrets Manager

```hcl
data "aws_kms_key" "kms_key" {
    key_id = "${var.kms_key}"
}

resource "aws_secretsmanager_secret" "secret" {
  name        = var.secret_name
  description = var.description
  kms_key_id  = data.aws_kms_key.kms_key.arn
  tags        = var.tags
}

resource "aws_secretsmanager_secret_version" "secret_version" {
  secret_id     = aws_secretsmanager_secret.secret.id
  secret_string = var.secret_string
}
```

Creates a secret and secret version

Conditions applied in this module have the following set

Value           | Type     | Value Type           | Description
--------------- | -------- | -------------------- | -----------
`secret_name`          | Required | String               | Specifies the friendly name of the new secret. The secret name can consist of uppercase letters, lowercase letters, digits, and any of the following characters: /_+=.@-
`description`   | Required | NA                   | A description of the secret.
`kms_key_id`    | Optional, defaults to "alias/cai-basic-data-kms-key" | String               | Specifies the ARN or alias of the AWS KMS customer master key (CMK) to be used to encrypt the secret values in the versions stored in this secret. If you don't specify this value, then Secrets Manager defaults to using the AWS account's default CMK (the one named aws/secretsmanager). If the default KMS CMK with that name doesn't yet exist, then AWS Secrets Manager creates it for you automatically the first time.
`tags`          | Optional | Map                  | Specifies a key-value map of user-defined tags that are attached to the secret
`secret_string` | Required | String, Number, Bool | Specifies text data that you want to encrypt and store in this version of the secret.
`recovery_window_in_days` | Optional | Number, defaults to 7 days | Specifies the number of days that AWS Secrets Manager waits before it can delete the secret. This value can be 0 to force deletion without recovery or range from 7 to 30 days

## References
[Terraform Secrets Manager](https://www.terraform.io/docs/providers/aws/r/secretsmanager_secret.html)

[Terraform Secrets Manager Version](https://www.terraform.io/docs/providers/aws/r/secretsmanager_secret_version.html)
