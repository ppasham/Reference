# Secrets Manager Outputs

# Secrets Manager Secret ID
output "secretsmanager_secret_id" {
 value = aws_secretsmanager_secret.secret.id
}

# Secrets Manager Secret ARN
output "secretsmanager_secret_arn" {
 value = aws_secretsmanager_secret.secret.arn
}

# Secrets Manager Secret Version ID
output "secretsmanager_secret_version_id" {
 value = aws_secretsmanager_secret_version.secret_version.id
}

# Secrets Manager Secret Version ARN
output "secretsmanager_secret_version_arn" {
 value = aws_secretsmanager_secret_version.secret_version.arn
}

# Secrets Manager Secret Version VersionID
output "secretsmanager_secret_version_versionid" {
 value = aws_secretsmanager_secret_version.secret_version.version_id
}
