# Secrets Manager Secret & Secret Version Terraform Deployment

terraform {
  required_version = ">= 0.12"
}

# Variables
variable "region" {
  default     = "us-west-2"
  description = "AWS region where service will be deployed"
}

variable "kms_key" {
  default     = "alias/test"
  description = "Specifies the ARN or alias of the AWS KMS customer master key (CMK) to be used to encrypt the secret values in the versions stored in this secret"
}

variable "secret_name" {
  default     = "myfirstsecret"
  description = "Specifies the friendly name of the new secret"
}

variable "description" {
  default     = "My Secret for My Microservice"
  description = "A description of the secret"
}

variable "tags" {
  type        = map(string)
  default     = {
    Owner       = "MeMyselfI"
    Environment = "Test"
  }
  description = "Specifies a key-value map of user-defined tags that are attached to the secret"
}

variable "secret_string" {
  default     = "MyShhhItsASecret"
  description = "Specifies text data that you want to encrypt and store in this version of the secret"
}

# AWS Provider
provider "aws" {
  region = var.region
}

# S3 Backend
terraform {
  backend "s3" {
  }
}

# Secret Creation
module "my_secret" {
  source        = "git@ghe.coxautoinc.com:cms-terraform/tf-secrets-manager.git"
  kms_key       = var.kms_key
  secret_name   = var.secret_name
  description   = var.description
  tags          = var.tags
  secret_string = var.secret_string
}
