# Terraform Secrets Manager Module
#
#############################################################################################
# Module maintainer: CMS Platform Engineering Services                                      #
# Contact: CMS-SuperSmashCrew@coxautoinc.com                                                #
#                                                                                           #
# Description: Secrets Manager Secret Creation                                              #
# README: https://ghe.coxautoinc.com/cms-terraform/tf-secrets-manager/blob/master/README.md #
# ___________________                                                                       #
#                                                                                           #
#  Copyright 2019 Cox Automotive Incorporated                                               #
#  All Rights Reserved.                                                                     #
#                                                                                           #
#############################################################################################

terraform {
  required_version = ">= 0.12"
}

# Variables
variable "kms_key" {
  default     = "alias/cai-basic-data-kms-key"
  description = "The name of the KMS Key to use for secret encryption."
}

variable "secret_name" {
  description = "Specifies the friendly name of the new secret. The secret name can consist of uppercase letters, lowercase letters, digits, and any of the following characters: /_+=.@-"
}

variable "description" {
  description = "A description of the secret"
}

variable "tags" {
  type = map(string)
  default = {}
  description = "Specifies a key-value map of user-defined tags that are attached to the secret."
}

variable "secret_string" {
  description = "Specifies text data that you want to encrypt and store in the secret."
}

variable "recovery_window_in_days" {
  default = 7
  description = "Specifies the number of days that AWS Secrets Manager waits before it can delete the secret. This value can be 0 to force deletion without recovery or range from 7 to 30 days"
}

# Pulls KMS information
data "aws_kms_key" "kms_key" {
  key_id = var.kms_key
}

# Secrets Manager
resource "aws_secretsmanager_secret" "secret" {
  name        = var.secret_name
  description = var.description
  kms_key_id  = data.aws_kms_key.kms_key.arn
  tags        = var.tags
  recovery_window_in_days = var.recovery_window_in_days
}

# Secrets Manager Version
resource "aws_secretsmanager_secret_version" "secret_version" {
  secret_id     = aws_secretsmanager_secret.secret.id
  secret_string = var.secret_string
}
