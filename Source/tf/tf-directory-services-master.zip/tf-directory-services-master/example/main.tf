variable "simple_ad_directory_name" {
  default = "example_simple_ad"
}

variable "simple_ad_directory_password" {
  default = "SuperSecretEx@mp!ePa33w0rd"
}

variable "simple_ad_directory_size" {
  default = "Small"
}

variable "microsoft_ad_directory_name" {
  default = "example_microsoft_ad"
}

variable "microsoft_ad_directory_password" {
  default = "SuperSecretEx@mp!ePa33w0rd"
}

variable "microsoft_ad_directory_edition" {
  default = "Standard"
}

variable "vpc_name" {
  default = "exampleVpcName"
}

variable "subnet_ids" {
  default = [
    "sg-1x1x1x1x1x1x1x1x1x1x1x",
    "sg-2x2x2x2x2x2x2x2x2x2x2x"
  ]
}

variable "region" {
  default = "us-west-2"
}

variable "tags" {
  type    = map(string)
  default = {}
}

# AWS Provider
provider "aws" {
  region = var.region
}

module "simple_ad" {
  source = "git@ghe.coxautoinc.com:cms-terraform/tf-directory-services.git//simple_ad"

  directory_name     = var.simple_ad_directory_name
  directory_password = var.simple_ad_directory_password
  directory_size     = var.simple_ad_directory_size

  vpc_name   = var.vpc_name
  subnet_ids = var.subnet_ids
  tags       = var.tags
}

module "microsoft_ad" {
  source = "git@ghe.coxautoinc.com:cms-terraform/tf-directory-services.git//microsoft_ad"

  directory_name     = var.microsoft_ad_directory_name
  directory_password = var.microsoft_ad_directory_password
  directory_edition  = var.microsoft_ad_directory_edition

  vpc_name   = var.vpc_name
  subnet_ids = var.subnet_ids
  tags       = var.tags
}
