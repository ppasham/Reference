# tf-directory-services

Provides module for AWS Simple AD and AWS Microsoft AD.

## Description

### Simple AD (simple-ad)

AWS directory service directory using Simple AD.

### Microsoft AD (microsoft-ad)

AWS directory service directory of the "MicrosoftAD" type.

## Usage

### Simple AD (simple-ad)

```hcl
data "aws_vpc" "vpc" {
  tags = {
    Name = var.vpc_name
  }
}

resource "aws_directory_service_directory" "simple_ad_directory_service" {
  name     = var.directory_name  
  password = var.directory_password
  size     = var.directory_size

  vpc_settings {
    vpc_id     = data.aws_vpc.vpc.id
    subnet_ids = var.subnet_ids
  }

  tags = var.tags
}
```

Conditions applied in this module have the following set:

| Value | Type | Forces New | Value Type | Description |
|-------|------|------------|------------|-------------|
| `directory_name` | Required | yes | string | The human-readable name of the Simple AD instance. |
| `directory_password` | Required | yes | string | The passwotd for the Simple AD instance. |
| `directory_size` | Optional | yes | string | The size of the Simple AD directory service to create. |
| `vpc_name` | Required | yes | string | The name of the VPC to deploy to. |
| `subnet_ids` | Required | yes | string | The ID's of the subnets to connect the Simple AD service to. |

### Microsoft AD (microsoft-ad)

```hcl
data "aws_vpc" "vpc" {
  tags = {
    Name = var.vpc_name
  }
}

resource "aws_directory_service_directory" "microsoft_ad_directory_service" {
  name     = var.directory_name
  password = var.directory_password
  edition  = var.directory_edition
  type     = "MicrosoftAD"

  vpc_settings {
    vpc_id     = data.aws_vpc.vpc.id
    subnet_ids = var.subnet_ids
  }

  tags = var.tags
}
```

Conditions applied in this module have the following set:

| Value | Type | Forces New | Value Type | Description |
|-------|------|------------|------------|-------------|
| `directory_name` | Required | yes | string | The human-readable name of the Microsoft AD instance. |
| `directory_password` | Required | yes | string | The password for the Microsoft AD instance. |
| `directory_edition` | Optional | yes | string | The edition of the Microsoft AD instance. |
| `vpc_name` | Required | yes | string | The name of the VPC to deploy to. |
| `subnet_ids` | Required | yes | string | The ID's of the subnets to connect the Microsoft AD service to. |

