# Terraform Directory Services Module
#
###############################################################################################
# Module maintainer: CMS Platform Engineering Services                                        #
# Contact: CMS-SuperSmashCrew@coxautoinc.com                                                  #
#                                                                                             #
# Description: Simple AD creation                                                             #
# README: https://ghe.coxautoinc.com/cms-terraform/tf-directoryservices/blob/master/README.md #
# ___________________                                                                         #
#                                                                                             #
#  Copyright 2020 Cox Automotive Incorporated                                                 #
#  All Rights Reserved.                                                                       #
#                                                                                             #
###############################################################################################

# Requirements
terraform {
  required_version = ">= 0.12"
}

# Variables
variable "directory_name" {
}

variable "directory_password" {
}

variable "directory_size" {
  default = "Small"
}

variable "vpc_name" {
}

variable "subnet_ids" {
  default = []
}

variable "tags" {
  type    = map(string)
  default = {}
}

# Pulls Account ID
data "aws_caller_identity" "current" {}

# Pulls VPC ID
data "aws_vpc" "vpc" {
  tags = {
    Name = var.vpc_name
  }
}

# Resources
resource "aws_directory_service_directory" "simple_ad_directory_service" {
  name     = var.directory_name
  password = var.directory_password
  size     = var.directory_size

  vpc_settings {
    vpc_id     = var.vpc_id
    subnet_ids = var.subnet_ids
  }

  tags = var.tags
}
