# Terraform Directory Services Module 

output "simple_ad_id" {
  value = aws_directory_service_directory.simple_ad_directory_service.id
}

output "simple_ad_access_url" {
  value = aws_directory_service_directory.simple_ad_directory_service.access_url
}

output "simple_ad_dns_ip_addresses" {
  value = aws_directory_service_directory.simple_ad_directory_service.dns_ip_addesses
}

output "simple_ad_security_group_id" {
  value = aws_directory_service_directory.simple_ad_directory_service.security_group_id
}
