# Terraform Elastic Beanstalk Deployment Script

terraform {
  required_version = ">= 0.12"
}

# Variables
variable "region" {
}

variable "application_name" {
  default     = "my_app"
  description = "The name of the application"
}

variable "service_role" {
  default     = "my_role"
  description = "The ARN of an IAM service role under which the application version is deleted. Elastic Beanstalk must have permission to assume this role"
}

variable "description" {
  default     = "This is my first Application"
  description = "Description of the application"
}

# AWS Provider
provider "aws" {
  region = var.region
}

# S3 Backend
terraform {
  backend "s3" {
  }
}

# Application Creation
module "example_application" {
  source                = "git@ghe.coxautoinc.com:cms-terraform/tf-elasticbeanstalk.git//eb-application"
  application_name      = var.application_name
  description           = var.application_description
  service_role          = var.service_role
}
