# Terraform Elastic Beanstalk Deployment Script

terraform {
  required_version = ">= 0.12"
}

# Variables
variable "region" {
}

variable "artifact_version_name" {
  default     = "1.0.0"
  description = "Application Version"
}

variable "application_name" {
  default     = "my_app"
  description = "Name of the Application"
}

variable "application_version_description" {
  default     = "This is my first application"
  description = "Description of the Application Version"
}

variable "bucket_name" {
  default     = "my_app_bucket"
  description = "The name of the s3 bucket for application version"
}

variable "key" {
  default     = "my_app_1.0.0"
  description = "S3 object that is the Application Version source bundle"
}

# AWS Provider
provider "aws" {
  region = var.region
}

# S3 Backend
terraform {
  backend "s3" {
  }
}

# Application Version Creation
module "example_application_version" {
  source                = "git@ghe.coxautoinc.com:cms-terraform/tf-elasticbeanstalk.git//eb-application-version"
  artifact_version_name = var.artifact_version_name
  application_name      = var.application_name
  description           = var.application_version_description
  bucket_name           = var.bucket_name
  key                   = var.key
}
