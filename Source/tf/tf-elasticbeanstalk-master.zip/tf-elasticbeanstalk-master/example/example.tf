# Terraform Elastic Beanstalk Deployment Script

terraform {
  required_version = ">= 0.12"
}

# Variables
variable "region" {
}

variable "application_name" {
  default     = "my_app"
  description = "The name of the application"
}

variable "application_description" {
  default     = "my first application"
  description = "The description of the application"
}

variable "service_role" {
  default     = "my_app_role"
  description = "The ARN of an IAM service role under which the application version is deleted. Elastic Beanstalk must have permission to assume this role."
}

variable "delete_source_from_s3" {
  default     = "true"
  description = "Set to true to delete a version's source bundle from S3 when the application version is deleted."
}

variable "artifact_version_name" {
  default     = "artifact_1.0"
  description = "The applicaton version name"
}

variable "application_version_description" {
  default     = "My first application version"
  description = "The application version description"
}

variable "bucket_name" {
  default     = "my_bucket"
  description = "S3 bucket that contains the application version"
}

variable "key" {
  default     = "my_appp_1.0"
  description = "S3 object that is the Application Version source bundle."
}

variable "environment_name" {
  default     = "my_appliction_environment"
  description = "The name of the environment"
}

variable "name_regex" {
  default     = "^64bit Amazon Linux (.*) running Java 8"
  description = "The regular expression for the solution stack to run application on"
}

variable "tier" {
  default     = "WebServer"
  description = "Elastic Beanstalk Environment tier. Valid values are Worker or WebServer."
}

variable "wait_for_ready_timeout" {
   default     = "20m"
   description = "The maximum duration that Terraform should wait for an Elastic Beanstalk Environment to be in a ready state before timing out."
 }

variable "tags" {
  type        = map(string)
  default     = {
    Name        = "my-first-eb-app"
    Environment = "Test"
    Owner       = "Me,Myself_&I"
  }
  description = "A mapping of tags to assign to the object"
}

# AWS Provider
provider "aws" {
  region = var.region
}

# S3 Backend
terraform {
  backend "s3" {
  }
}

# Application Creation
module "example_application" {
  source                = "git@ghe.coxautoinc.com:cms-terraform/tf-elasticbeanstalk.git//eb-application"
  application_name      = var.application_name
  description           = var.application_description
  service_role          = var.service_role
  delete_source_from_s3 = var.delete_source_from_s3
}

# Application Version Creation
module "example_application_version" {
  source                = "git@ghe.coxautoinc.com:cms-terraform/tf-elasticbeanstalk.git//eb-application-version"
  artifact_version_name = var.artifact_version_name
  application_name      = module.example_application.name
  description           = var.application_version_description
  bucket_name           = var.bucket_name
  key                   = var.key
}

# Environment Creation
module "example_environment" {
  source                 = "git@ghe.coxautoinc.com:cms-terraform/tf-elasticbeanstalk.git//eb-environment"
  environment_name       = var.environment_name
  application_name       = module.example_application.name
  name_regex             = var.name_regex
  tier                   = var.tier
  wait_for_ready_timeout = var.wait_for_ready_timeout
  tags                   = var.tags
}
