# Terraform Elastic Beanstalk Deployment Script

terraform {
  required_version = ">= 0.12"
}

# Variables
variable "region" {
}

variable "application_name" {
  default     = "my_app"
  description = "The name of the application for the Elastic Beanstalk Environment"
}

variable "environment_name" {
  default     = "my_appliction_environment"
  description = "The name of the environment"
}

variable "name_regex" {
  default     = "^64bit Amazon Linux (.*) running Java 8"
  description = "The regular expression for the solution stack to run application on"
}

variable "tier" {
  default     = "WebServer"
  description = "Elastic Beanstalk Environment tier. Valid values are Worker or WebServer."
}

variable "wait_for_ready_timeout" {
   default     = "20m"
   description = "The maximum duration that Terraform should wait for an Elastic Beanstalk Environment to be in a ready state before timing out."
}

variable "tags" {
  type        = map(string)
  default     = {
    Name        = "my-first-eb-app"
    Environment = "Test"
    Owner       = "Me,Myself_&I"
  }
  description = "A mapping of tags to assign to the object"
}

# AWS Provider
provider "aws" {
  region = var.region
}

# S3 Backend
terraform {
  backend "s3" {
  }
}

# Environment Creation
module "example_environment" {
  source                 = "git@ghe.coxautoinc.com:cms-terraform/tf-elasticbeanstalk.git//eb-environment"
  environment_name       = var.environment_name
  application_name       = var.application_name
  name_regex             = var.name_regex
  tier                   = var.tier
  wait_for_ready_timeout = var.wait_for_ready_timeout
  tags                   = var.tags
}
