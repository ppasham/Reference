# Terraform Elastic Beanstalk Application Version
#
##############################################################################################
# Module maintainer: CMS Platform Engineering Services                                       #
# Contact: CMS-SuperSmashCrew@coxautoinc.com                                                 #
#                                                                                            #
# Description: Terraform Elastic Beanstalk Application Version                               #
# README: https://ghe.coxautoinc.com/cms-terraform/tf-elasticbeanstalk/blob/master/README.md #
# ___________________                                                                        #
#                                                                                            #
#  Copyright 2019 Cox Automotive Incorporated                                                #
#  All Rights Reserved.                                                                      #
#                                                                                            #
##############################################################################################

# Requirements
terraform {
  required_version = ">= 0.12"
}

# Variables
variable "artifact_version_name" {
  default = ""
}

variable "application_name" {
  default = ""
}

variable "description" {
  default = ""
}

variable "bucket_name" {
  default = ""
}

variable "key" {
  default = ""
}

# Elastic Beanstalk Application Version
resource "aws_elastic_beanstalk_application_version" "application_version" {
  name        = var.artifact_version_name
  application = var.application_name
  description = var.description
  bucket      = var.bucket_name
  key         = var.key
}
