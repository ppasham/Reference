# Elastic Beanstalk Application Version Outputs

# Elastic Beanstalk Application Version Name
output "eb_application_version_name" {
  value = aws_elastic_beanstalk_application_version.application_version.name
}

# Elastic Beanstalk Application Version ID
output "eb_application_version_id" {
  value = aws_elastic_beanstalk_application_version.application_version.id
}

# Elastic Beanstalk Application Version ARN
output "eb_application_version_arn" {
  value = aws_elastic_beanstalk_application_version.application_version.arn
}
