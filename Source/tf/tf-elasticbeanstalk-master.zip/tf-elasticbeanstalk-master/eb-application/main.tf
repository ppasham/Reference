# Terraform Elastic Beanstalk Application
#
##############################################################################################
# Module maintainer: CMS Platform Engineering Services                                       #
# Contact: CMS-SuperSmashCrew@coxautoinc.com                                                 #
#                                                                                            #
# Description: Terraform Elastic Beanstalk Application                                       #
# README: https://ghe.coxautoinc.com/cms-terraform/tf-elasticbeanstalk/blob/master/README.md #
# ___________________                                                                        #
#                                                                                            #
#  Copyright 2019 Cox Automotive Incorporated                                                #
#  All Rights Reserved.                                                                      #
#                                                                                            #
##############################################################################################

# Requirements
terraform {
  required_version = ">= 0.12"
}

# Variables
variable "application_name" {
  default = ""
}

variable "service_role" {
  default = ""
}

variable "description" {
  default = ""
}

variable "delete_source_from_s3" {
  default = "true"
}

# Elastic Beanstalk Application Creation
resource "aws_elastic_beanstalk_application" "application" {
  name        = var.application_name
  description = var.description

  appversion_lifecycle {
    service_role          = var.service_role
    max_count             = 50
    delete_source_from_s3 = var.delete_source_from_s3
  }
}
