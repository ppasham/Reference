# Elastic Beanstalk Application Outputs

# Elastic Beanstalk Application Name
output "eb_application_name" {
  value = aws_elastic_beanstalk_application.application.name
}

# Elastic Beanstalk Application ID
output "eb_application_id" {
  value = aws_elastic_beanstalk_application.application.id
}

# Elastic Beanstalk Application ARN
output "eb_application_arn" {
  value = aws_elastic_beanstalk_application.application.arn
}
