# Terraform Elastic Beanstalk Environment
#
##############################################################################################
# Module maintainer: CMS Platform Engineering Services                                       #
# Contact: CMS-SuperSmashCrew@coxautoinc.com                                                 #
#                                                                                            #
# Description: Terraform Elastic Beanstalk Environment                                       #
# README: https://ghe.coxautoinc.com/cms-terraform/tf-elasticbeanstalk/blob/master/README.md #
# ___________________                                                                        #
#                                                                                            #
#  Copyright 2019 Cox Automotive Incorporated                                                #
#  All Rights Reserved.                                                                      #
#                                                                                            #
##############################################################################################

# Requirements
terraform {
  required_version = ">= 0.12"
}

# Variables
variable "name_regex" {
  default = ""
}

variable "application_name" {
  default = ""
}

variable "vpc_name" {
  default = ""
}

variable "environment_name" {
  default = ""
}

variable "tier" {
  default = "WebServer"
}

variable "wait_for_ready_timeout" {
  default = "20m"
}

variable "tags" {
  type        = map(string)
  default     = {}
}

variable "root_volume_type" {
  default = "gp2"
}

variable "root_volume_size" {
  default = "60"
}

variable "iam_profile" {
  default = ""
}

variable "instance_size" {
  default = "t2.medium"
}

variable "web_sec_grp" {
  default = ""
}

variable "key_pair" {
  default = ""
}

variable "lb_sec_grp" {
  default = ""
}

variable "web_sec_grp" {
  default = ""
}

variable "subnet_ids" {
  type    = list(string)
  default = ["", ""]
}

variable "associate_public_ip_address" {
  default = "false"
}

variable "platform_update" {
  default = "true"
}

variable "time_updates" {
  default = "SUN:17:00"
}

variable "platform_update_level" {
  default = "minor"
}

variable "rolling_update" {
  default = "true"
}

variable "rolling_update_type" {
  default = "Health"
}

variable "max_batch_size" {
  default = "1"
}

variable "deployment_type" {
  default = "Rolling"
}

variable "batch_size_type" {
  default = "Fixed"
}

variable "batch_size" {
  default = "1"
}

variable "elb_scheme" {
  default = "internal"
}

variable "environment_type" {
  default = "LoadBalanced"
}

variable "lb_config_vars" {
  type        = list(map(string))
  description = "Elastic Beanstalk Load Balancer Configuration Variables"
  default     = []
}

variable "config_vars" {
  type        = list(map(string))
  description = "Elastic Beanstalk Application Configuration Variables"
  default     = []
}

variable "health_check_url" {
  default = ""
}

variable "health_system_type" {
  default = ""
}

variable "config_document" {
  default = ""
}

variable "min_instances" {
  default = "1"
}

variable "max_instances" {
  default = "2"
}

variable "availability_zones" {
  default = "Any 3"
}

variable "cross_zone" {
  default = "true"
}

variable "trigger_unit" {
  default = "Percent"
}

variable "measure_name" {
  default = "CPU"
}

variable "lower_threshold" {
  default = "20"
}

variable "upper_threshold" {
  default = "80"
}

variable "autoscale_period" {
  default = "5"
}

variable "upper_breach_scale_increment" {
  default = "1"
}

variable "lower_breach_scale_increment" {
  default = "-1"
}

variable "healthy_threshold" {
  default = ""
}

variable "health_check_interval" {
  default = ""
}

variable "health_check_timeout" {
  default = ""
}

variable "unhealthy_threshold" {
  default = ""
}

variable "eb_env_vars" {
  type        = map(string)
  description = "Elastic Beanstalk Environment Variables"
  default     = {}
}

variable "evaluated_eb_env_vars" {
  type        = map(string)
  description = "Elastic Beanstalk Environment Variables"
  default     = {}
}

data "aws_elastic_beanstalk_solution_stack" "stack" {
  most_recent = true
  name_regex  = var.name_regex
}

data "aws_elastic_beanstalk_application" "app" {
  name = var.application_name
}

data "aws_vpc" "vpc" {
  tags = {
    Name = var.vpc_name
  }
}

resource "aws_elastic_beanstalk_environment" "eb_environment" {
  name                   = var.environment_name
  application            = data.aws_elastic_beanstalk_application.app.id
  solution_stack_name    = data.aws_elastic_beanstalk_solution_stack.stack.name
  tier                   = var.tier
  wait_for_ready_timeout = var.wait_for_ready_timeout
  tags                   = var.tags

  # Applying EC2 IAM role
  setting {
    namespace = "aws:autoscaling:launchconfiguration"
    name      = "IamInstanceProfile"
    value     = var.iam_profile
  }

  # This is the size that the instances will use. example: t2.micro
  setting {
    namespace = "aws:autoscaling:launchconfiguration"
    name      = "InstanceType"
    value     = var.instance_size
  }

  # This is the size that the instances will use.
  setting {
    namespace = "aws:autoscaling:launchconfiguration"
    name      = "RootVolumeType"
    value     = var.root_volume_type
  }

  # This is the size that the instances will use.
 setting {
   namespace = "aws:autoscaling:launchconfiguration"
   name      = "RootVolumeSize"
   value     = var.root_volume_size
 }

  # SSH security group setting
  setting {
    namespace = "aws:autoscaling:launchconfiguration"
    name      = "SSHSourceRestriction"
    value     = "tcp,22,22,${var.web_sec_grp}"
  }

  # Set SSH key pair only if defined
  dynamic "setting" {
      for_each = var.key_pair != "" ? [var.key_pair] : []
      content {
          namespace = "aws:autoscaling:launchconfiguration"
          name      = "EC2KeyName"
          value     = setting.value
      }
  }

  # LB security group
  setting {
    namespace = "aws:elb:loadbalancer"
    name      = "ManagedSecurityGroup"
    value     = var.lb_sec_grp
  }

  # This is the VPC that the instances will use.
  setting {
    namespace = "aws:ec2:vpc"
    name      = "VPCId"
    value     = data.aws_vpc.vpc.id
  }

  # This is the security group
  setting {
    namespace = "aws:autoscaling:launchconfiguration"
    name      = "SecurityGroups"
    value     = var.web_sec_grp
  }

  # This is the subnets for the instances.
  setting {
    namespace = "aws:ec2:vpc"
    name      = "Subnets"
    value     = join(",", var.subnet_ids)
  }
  setting {
    namespace = "aws:ec2:vpc"
    name      = "AssociatePublicIpAddress"
    value     = var.associate_public_ip_address
  }

  # Environment Service Role
  setting {
    namespace = "aws:elasticbeanstalk:environment"
    name      = "ServiceRole"
    value     = "aws-elasticbeanstalk-service-role"
  }

  # Platform Updates
  setting {
    namespace = "aws:elasticbeanstalk:managedactions"
    name      = "ManagedActionsEnabled"
    value     = var.platform_update
  }

  # Platform Updates
  setting {
    namespace = "aws:elasticbeanstalk:managedactions"
    name      = "PreferredStartTime"
    value     = var.time_updates
  }

  # Platform Updates
  setting {
    namespace = "aws:elasticbeanstalk:managedactions:platformupdate"
    name      = "UpdateLevel"
    value     = var.platform_update_level
  }

  # Rolling update setting
  setting {
    namespace = "aws:autoscaling:updatepolicy:rollingupdate"
    name      = "RollingUpdateEnabled"
    value     = var.rolling_update
  }
  setting {
    namespace = "aws:autoscaling:updatepolicy:rollingupdate"
    name      = "RollingUpdateType"
    value     = var.rolling_update_type
  }
  setting {
    namespace = "aws:autoscaling:updatepolicy:rollingupdate"
    name      = "MaxBatchSize"
    value     = var.max_batch_size
  }

  # Rolling Deployment setting
  setting {
    namespace = "aws:elasticbeanstalk:command"
    name      = "DeploymentPolicy"
    value     = var.deployment_type
  }
  setting {
    namespace = "aws:elasticbeanstalk:command"
    name      = "BatchSizeType"
    value     = var.batch_size_type
  }
  setting {
    namespace = "aws:elasticbeanstalk:command"
    name      = "BatchSize"
    value     = var.batch_size
  }

  # This is the subnet of the ELB
  setting {
    namespace = "aws:ec2:vpc"
    name      = "ELBSubnets"
    value     = join(",", var.subnet_ids)
  }
  setting {
    namespace = "aws:ec2:vpc"
    name      = "ELBScheme"
    value     = var.elb_scheme
  }

  # You can set the environment type, single or LoadBalanced
  setting {
    namespace = "aws:elasticbeanstalk:environment"
    name      = "EnvironmentType"
    value     = var.environment_type
  }

  # The dynamic setting for Load Balancer Configuration
  dynamic "setting" {
      for_each = var.lb_config_vars
      content {
          namespace = setting.value["namespace"]
          name = setting.value["name"]
          value = setting.value["value"]
      }
  }

  # Adding Application Health check
  setting {
    namespace = "aws:elasticbeanstalk:application"
    name      = "Application Healthcheck URL"
    value     = "/${var.health_check_url}"
  }
  setting {
    namespace = "aws:elasticbeanstalk:healthreporting:system"
    name      = "SystemType"
    value     = var.health_system_type
  }
  setting {
    namespace = "aws:elasticbeanstalk:healthreporting:system"
    name      = "ConfigDocument"
    value     = var.config_document
  }

  # Minimum number of instances
  setting {
    namespace = "aws:autoscaling:asg"
    name      = "MinSize"
    value     = var.min_instances
  }

  # Maximum number of instances
  setting {
    namespace = "aws:autoscaling:asg"
    name      = "MaxSize"
    value     = var.max_instances
  }

  # Availability Zones options
  setting {
    namespace = "aws:autoscaling:asg"
    name      = "Availability Zones"
    value     = var.availability_zones
  }

  # Are the load balancers multizone?
  setting {
    namespace = "aws:elb:loadbalancer"
    name      = "CrossZone"
    value     = var.cross_zone
  }
  setting {
    namespace = "aws:autoscaling:trigger"
    name      = "Unit"
    value     = var.trigger_unit
  }
  setting {
    namespace = "aws:autoscaling:trigger"
    name      = "MeasureName"
    value     = var.measure_name
  }
  setting {
    namespace = "aws:autoscaling:trigger"
    name      = "LowerThreshold"
    value     = var.lower_threshold
  }
  setting {
    namespace = "aws:autoscaling:trigger"
    name      = "UpperThreshold"
    value     = var.upper_threshold
  }
  setting {
    namespace = "aws:autoscaling:trigger"
    name      = "Period"
    value     = var.autoscale_period
  }
  setting {
    namespace = "aws:autoscaling:trigger"
    name      = "UpperBreachScaleIncrement"
    value     = var.upper_breach_scale_increment
  }
  setting {
    namespace = "aws:autoscaling:trigger"
    name      = "LowerBreachScaleIncrement"
    value     = var.lower_breach_scale_increment
  }
  setting {
    namespace = "aws:elb:healthcheck"
    name      = "HealthyThreshold"
    value     = var.healthy_threshold
  }
  setting {
    namespace = "aws:elb:healthcheck"
    name      = "Interval"
    value     = var.health_check_interval
  }
  setting {
    namespace = "aws:elb:healthcheck"
    name      = "Timeout"
    value     = var.health_check_timeout
  }
  setting {
    namespace = "aws:elb:healthcheck"
    name      = "UnhealthyThreshold"
    value     = var.unhealthy_threshold
  }
  #Cloudwatch settings
  setting {
      namespace = "aws:elasticbeanstalk:cloudwatch:logs"
      name      = "DeleteOnTerminate"
      value     = "false"
  }
  setting {
      namespace = "aws:elasticbeanstalk:cloudwatch:logs"
      name      = "RetentionInDays"
      value     = "30"
  }
  setting {
      namespace = "aws:elasticbeanstalk:cloudwatch:logs"
      name      = "StreamLogs"
      value     = "true"
  }

  # Setting environment variables

  # The dynamic setting for configuration settings of application
  dynamic "setting" {
      for_each = var.config_vars
      content {
          namespace = setting.value["namespace"]
          name = setting.value["name"]
          value = setting.value["value"]
      }
  }

  # The dynamic setting only works with TF 0.12 and higher
  dynamic "setting" {
      for_each = var.eb_env_vars
      content {
          namespace = "aws:elasticbeanstalk:application:environment"
          name      = setting.key
          value     = setting.value
      }
  }
  dynamic "setting" {
      for_each = var.evaluated_eb_env_vars
      content {
          namespace = "aws:elasticbeanstalk:application:environment"
          name      = setting.key
          value     = setting.value
      }
  }
}
