# Elastic Beanstalk Environment Outputs

# Elastic Beanstalk ID
output "eb_id" {
  value = aws_elastic_beanstalk_environment.eb_environment.id
}

# Elastic Beanstalk Name
output "eb_name" {
  value = aws_elastic_beanstalk_environment.eb_environment.name
}

# Elastic Beanstalk Description
output "eb_description" {
  value = aws_elastic_beanstalk_environment.eb_environment.description
}

# Elastic Beanstalk Tier
output "eb_tier" {
  value = aws_elastic_beanstalk_environment.eb_environment.tier
}

# Elastic Beanstalk Application
output "eb_application" {
  value = aws_elastic_beanstalk_environment.eb_environment.application
}

# Elastic Beanstalk Setting
output "eb_setting" {
  value = aws_elastic_beanstalk_environment.eb_environment.setting
}

# Elastic Beanstalk All Settings
output "eb_all_settings" {
  value = aws_elastic_beanstalk_environment.eb_environment.all_settings
}

# Elastic Beanstalk CNAME
output "eb_cname" {
  value = aws_elastic_beanstalk_environment.eb_environment.cname
}

# Elastic Beanstalk Autoscaling Groups
output "eb_autoscaling_groups" {
  value = aws_elastic_beanstalk_environment.eb_environment.autoscaling_groups
}

# Elastic Beanstalk Instances
output "eb_instances" {
  value = aws_elastic_beanstalk_environment.eb_environment.instances
}

# Elastic Beanstalk Launch Configurations
output "eb_launch_configurations" {
  value = aws_elastic_beanstalk_environment.eb_environment.launch_configurations
}

# Elastic Beanstalk Load Balancers
output "eb_load_balancers" {
  value = aws_elastic_beanstalk_environment.eb_environment.load_balancers
}

# Elastic Beanstalk Queues
output "eb_queues" {
  value = aws_elastic_beanstalk_environment.eb_environment.queues
}

# Elastic Beanstalk Triggers
output "eb_triggers" {
  value = aws_elastic_beanstalk_environment.eb_environment.triggers
}

# Elastic Beanstalk End Point URL
output "eb_endpoint_url" {
  value = aws_elastic_beanstalk_environment.eb_environment.endpoint_url
}
