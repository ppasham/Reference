# tf-elasticbeanstalk
AWS Elastic Beanstalk Module

## Description

### Elastic Beanstalk Application
Provides an Elastic Beanstalk Application Resource. Elastic Beanstalk allows you to deploy and manage applications in the AWS cloud without worrying about the infrastructure that runs those applications.
### Elastic Beanstalk Application Version
Provides an Elastic Beanstalk Application Version Resource. Elastic Beanstalk allows you to deploy and manage applications in the AWS cloud without worrying about the infrastructure that runs those applications.
### Elastic Beanstalk Environment
Provides an Elastic Beanstalk Environment Resource. Elastic Beanstalk allows you to deploy and manage applications in the AWS cloud without worrying about the infrastructure that runs those applications.

## Usage

### Elastic Beanstalk Application
```tf
resource "aws_elastic_beanstalk_application" "application" {
  name        = var.name
  description = var.description

  appversion_lifecycle {
    service_role          = var.service_role
    max_count             = 50
    delete_source_from_s3 = var.delete_source_from_s3
  }
}
```

Conditions applied in this module have the following set:

| Value  | Required | Default | Description |
| ------------- | ------------- | ------------- | ------------- |
| name          | Yes | No   | The Application Name
| description | Yes | No | The Description of the Application
| service_role | Yes | No | The ARN of an IAM service role under which the application version is deleted. Elastic Beanstalk must have permission to assume this role.
| delete_source_from_s3 | Yes | No | Set to true to delete a version's source bundle from S3 when the application version is deleted.


### Elastic Beanstalk Application Version
```tf
resource "aws_elastic_beanstalk_application_version" "application_version" {
  name        = var.artifact_version_name
  application = var.application_name
  description = var.description
  bucket      = var.bucket_name
  key         = var.key
}
```

Conditions applied in this module have the following set:

| Value  | Required | Default | Description |
| ------------- | ------------- | ------------- | ------------- |
| name          | Yes | No   | A unique name for the this Application Version
| application | Yes | No | Name of the Beanstalk Application the version is associated with.
| description | Yes | No | Short description of the Application Version.
| bucket | Yes | No | S3 bucket that contains the Application Version source bundle.
| key | Yes | No | S3 object that is the Application Version source bundle.

### Elastic Beanstalk Environment
```tf
data "aws_elastic_beanstalk_solution_stack" "stack" {
  most_recent = true
  name_regex  = var.name_regex
}

data "aws_elastic_beanstalk_application" "app" {
  name = var.application_name
}

data "aws_vpc" "vpc" {
  tags = {
    Name = var.vpc_name
  }
}

resource "aws_elastic_beanstalk_environment" "eb_environment" {
  name                   = var.environment_name
  application            = data.aws_elastic_beanstalk_application.app.id
  solution_stack_name    = data.aws_elastic_beanstalk_solution_stack.stack.name
  tier                   = var.tier
  wait_for_ready_timeout = var.wait_for_ready_timeout
  tags                   = var.tags
}
```

Conditions applied in this module have the following set:

| Value  | Required | Default | Description |
| ------------- | ------------- | ------------- | ------------- |
| name_regex | Yes | No   | The regular expression to match solution stack name.
| application_name | Yes | No   | The name of the Elastic Beanstalk application.
| vpc_name      | Yes  | No | The name of the VPC where the Elastic Beanstalk is located.
| environment_name | Yes | No | The name of the Elastic Beanstalk environment.
| tier | Yes | WebServer | The Elastic Beanstalk tier.
| wait_for_ready_timeout | Yes | 20m | The maximum duration that Terraform should wait for an Elastic Beanstalk Environment to be in a ready state before timing out.
| tags | Yes | No | A set of tags to apply to the Environment.

### Dynamic Settings example:

```tf
variable "lb_config_vars" {
  type        = list(map(string))
  description = "Elastic Beanstalk Load Balancer Configuration Variables"
  default     = [
   {
    namespace = "aws:elasticbeanstalk:environment"
    name      = "LoadBalancerType"
    value     = "application"
   },
   {
    namespace = "aws:elbv2:listener:default"
    name      = "ListenerEnabled"
    value     = "true"
   }
  ]
}

# The dynamic setting for Load Balancer Configuration
dynamic "setting" {
    for_each = var.lb_config_vars
    content {
        namespace = setting.value["namespace"]
        name = setting.value["name"]
        value = setting.value["value"]
    }
}
```

```tf
variable "eb_env_vars" {
  type        = map(string)
  description = "Elastic Beanstalk Environment Variables"
  default     = {NEW_RELIC_HIGH_SECURITY=true, NEW_RELIC_DISTRIBUTED_TRACING_ENABLED=true}
}

dynamic "setting" {
    for_each = var.eb_env_vars
    content {
        namespace = "aws:elasticbeanstalk:application:environment"
        name      = setting.key
        value     = setting.value
    }
}
```
```tf

variable "evaluated_eb_env_vars" {
  type        = map(string)
  description = "Elastic Beanstalk Environment Variables"
  default     = {SPLUNK_INDEX="dt-cms_app", SPLUNK_BUCKET="cms-resources-np", SPLUNK_TEAM="${env.TEAM}", NEW_RELIC_LICENSE_KEY="${NEW_RELIC_LICENSE_KEY}"}
}

dynamic "setting" {
    for_each = var.evaluated_eb_env_vars
    content {
        namespace = "aws:elasticbeanstalk:application:environment"
        name      = setting.key
        value     = setting.value
    }
}

```

Additional Resources for Elastic Beanstalk Environment Configuration:

[Elastic Beanstalk Options](https://docs.aws.amazon.com/elasticbeanstalk/latest/dg/command-options.html)

[Terraform Dynamic Blocks](https://www.terraform.io/docs/configuration/expressions.html#dynamic-blocks)
