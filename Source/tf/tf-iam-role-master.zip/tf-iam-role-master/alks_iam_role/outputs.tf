# IAM Role output file

# IAM ID resource output
output "iam_role_id" {
  value = alks_iamrole.iam_role.id
}

output "iam_role_name" {
  value = alks_iamrole.iam_role.name
}

output "iam_role_arn" {
  value = alks_iamrole.iam_role.arn
}
