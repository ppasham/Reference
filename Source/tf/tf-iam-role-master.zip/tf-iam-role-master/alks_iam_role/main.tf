# Terraform IAM Role Module
#
##########################################################################################
# Module maintainer: CMS Platform Engineering Services                                   #
# Contact: CMS-SuperSmashCrew@coxautoinc.com                                             #
#                                                                                        #
# Description: IAM Role Creation using ALKS Resource                                     #
# README: https://ghe.coxautoinc.com/cms-terraform/tf-iam-role/blob/master/README.md     #
# ___________________                                                                    #
#                                                                                        #
#  Copyright 2019 Cox Automotive Incorporated                                            #
#  All Rights Reserved.                                                                  #
#                                                                                        #
##########################################################################################

# Requirements
terraform {
  required_version = ">= 0.12"
  required_providers {
    alks = {
      source  = "cox-automotive/alks"
      version = ">= 2.7.0"
    }
  }
}

# Variables
variable "role_name" {
  type        = string
  description = "(Required) The name of the ALKS IAM role which will be reflected in AWS and the ALKS UI."
}

variable "service_type" {
  type        = string
  description = <<EOT
(Required) The role type to use. Example: 'Amazon EC2', 'AWS Lambda'.

To see a list of available roles, call

curl -X GET "https://alks.coxautoinc.com/rest/allAwsRoleTypes" -H "accept: */*" -H "ALKS-STS-Access-Key: AWS_ACCESS_KEY" \
     -H "ALKS-STS-Secret-Key: AWS_SECRET_KEY" -H "ALKS-STS-Session-Token: AWS_TOKEN".
EOT
}

variable "default_policies" {
  type        = bool
  default     = false
  description = <<EOT
(Required) Whether or not the default managed policies should be attached to the new role.

To see which policies are included by default inspect 'defaultArns' key for the requested role type in the response
from https://alks.coxautoinc.com/rest/allAwsRoleTypes API
EOT
}

variable "alks_access" {
  type        = bool
  default     = false
  description = <<EOT
(Optional) If true, allows ALKS calls to be made by instance profiles or Lambda functions making use of this role.
Note: This enables machine identity capability.
EOT
}

variable "tags" {
  type        = map(string)
  default     = {}
  description = " A map of tags to assign to the resource"
}

# ALKS IAM Role
resource "alks_iamrole" "iam_role" {
  name                     = var.role_name
  type                     = var.service_type
  include_default_policies = var.default_policies
  enable_alks_access       = var.alks_access
  tags                     = var.tags
}
