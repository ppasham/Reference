# Terraform IAM Trust Role Module
#
##########################################################################################
# Module maintainer: CMS Platform Engineering Services                                   #
# Contact: CMS-SuperSmashCrew@coxautoinc.com                                             #
#                                                                                        #
# Description: IAM Role Creation using ALKS Resource                                     #
# README: https://ghe.coxautoinc.com/cms-terraform/tf-iam-role/blob/master/README.md     #
# ___________________                                                                    #
#                                                                                        #
#  Copyright 2022 Cox Automotive Incorporated                                            #
#  All Rights Reserved.                                                                  #
#                                                                                        #
##########################################################################################

# Requirements
terraform {
  required_version = ">= 0.12"
  required_providers {
    alks = {
      source  = "cox-automotive/alks"
      version = ">= 2.7.0"
    }
  }
}

# Variables
variable "role_name" {
  type        = string
  description = "(Required) The name of the ALKS IAM role which will be reflected in AWS and the ALKS UI."
}

variable "role_type" {
  type        = string
  description = "(Required) The role type to use Cross Account or Inner Account."
}

variable "trust_arn" {
  type        = string
  description = "(Required) Account role ARN to trust."
}

variable "alks_access" {
  type        = bool
  default     = false
  description = <<EOT
(Optional) If true, allows ALKS calls to be made by instance profiles or Lambda functions making use of this role.
Note: This enables machine identity capability.
EOT
}

variable "tags" {
  type        = map(string)
  default     = {}
  description = " A map of tags to assign to the resource"
}

resource "alks_iamtrustrole" "iam_trust_role" {
  name               = var.role_name
  type               = var.role_type
  trust_arn          = var.trust_arn
  enable_alks_access = var.alks_access
  tags               = var.tags
}
