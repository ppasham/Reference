# IAM Role output file

# IAM ID resource output
output "iam_role_id" {
  value = alks_iamrole.iam_role_with_trust_policies.id
}

output "iam_role_name" {
  value = alks_iamrole.iam_role_with_trust_policies.name
}

output "iam_role_arn" {
  value = alks_iamrole.iam_role_with_trust_policies.arn
}
