# tf-iam-role
AWS ALKS IAM Role Terraform Module

## Description
ALKS IAM Role resource is specific to creating IAM Roles in Cox Automtive AWS Accounts. This module creates a base IAM Role that is tied to an AWS service.
Links to ALKS documentation:
* ALKS Provider Sharepoint - [ALKS Provider](https://coxautoinc.sharepoint.com/sites/department-accessone/SitePages/Terraform%20ALKS%20on%20Non-Prod%20and%20Prod%20(created%20on%202018-04-06).aspx)
* ALK Provider Repo - [ALKS Git Repo](https://github.com/Cox-Automotive/terraform-provider-alks)

## Usage

### Resource Configuration

#### `alks_iamrole`

```tf
resource "alks_iamrole" "test_role" {
    name                     = "My_Test_Role"
    type                     = "Amazon EC2"
    include_default_policies = false
    enable_alks_access       = false
}
```

Value                             | Type     | Forces New | Value Type | Description
--------------------------------- | -------- | ---------- | ---------- | -----------
`name`                           | Required | yes        | string     | The name of the IAM role to create. This parameter allows a string of characters consisting of upper and lowercase alphanumeric characters with no spaces. You can also include any of the following characters: =,.@-. Role names are not distinguished by case.
`type`                           | Required | yes        | string     | The role type to use. [Available Roles](https://gist.github.com/brianantonelli/5769deff6fd8f3ff30e40b844f0b1fb4)
`include_default_policies`                           | Required | yes        | bool     | Whether or not the default managed policies should be attached to the role.
`role_added_to_ip`                           | Computed | n/a        | bool     | Indicates whether or not an instance profile role was created.
`arn`                           | Computed | n/a        | string     | Provides the ARN of the role that was created.
`ip_arn`                           | Computed | n/a        | string     | If `role_added_to_ip` was `true` this will provide the ARN of the instance profile role.
`enable_alks_access` | Optional | yes | bool | If true, allows ALKS calls to be made by instance profiles or Lambda functions making use of this role.
`tags` | Optional | yes | map(string) | The tags to apply to taggable resources.

#### `alks_iamrole with trust policies`

```tf
resource "alks_iamrole" "iam_role_with_trust_policies" {
  name                     = var.role_name
  assume_role_policy       = file("./${var.role_policy}")
  include_default_policies = var.default_policies
  enable_alks_access       = var.alks_access
  tags                     = var.tags
}
```

Value                             | Type     | Forces New | Value Type | Description
--------------------------------- | -------- | ---------- | ---------- | -----------
`name`                           | Required | yes        | string     | The name of the IAM role to create. This parameter allows a string of characters consisting of upper and lowercase alphanumeric characters with no spaces. You can also include any of the following characters: =,.@-. Role names are not distinguished by case.
`assume_role_policy`                           | Required | yes        | NA   | The policy document. This is a JSON formatted string.
`include_default_policies`                           | Required | yes        | bool     | Whether or not the default managed policies should be attached to the role.
`enable_alks_access` | Optional | yes | bool | If true, allows ALKS calls to be made by instance profiles or Lambda functions making use of this role.
`tags` | Optional | yes | map(string) | The tags to apply to taggable resources. 

#### `alks_iamtrustrole`

```tf
resource "alks_iamtrustrole" "iam_trust_role" {
  name               = var.role_name
  type               = var.role_type
  trust_arn          = var.trust_arn
  enable_alks_access = var.alks_access
  tags               = var.tags
}
```

Value                             | Type     | Forces New | Value Type | Description
--------------------------------- | -------- | ---------- | ---------- | -----------
`name`                           | Required | yes        | string     | The name of the IAM role to create. This parameter allows a string of characters consisting of upper and lowercase alphanumeric characters with no spaces. You can also include any of the following characters: =,.@-. Role names are not distinguished by case.
`type`                           | Required | yes        | string     | The role type to use. [Available Roles](https://gist.github.com/brianantonelli/5769deff6fd8f3ff30e40b844f0b1fb4)
`trust_arn`                           | Computed | n/a        | string     | Provides the ARN of the role that was created.
`enable_alks_access` | Optional | yes | bool | If true, allows ALKS calls to be made by instance profiles or Lambda functions making use of this role.
`tags` | Optional | yes | map(string) | The tags to apply to taggable resources.
