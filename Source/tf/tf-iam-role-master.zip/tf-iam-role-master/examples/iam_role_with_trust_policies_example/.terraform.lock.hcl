# This file is maintained automatically by "terraform init".
# Manual edits may be lost in future updates.

provider "registry.terraform.io/cox-automotive/alks" {
  version     = "2.7.1"
  constraints = ">= 2.7.0"
  hashes = [
    "h1:ZNYnmUhRPU2sEoEX0BclJd68IfKt//VXNnnbd/p4LDI=",
    "zh:1e4a6c23750643c7d476d695152607a620b0fe429fcfc96c9ef0514d88ab9f14",
    "zh:22a7d7c776fbad6fbd3fce3af4cd7a2cd11b7c4eab044d0b257f6c465226e62c",
    "zh:2b673adbff6ed8af6e04a3d65d7adf7bec28c30e463cc3ab6b31d495ed9b7428",
    "zh:2d891a2aa5327e232951bb0e4629749b174929a9a502e00ba6ff3e8096b0bb5c",
    "zh:42f7ffbd5b4131b06edce33431c9eb6c21bafef537c5660be59832abdc7cf18f",
    "zh:59acac135b8fa889f4e75ed904af225093b271fb95583250f79483c61dbd35b3",
    "zh:7290a73394da961838463679a42743e97524f3e5d8a0aee03c95f2202b8dcb2f",
    "zh:7f063ae4b9435520f43e98b37f6cfb65470b3188ea2cd37c12e47116e5ae196a",
    "zh:820f528b2ab95335cab44bf57ea5515b91c13ff09c20e1e0a7a9d14f0cfa9ea1",
    "zh:89d5c2ad4d2c6edc7c94ee18413b7a9ed4fb6d45d055daede90087635da0b1d6",
    "zh:ca5ed062cf45f4c7595a78752020e13f09ce48e9a84c3d591f27135f6148f9d5",
    "zh:d2e4b67b76d9711367d5840f4478f283f7c721693494a727b32cc2a578491791",
    "zh:e9aa4a2f7d4bf041bc246866a556b6be86bf4c2e55da0848361671495572801f",
    "zh:f29f17f76f04626a4601ea6a90d142877945822bd0c168c9da3a5c0c67d22c0b",
  ]
}

provider "registry.terraform.io/hashicorp/aws" {
  version = "4.56.0"
  hashes = [
    "h1:koDunHl/LUmCAKy3VFie6MakXN7ng93v8HBRpKI8He8=",
    "zh:1d2b7693a102da015a86b9235b554272b9280597011216c3ddd1a6dc95ad8dab",
    "zh:28c3e8ebaa077f65c4ac5fd051c95887070293fcff0386dfc2e4b7e248a0aefa",
    "zh:2a620bc4a87be06e7acac1bc15e966dba45df643bf6c3efb811e74e6c2122b03",
    "zh:30d3ac148fa0634e7ba1de66e1af1328481c92cd774adcfc0e27f828103b17e0",
    "zh:3d3eebf916f25e11b12dd3c692f8fe1e4c4e9a0c414af9d0d881ddebd28dcd39",
    "zh:3f4600f2881c02fcc69080df68747c9a0b9b11cb002117fd918b7800f2ac402b",
    "zh:7156fb12c3b4f2964f7e78cee97f31d95b43045467f90749d2ed545725c36baa",
    "zh:9b12af85486a96aedd8d7984b0ff811a4b42e3d88dad1a3fb4c0b580d04fa425",
    "zh:a5bbc84fd37d468c7b016009776b6d2a287bbb746af81aba786cdf8eb5fce4a1",
    "zh:d5322bcd4e11caddbbfaa1198893824d4b4d28f504517a3a87902cf86d75bd87",
    "zh:d766eb9f86a40060d63e12ef674d7c9c47ec4e47ade487f1f49af8c89b441711",
    "zh:df23f592b99f6617f09e449009bbb49068a69fc926b15ca29e30b068c9c67365",
    "zh:e7b0acee2d98549731547259b539f598e18db07c0c202d3a34b922beff711054",
    "zh:ec317f79fdcce934c39458ea312862e7f7ec48cafb8bcc9b5a00d9b78b629d81",
    "zh:f78ec7a771867d96dfee96bf74523341ba42feeb64ce2f108b5bf2e7ebef0fef",
  ]
}
