# Terraform IAM Role with Trust Policy Deployment Script

# ALKS IAM Reference
# https://github.com/Cox-Automotive/terraform-provider-alks

terraform {
  required_version = ">= 0.12"
  required_providers {
    alks = {
      source  = "cox-automotive/alks"
      version = ">=2.7.0"
    }
  }
}

# Variables
variable "region" {
  type        = string
  default     = "us-west-2"
  description = "AWS Region"
}

variable "example_role_name" {
  type        = string
  default     = "my-iam-role-with-trust-policy"
  description = "Name of IAM Role"
}

variable "example_policy_file_name" {
  type        = string
  default     = "policy.json"
  description = "IAM Service Type"
}

variable "default_policies" {
  type        = bool
  default     = true
  description = "Whether or not the default managed policies should be attached to the role"
}

variable "alks_access" {
  type        = bool
  default     = false
  description = "If true, allows ALKS calls to be made by instance profiles or Lambda functions making use of this role"
}

variable "tags" {
  type        = map(string)
  default     = {
    Name        = "my-iam-role-with-trust-policy"
    Environment = "Test"
    Owner       = "Me-Myself-And-I"
  }
  description = "A mapping of tags to assign to the object"
}

# ALKS & AWS Providers
# ALKS Provider
provider "alks" {
  url = "https://alks.coxautoinc.com/rest"
}

provider "aws" {
  region = var.region
}

# S3 Backend
terraform {
  backend "s3" {
  }
}

# IAM Role Creation
module "example_role" {
  source           = "git@ghe.coxautoinc.com:cms-terraform/tf-iam-role.git//alks_iam_role_with_trust_policies"
  role_name        = var.example_role_name
  role_policy      = var.example_policy_file_name
  default_policies = var.default_policies
  alks_access      = var.alks_access
  tags             = var.tags
}
