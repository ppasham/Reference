# Terraform Iam Trust Role Deployment Script

# ALKS IAM Reference
# https://github.com/Cox-Automotive/terraform-provider-alks

terraform {
  required_version = ">= 0.12"
  required_providers {
    alks = {
      source  = "cox-automotive/alks"
      version = ">=2.7.0"
    }
  }
}

# Variables
variable "region" {
  type        = string
  default     = "us-west-2"
  description = "AWS Region"
}

variable "example_role_name" {
  type        = string
  default     = "my-trust-role"
  description = "Name of IAM Role"
}

variable "example_role_type" {
  type        = string
  default     = "Cross Account"
  description = "IAM Service Type"
}

variable "trust_arn" {
  type        = string
  default     = "arn:aws:iam::123456789123:role/acct-managed/TestTrustRole"
  description = "(Required) Account role ARN to trust."
}

variable "alks_access" {
  type        = bool
  default     = false
  description = "If true, allows ALKS calls to be made by instance profiles or Lambda functions making use of this role"
}

variable "tags" {
  type        = map(string)
  default     = {
    Name        = "my-trust-role"
    Environment = "Test"
    Owner       = "Me-Myself-And-I"
  }
  description = "A mapping of tags to assign to the object"
}

# ALKS & AWS Providers
# ALKS Provider
provider "alks" {
  url = "https://alks.coxautoinc.com/rest"
}

provider "aws" {
  region = var.region
}

# S3 Backend
terraform {
  backend "s3" {
  }
}

# IAM Role Creation
module "example_role" {
  source      = "git@ghe.coxautoinc.com:cms-terraform/tf-iam-role.git//alks_iamtrust_role"
  role_name   = var.example_role_name
  role_type   = var.example_role_type
  trust_arn   = var.example_trust_arn
  alks_access = var.alks_access
  tags        = var.tags
}
