# WAF Regional Regex Match Set Output
output "regex_match_set_id" {
  value = aws_wafregional_regex_match_set.regex_match_set.id
}

output "regex_match_set_name" {
  value = aws_wafregional_regex_match_set.regex_match_set.name
}