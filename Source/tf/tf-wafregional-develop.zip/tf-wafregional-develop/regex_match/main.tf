# Terraform WAF Regional Regex Match Set Instance Module
#
##########################################################################################
# Module maintainer: CMS Platform Engineering Services                                   #
# Contact: CMS-SuperSmashCrew@coxautoinc.com                                             #
#                                                                                        #
# Description: WAF Creation                                                              #
# README: https://ghe.coxautoinc.com/cms-terraform/tf-wafregional/blob/master/README.md  #
# ___________________                                                                    #
#                                                                                        #
#  Copyright 2019 Cox Automotive Incorporated                                            #
#  All Rights Reserved.                                                                  #
#                                                                                        #
##########################################################################################

terraform {
  required_version = ">= 0.12"
}

# Variables
variable "name" {
  default = ""
}

variable "match_tuples" {
  type = list(object({
    regex_pattern_set_id = string
    text_transform = string
    field_match = object({
      type = string
      data = string
    })
  }))
}

# Resources
resource "aws_wafregional_regex_match_set" "regex_match_set" {
  name = var.name

  dynamic "regex_match_tuple" {
    for_each = var.match_tuples
    content {
      regex_pattern_set_id = regex_match_tuple.value["regex_pattern_set_id"]
      text_transformation = regex_match_tuple.value["text_transform"]

      field_to_match {
        type = regex_match_tuple.value["field_match"]["type"]
        data = regex_match_tuple.value["field_match"]["data"] == "" ? null : regex_match_tuple.value["field_match"]["data"]
      }
    }
  }
}