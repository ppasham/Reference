# tf-wafregional

AWS WAF Regional Terraform Module

## Description

Terraform module which creates an AWS WAF Regional with associated ipsets, rules, acl's, etc.

### NOTE
_There are two separate repositories for WAF and WAFRegional implemetation. You are currently viewing the WAFRegional module repository. The WAF repository can be found [here](https://ghe.coxautoinc.com/cms-terraform/tf-waf)._

## Usage

### aws_wafregional_byte_match_set

```hcl
resource "aws_wafregional_byte_match_set" "byte_match_set" {
  name = var.name

  dynamic "byte_match_tuples" {
    for_each = var.match_tuples
    content {
      text_transformation = byte_match_tuples.value["text_transform"]
      target_string = byte_match_tuples.value["target_string"]
      positional_constraint = byte_match_tuples.value["positional_constraint"]

      field_to_match {
        type = byte_match_tuples.value["field_match"]["type"]
        data = byte_match_tuples.value["field_match"]["data"] == "" ? null : byte_match_tuples.value["field_match"]["data"]
      }
    }
  }
}
```

Conditions applied in this module have the following set:

| Value        | Type     | Value Type   | Description                                    |
|--------------|----------|--------------|------------------------------------------------|
| name         | Required | string       | The name of the byte match set to create.      |
| match_tuples | Required | list(object) | A list of byte_match_tuples. Documented below. |

__match_tuples__

| Value                 | Type     | Value Type | Description                                                                                 |
|-----------------------|----------|------------|---------------------------------------------------------------------------------------------|
| text_transform        | Required | string     | The formatting way for web request.                                                         |
| target_string         | Required | string     | The value that you want AWS WAF to search for. The maximum length of the value is 50 bytes. |
| positional_constraint | Required | string     | Within the portion of a web request that you want to search.                                |
| field_match           | Required | object     | Settings for the ByteMatchTuple. Documented below.                                          |

__field_match__

| Value | Type     | Value Type | Description                                                                                                                                                                             |
|-------|----------|------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| type  | Required | string     | The part of the web request that you want AWS WAF to search for a specified string.                                                                                                     |
| data  | Optional | string     | When the value of Type is HEADER, enter the name of the header that you want AWS WAF to search, for example, User-Agent or Referer. If the value of Type is any other value, omit Data. |

----------

### aws_wafregional_geo_match_set

```hcl
resource "aws_wafregional_geo_match_set" "geo_match_set" {
  name = var.name

  dynamic "geo_match_constraint" {
    for_each = var.geo_matches
    content {
      type = geo_match_constraint.value["type"]
      value = geo_match_constraint.value["value"]
    }
  }
}
```

Conditions applied in this module have the following set:

| Value       | Type     | Value Type   | Description                                                                                                       |
|-------------|----------|--------------|-------------------------------------------------------------------------------------------------------------------|
| name        | Required | string       | The name or description of the Geo Match Set.                                                                     |
| geo_matches | Required | list(object) | The Geo Match Constraint objects which contain the country that you want AWS WAF to search for. Documented below. |

__geo_matches__

| Value | Type     | Value Type | Description                                                                                                     |
|-------|----------|------------|-----------------------------------------------------------------------------------------------------------------|
| type  | Required | string     | The type of geographical area you want AWS WAF to search for. Currently Country is the only valid value.        |
| value | Required | string     | The country that you want AWS WAF to search for. This is the two-letter country code, e.g. US, CA, RU, CN, etc. |

----------

### aws_wafregional_ipset

```hcl
resource "aws_wafregional_ipset" "ipset" {
  name = var.name

  dynamic "ip_set_descriptor" {
    for_each = var.set_descriptors
    content {
      type = ip_set_descriptor.value["type"]
      value = ip_set_descriptor.value["value"]
    }
  }
}
```

Conditions applied in this module have the following set:

| Value           | Type     | Value Type   | Description                                                                                                                                                      |
|-----------------|----------|--------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| name            | Required | string       | The name or description of the IPSet.                                                                                                                            |
| set_descriptors | Required | list(object) | One or more pairs specifying the IP address type (IPV4 or IPV6) and the IP address range (in CIDR notation) from which web requests originate. Documented below. |

__set_descriptors__

| Value | Type     | Value Type | Description                   |
|-------|----------|------------|-------------------------------|
| type  | Required | string     | The string like IPV4 or IPV6. |
| value | Required | string     | The CIDR notation.            |

----------

### aws_wafregional_rate_based_rule

```hcl
resource "aws_wafregional_rate_based_rule" "rate_based_rule" {
  metric_name = var.metric_name
  name = var.name
  rate_key = var.rate_key
  rate_limit = var.rate_limit

  dynamic "predicate" {
    for_each = var.predicates
    content {
      data_id = predicate.value["data_id"]
      negated = predicate.value["negated"]
      type = predicate.value["type"]
    }
  }
}
```

Conditions applied in this module have the following set:

| Value       | Type     | Value Type   | Description                                                                                                                                                 |
|-------------|----------|--------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------|
| name        | Required | string       | The name or description of the rule.                                                                                                                        |
| metric_name | Required | string       | The name or description for the Amazon CloudWatch metric of this rule.                                                                                      |
| rate_key    | Required | string       | Valid value is IP.                                                                                                                                          |
| rate_limit  | Required | number       | The maximum number of requests, which have an identical value in the field specified by the RateKey, allowed in a five-minute period. Minimum value is 100. |
| predicates  | Required | list(object) | The objects to include in a rule. Documented below.                                                                                                         |

__predicates__

| Value   | Type     | Value Type | Description                                                                                                                                                                                                                                                                                                                                                                                                                 |
|---------|----------|------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| data_id | Required | string     | A unique identifier for a predicate in the rule, such as Byte Match Set ID or IPSet ID.                                                                                                                                                                                                                                                                                                                                     |
| negated | Required | boolean    | Set this to false if you want to allow, block, or count requests based on the settings in the specified ByteMatchSet, IPSet, SqlInjectionMatchSet, XssMatchSet, or SizeConstraintSet. For example, if an IPSet includes the IP address 192.0.2.44, AWS WAF will allow or block requests based on that IP address. If set to true, AWS WAF will allow, block, or count requests based on all IP addresses except 192.0.2.44. |
| type    | Required | string     | The type of predicate in a rule. Valid values: ByteMatch, GeoMatch, IPMatch, RegexMatch, SizeConstraint, SqlInjectionMatch, or XssMatch.                                                                                                                                                                                                                                                                                    |

----------

### aws_wafregional_regex_match_set

```hcl
resource "aws_wafregional_regex_match_set" "regex_match_set" {
  name = var.name

  dynamic "regex_match_tuple" {
    for_each = var.match_tuples
    content {
      regex_pattern_set_id = regex_match_tuple.value["regex_pattern_set_id"]
      text_transformation = regex_match_tuple.value["text_transform"]

      field_to_match {
        type = regex_match_tuple.value["field_match"]["type"]
        data = regex_match_tuple.value["field_match"]["data"] == "" ? null : regex_match_tuple.value["field_match"]["data"]
      }
    }
  }
}
```

Conditions applied in this module have the following set:

| Value        | Type     | Value Type   | Description                                                                                                                                                                         |
|--------------|----------|--------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| name         | Required | string       | The name or description of the Regex Match Set.                                                                                                                                     |
| match_tuples | Required | list(object) | The regular expression pattern that you want AWS WAF to search for in web requests, the location in requests that you want AWS WAF to search, and other settings. Documented below. |

__match_tuples__

| Value                | Type     | Value Type | Description                                                                                                                                                             |
|----------------------|----------|------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| regex_pattern_set_id | Required | string     | The ID of a Regex Pattern Set.                                                                                                                                          |
| text_transform       | Required | string     | Text transformations used to eliminate unusual formatting that attackers use in web requests in an effort to bypass AWS WAF. e.g. CMD_LINE, HTML_ENTITY_DECODE or NONE. |
| field_match          | Required | object     | The part of a web request that you want to search, such as a specified header or a query string. Documented below.                                                      |

__field_match__

| Value | Type     | Value Type | Description                                                                                                                                         |
|-------|----------|------------|-----------------------------------------------------------------------------------------------------------------------------------------------------|
| type  | Required | string     | The part of the web request that you want AWS WAF to search for a specified string. e.g. HEADER, METHOD or BODY.                                    |
| data  | Optional | string     | When type is HEADER, enter the name of the header that you want to search, e.g. User-Agent or Referer. If type is any other value, omit this field. |

----------

### aws_wafregional_regex_pattern_set

```hcl
resource "aws_wafregional_regex_pattern_set" "regex_pattern_set" {
  name = var.name
  regex_pattern_strings = var.pattern_strings
}
```

Conditions applied in this module have the following set:

| Value           | Type     | Value Type   | Description                                                                                              |
|-----------------|----------|--------------|----------------------------------------------------------------------------------------------------------|
| name            | Required | string       | The name or description of the Regex Pattern Set.                                                        |
| pattern_strings | Required | list(string) | A list of regular expression (regex) patterns that you want AWS WAF to search for, such as B[a@]dB[o0]t. |

----------

### aws_wafregional_rule

```hcl
resource "aws_wafregional_rule" "rule" {
  name = var.name
  metric_name = var.metric_name

  dynamic "predicate" {
    for_each = var.predicates
    content {
      data_id = predicate.value["data_id"]
      negated = predicate.value["negated"]
      type = predicate.value["type"]
    }
  }
}
```

Conditions applied in this module have the following set:

| Value       | Type     | Value Type   | Description                                                            |
|-------------|----------|--------------|------------------------------------------------------------------------|
| name        | Required | string       | The name or description of the rule.                                   |
| metric_name | Required | string       | The name or description for the Amazon CloudWatch metric of this rule. |
| predicates  | Required | list(object) | The objects to include in a rule. Documented below.                    |

__predicates__

| Value   | Type     | Value Type | Description                                                                                                                             |
|---------|----------|------------|-----------------------------------------------------------------------------------------------------------------------------------------|
| data_id | Required | string     | The unique identifier of a predicate, such as the ID of a ByteMatchSet or IPSet.                                                        |
| negated | Required | bool       | Whether to use the settings or the negated settings that you specified in the objects.                                                  |
| type    | Required | string     | The type of predicate in a rule. Valid values: ByteMatch, GeoMatch, IPMatch, RegexMatch, SizeConstraint, SqlInjectionMatch, or XssMatch |

----------

### aws_wafregional_rule_group

```hcl
resource "aws_wafregional_rule_group" "rule_group" {
  metric_name = var.metric_name
  name = var.name

  dynamic "activated_rule" {
    for_each = var.activated_rules
    content {
      action {
        type = activated_rule.value["action_type"]
      }

      priority = activated_rule.value["priority"]
      rule_id = activated_rule.value["rule_id"]
    }
  }
}
```

Conditions applied in this module have the following set:

| Value           | Type     | Value Type   | Description                                         |
|-----------------|----------|--------------|-----------------------------------------------------|
| name            | Required | string       | A friendly name of the rule group                   |
| metric_name     | Required | string       | A friendly name for the metrics from the rule group |
| activated_rules | Required | list(object) | A list of activated rules. Documented below.        |

__activated_rules__

| Value       | Type     | Value Type | Description                                                                                                                              |
|-------------|----------|------------|------------------------------------------------------------------------------------------------------------------------------------------|
| action_type | Required | string     | Specifies the action that CloudFront or AWS WAF takes when a web request matches the conditions in the rule. e.g. BLOCK, ALLOW, or COUNT |
| priority    | Required | number     | Specifies the order in which the rules are evaluated. Rules with a lower value are evaluated before rules with a higher value.           |
| rule_id     | Required | string     | The ID of a rule                                                                                                                         |

----------

### aws_wafregional_size_constraint_set

```hcl
resource "aws_wafregional_size_constraint_set" "size_constraint_set" {
  name = var.name

  dynamic "size_constraints" {
    for_each = var.size_constraints
    content {
      text_transformation = size_constraints.value["text_transform"]
      comparison_operator = size_constraints.value["comparison_operator"]
      size = size_constraints.value["size"]
      field_to_match {
        type = size_constraints.value["field_match"]["type"]
        data = size_constraints.value["field_match"]["data"] == "" ? null : size_constraints.value["field_match"]["data"]
      }
    }
  }
}
```

Conditions applied in this module have the following set:

| Value            | Type     | Value Type   | Description                                                                                 |
|------------------|----------|--------------|---------------------------------------------------------------------------------------------|
| name             | Required | string       | The name or description of the Size Constraint Set.                                         |
| size_constraints | Required | list(object) | Specifies the parts of web requests that you want to inspect the size of. Documented below. |

__size_constraints__

| Value               | Type     | Value Type | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                             |
|---------------------|----------|------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| text_transform      | Required | string     | Text transformations used to eliminate unusual formatting that attackers use in web requests in an effort to bypass AWS WAF. If you specify a transformation, AWS WAF performs the transformation on field_to_match before inspecting a request for a match. e.g. CMD_LINE, HTML_ENTITY_DECODE or NONE. See docs for all supported values. Note: if you choose BODY as type, you must choose NONE because CloudFront forwards only the first 8192 bytes for inspection. |
| comparison_operator | Required | string     | The type of comparison you want to perform. e.g. EQ, NE, LT, GT.                                                                                                                                                                                                                                                                                                                                                                                                        |
| size                | Required | number     | The size in bytes that you want to compare against the size of the specified field_to_match. Valid values are between 0 - 21474836480 bytes (0 - 20 GB).                                                                                                                                                                                                                                                                                                                |
| field_match         | Required | object     | Specifies where in a web request to look for the size constraint.                                                                                                                                                                                                                                                                                                                                                                                                       |

__field_match__

| Value | Type     | Value Type | Description                                                                                                                                         |
|-------|----------|------------|-----------------------------------------------------------------------------------------------------------------------------------------------------|
| type  | Required | string     | The part of the web request that you want AWS WAF to search for a specified string. e.g. HEADER, METHOD or BODY.                                    |
| data  | Optional | string     | When type is HEADER, enter the name of the header that you want to search, e.g. User-Agent or Referer. If type is any other value, omit this field. |

----------

### aws_wafregional_sql_injection_match_set

```hcl
resource "aws_wafregional_sql_injection_match_set" "sql_injection_match_set" {
  name = var.name

  dynamic "sql_injection_match_tuple" {
    for_each = var.match_tuples
    content {
      text_transformation = sql_injection_match_tuple.value["text_transform"]
      field_to_match {
        type = sql_injection_match_tuple.value["field_match"]["type"]
        data = sql_injection_match_tuple.value["field_match"]["data"] == "" ? null : sql_injection_match_tuple.value["field_match"]["data"]
      }
    }
  }
}
```

Conditions applied in this module have the following set:

| Value        | Type     | Value Type   | Description                                                                                                                                                               |
|--------------|----------|--------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| name         | Required | string       | The name or description of the SizeConstraintSet.                                                                                                                         |
| match_tuples | Required | list(object) | The parts of web requests that you want AWS WAF to inspect for malicious SQL code and, if you want AWS WAF to inspect a header, the name of the header. Documented below. |

__match_tuples__

| Value          | Type     | Value Type   | Description                                                                                                                                                                                                                                                                                             |
|----------------|----------|--------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| text_transform | Required | string       | Text transformations used to eliminate unusual formatting that attackers use in web requests in an effort to bypass AWS WAF. If you specify a transformation, AWS WAF performs the transformation on field_to_match before inspecting a request for a match. e.g. CMD_LINE, HTML_ENTITY_DECODE or NONE. |
| field_match    | Required | list(object) | Specifies where in a web request to look for snippets of malicious SQL code. Documented below.                                                                                                                                                                                                          |

__field_match__

| Value | Type     | Value Type | Description                                                                                                                                         |
|-------|----------|------------|-----------------------------------------------------------------------------------------------------------------------------------------------------|
| type  | Required | string     | The part of the web request that you want AWS WAF to search for a specified string. e.g. HEADER, METHOD or BODY.                                    |
| data  | Optional | string     | When type is HEADER, enter the name of the header that you want to search, e.g. User-Agent or Referer. If type is any other value, omit this field. |

----------

### aws_wafregional_web_acl

```hcl
resource "aws_wafregional_web_acl" "web_acl" {
  name = var.name
  metric_name = var.metric_name
  default_action {
    type = var.default_action
  }

  dynamic "rule" {
    for_each = var.rules
    content {
      action {
        type = rule.value["action"]["type"]
      }
      priority = rule.value["priority"]
      rule_id = rule.value["rule_id"]
      type = rule.value["type"]
    }
  }
}
```

Conditions applied in this module have the following set:

| Value          | Type     | Value Type   | Description                                                                                                                                           |
|----------------|----------|--------------|-------------------------------------------------------------------------------------------------------------------------------------------------------|
| name           | Required | string       | The name or description of the web ACL.                                                                                                               |
| metric_name    | Required | string       | The name or description for the Amazon CloudWatch metric of this web ACL.                                                                             |
| default_action | Required | string       | The action that you want AWS WAF Regional to take when a request doesn't match the criteria in any of the rules that are associated with the web ACL. |
| rules          | Required | list(object) | Set of configuration blocks containing rules for the web ACL. Documented below.                                                                       |

__rules__

| Value    | Type     | Value Type | Description                                                                                                                                                                                                                                                                      |
|----------|----------|------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| action   | Required | object     | Configuration block of the action that CloudFront or AWS WAF takes when a web request matches the conditions in the rule. Not used if type is GROUP. Documented below.                                                                                                           |
| priority | Required | number     | Specifies the order in which the rules in a WebACL are evaluated. Rules with a lower value are evaluated before rules with a higher value.                                                                                                                                       |
| rule_id  | Required | string     | ID of the associated WAF (Regional) rule (e.g. aws_wafregional_rule). WAF (Global) rules cannot be used.                                                                                                                                                                         |
| type     | Required | string     | The rule type, either REGULAR, as defined by Rule, RATE_BASED, as defined by RateBasedRule, or GROUP, as defined by RuleGroup. The default is REGULAR. If you add a RATE_BASED rule, you need to set type as RATE_BASED. If you add a GROUP rule, you need to set type as GROUP. |

__action__

| Value | Type     | Value Type | Description                                                                                                                  |
|-------|----------|------------|------------------------------------------------------------------------------------------------------------------------------|
| type  | Required | string     | Specifies how you want AWS WAF Regional to respond to requests that match the settings in a rule. e.g. ALLOW, BLOCK or COUNT |

----------

### aws_wafregional_web_acl_association
```hcl
resource "aws_wafregional_web_acl_association" "web_acl_association" {
  resource_arn = var.resource_arn
  web_acl_id = var.web_acl_id
}
```

Conditions applied in this module have the following set:

| Value        | Type     | Value Type | Description                                                                                            |
|--------------|----------|------------|--------------------------------------------------------------------------------------------------------|
| resource_arn | Required | string     | ARN of the resource to associate with. For example, an Application Load Balancer or API Gateway Stage. |
| web_acl_id   | Required | string     | The ID of the WAF Regional WebACL to create an association.                                            |

----------

### aws_wafregional_xss_match_set

```hcl
resource "aws_wafregional_xss_match_set" "xss_match_set" {
  name = var.name

  dynamic "xss_match_tuple" {
    for_each = var.match_tuples
    content {
      text_transformation = xss_match_tuple.value["text_transform"]
      field_to_match {
        type = xss_match_tuple.value["field_match"]["type"]
        data = xss_match_tuple.value["field_match"]["data"] == "" ? null : xss_match_tuple.value["field_match"]["data"]
      }
    }
  }
}
```

Conditions applied in this module have the following set:

| Value        | Type     | Value Type | Description                                                                                            |
|--------------|----------|------------|--------------------------------------------------------------------------------------------------------|
| name         | Required | string     | The name of the set                                                                                    |
| match_tuples | Required | string     | The parts of web requests that you want to inspect for cross-site scripting attacks. Documented below. |

__match_tuples__

| Value          | Type     | Value Type | Description                                                                                                                      |
|----------------|----------|------------|----------------------------------------------------------------------------------------------------------------------------------|
| text_transform | Required | string     | Which text transformation, if any, to perform on the web request before inspecting the request for cross-site scripting attacks. |
| field_match    | Required | object     | Specifies where in a web request to look for cross-site scripting attacks. Documented below.                                     |

__field_match__

| Value | Type     | Value Type | Description                                                                                                                                                                             |
|-------|----------|------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| type  | Required | string     | The part of the web request that you want AWS WAF to search for a specified string. e.g. HEADER or METHOD                                                                               |
| data  | Optional | string     | When the value of type is HEADER, enter the name of the header that you want the WAF to search, for example, User-Agent or Referer. If the value of type is any other value, omit data. |