# Terraform WAF Regional SQL Injection Match Instance Module
#
##########################################################################################
# Module maintainer: CMS Platform Engineering Services                                   #
# Contact: CMS-SuperSmashCrew@coxautoinc.com                                             #
#                                                                                        #
# Description: WAF Creation                                                              #
# README: https://ghe.coxautoinc.com/cms-terraform/tf-wafregional/blob/master/README.md  #
# ___________________                                                                    #
#                                                                                        #
#  Copyright 2019 Cox Automotive Incorporated                                            #
#  All Rights Reserved.                                                                  #
#                                                                                        #
##########################################################################################

terraform {
  required_version = ">= 0.12"
}

# Variables
variable "name" {
  default = ""
}

variable "match_tuples" {
  type = list(object({
    text_transform = string
    field_match = object({
      type = string
      data = string
    })
  }))
}

# Resources
resource "aws_wafregional_sql_injection_match_set" "sql_injection_match_set" {
  name = var.name

  dynamic "sql_injection_match_tuple" {
    for_each = var.match_tuples
    content {
      text_transformation = sql_injection_match_tuple.value["text_transform"]
      field_to_match {
        type = sql_injection_match_tuple.value["field_match"]["type"]
        data = sql_injection_match_tuple.value["field_match"]["data"] == "" ? null : sql_injection_match_tuple.value["field_match"]["data"]
      }
    }
  }
}
