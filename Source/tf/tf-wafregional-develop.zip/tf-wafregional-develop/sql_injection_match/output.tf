# WAF Regional SQL Injection Match Outputs
output "sql_injection_match_set_id" {
  value = aws_wafregional_sql_injection_match_set.sql_injection_match_set.id
}

output "sql_injection_match_set_name" {
  value = aws_wafregional_sql_injection_match_set.sql_injection_match_set.name
}