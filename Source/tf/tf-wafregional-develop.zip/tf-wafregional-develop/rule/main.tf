# Terraform WAF Regional Rule Instance Module
#
##########################################################################################
# Module maintainer: CMS Platform Engineering Services                                   #
# Contact: CMS-SuperSmashCrew@coxautoinc.com                                             #
#                                                                                        #
# Description: WAF Creation                                                              #
# README: https://ghe.coxautoinc.com/cms-terraform/tf-wafregional/blob/master/README.md  #
# ___________________                                                                    #
#                                                                                        #
#  Copyright 2019 Cox Automotive Incorporated                                            #
#  All Rights Reserved.                                                                  #
#                                                                                        #
##########################################################################################

terraform {
  required_version = ">= 0.12"
}

# Variables
variable "name" {
  default = ""
}

variable "metric_name" {
  default = ""
}

variable "predicates" {
  type = list(object({
    data_id = string
    negated = bool
    type = string
  }))
}

# Resources
resource "aws_wafregional_rule" "rule" {
  name = var.name
  metric_name = var.metric_name

  dynamic "predicate" {
    for_each = var.predicates
    content {
      data_id = predicate.value["data_id"]
      negated = predicate.value["negated"]
      type = predicate.value["type"]
    }
  }
}