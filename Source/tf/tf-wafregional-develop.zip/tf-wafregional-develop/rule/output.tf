# WAF Regional Rule Output
output "rule_id" {
  value = aws_wafregional_rule.rule.id
}

output "rule_arn" {
  value = aws_wafregional_rule.rule.arn
}

output "rule_name" {
  value = aws_wafregional_rule.rule.name
}