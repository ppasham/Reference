# Terraform WAF Regional Web ACL Instance Module
#
##########################################################################################
# Module maintainer: CMS Platform Engineering Services                                   #
# Contact: CMS-SuperSmashCrew@coxautoinc.com                                             #
#                                                                                        #
# Description: WAF Creation                                                              #
# README: https://ghe.coxautoinc.com/cms-terraform/tf-wafregional/blob/master/README.md  #
# ___________________                                                                    #
#                                                                                        #
#  Copyright 2019 Cox Automotive Incorporated                                            #
#  All Rights Reserved.                                                                  #
#                                                                                        #
##########################################################################################

terraform {
  required_version = ">= 0.12"
}

# Variables
variable "name" {
  default = ""
}

variable "metric_name" {
  default = ""
}

variable "default_action" {
  default = ""
}

variable "rules" {
  type = list(object({
    action = object({
      type = string
    })

    priority = number
    rule_id = string
    type = string
  }))
}

variable "log_destination" {
  default = ""
}

variable "log_redacted_fields" {
  type = list(object({
    data = string
    type = string
  }))

  default = []
}

variable "region" {
  default = ""
}

# Resources
resource "aws_wafregional_web_acl" "web_acl" {
  name = var.name
  metric_name = var.metric_name
  default_action {
    type = var.default_action
  }

  dynamic "rule" {
    for_each = var.rules
    content {
      action {
        type = rule.value["action"]["type"]
      }
      priority = rule.value["priority"]
      rule_id = rule.value["rule_id"]
      type = rule.value["type"]
    }
  }

  dynamic "logging_configuration" {
    for_each = var.log_destination == "" ? [] : [1]
    content {
//      log_destination = "arn:aws:firehose:${var.region}:${data.aws_caller_identity.current.account_id}:deliverystream/aws-waf-logs-${data.aws_caller_identity.current.account_id}"
      log_destination = var.log_destination

      dynamic "redacted_fields" {
        for_each = var.log_redacted_fields
        content {
          field_to_match {
            type = redacted_fields.value["type"]
            data = redacted_fields.value["data"] == "" ? null : redacted_fields.value["data"]
          }
        }
      }
    }
  }
}