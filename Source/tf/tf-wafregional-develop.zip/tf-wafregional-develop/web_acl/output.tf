# WAF Regional Web ACL Outputs
output "web_acl_id" {
  value = aws_wafregional_web_acl.web_acl.id
}

output "web_acl_arn" {
  value = aws_wafregional_web_acl.web_acl.arn
}

output "web_acl_name" {
  value = aws_wafregional_web_acl.web_acl.name
}