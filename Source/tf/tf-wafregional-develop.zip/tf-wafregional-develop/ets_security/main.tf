# Terraform WAF Regional ETS Security Instance Module
#
##########################################################################################
# Module maintainer: CMS Platform Engineering Services                                   #
# Contact: CMS-SuperSmashCrew@coxautoinc.com                                             #
#                                                                                        #
# Description: WAF Creation                                                              #
# README: https://ghe.coxautoinc.com/cms-terraform/tf-wafregional/blob/master/README.md  #
# ___________________                                                                    #
#                                                                                        #
#  Copyright 2019 Cox Automotive Incorporated                                            #
#  All Rights Reserved.                                                                  #
#                                                                                        #
##########################################################################################

terraform {
  required_version = ">= 0.12"
}

# Variables
variable "waf_prefix" {
  default = ""
}

variable "region" {
  default = ""
}

variable "body_max_size" {
  default = "4096"
}

variable "header_max_size" {
  default = "4093"
}

variable "query_string_max_size" {
  default = "1024"
}

variable "uri_max_size" {
  default = "512"
}

variable "admin_ipset" {
  type = list(object({
    type = string
    value = string
  }))

  default = []
}

variable "blacklisted_ipset" {
  type = list(object({
    type = string
    value = string
  }))

  default = []
}

variable "restrict_sizes_rule_action" {
  default = "BLOCK"
}

variable "detect_blacklisted_ips_rule_action" {
  default = "BLOCK"
}

variable "detect_bad_auth_tokens_rule_action" {
  default = "BLOCK"
}

variable "mitigate_sqli_rule_action" {
  default = "BLOCK"
}

variable "mitigate_xss_rule_action" {
  default = "BLOCK"
}

variable "detect_rfi_lfi_traversal_rule_action" {
  default = "BLOCK"
}

variable "detect_php_insecure_rule_action" {
  default = "BLOCK"
}

variable "enforce_csrf_rule_action" {
  default = "BLOCK"
}

variable "detect_ssi_rule_action" {
  default = "BLOCK"
}

variable "detect_admin_access_rule_action" {
  default = "BLOCK"
}

variable "log_redacted_fields" {
  type = list(object({
    data = string
    type = string
  }))

  default = []
}

# Data
data "aws_caller_identity" "current" {}

# Modules
module "admin_ipset" {
  source = "git@ghe.coxautoinc.com:cms-terraform/tf-wafregional.git//ipset"

  name = "${var.waf_prefix}-admin-remote-ipset"
  set_descriptors = var.admin_ipset
}

module "blacklisted_ipset" {
  source = "git@ghe.coxautoinc.com:cms-terraform/tf-wafregional.git//ipset"

  name = "${var.waf_prefix}-blacklisted-remote-ipset"
  set_descriptors = var.blacklisted_ipset
}

module "generic_size_restrictions" {
  source = "git@ghe.coxautoinc.com:cms-terraform/tf-wafregional.git//size_constraint"

  name = "${var.waf_prefix}-generic-size-restrictions"
  size_constraints = [
    {
      text_transform = "NONE"
      comparison_operator = "GT"
      size = var.body_max_size

      field_match = {
        type = "BODY"
        data = null
      }
    },
    {
      text_transform = "NONE"
      comparison_operator = "GT"
      size = var.header_max_size

      field_match = {
        type = "HEADER"
        data = "cookie"
      }
    },
    {
      text_transform = "NONE"
      comparison_operator = "GT"
      size = var.query_string_max_size

      field_match = {
        type = "QUERY_STRING"
        data = null
      }
    },
    {
      text_transform = "NONE"
      comparison_operator = "GT"
      size = var.uri_max_size

      field_match = {
        type = "URI"
        data = null
      }
    }
  ]
}

module "csrf_token_size_restrictions" {
  source = "git@ghe.coxautoinc.com:cms-terraform/tf-wafregional.git//size_constraint"

  name = "${var.waf_prefix}-generic-csrf-token-size-restrictions"
  size_constraints = [
    {
      text_transform = "NONE"
      comparison_operator = "EQ"
      size = "36"

      field_match = {
        type = "HEADER"
        data = "x-csrf-token"
      }
    }
  ]
}

module "sql_injection_match_set" {
  source = "git@ghe.coxautoinc.com:cms-terraform/tf-wafregional.git//sql_injection_match"

  name = "${var.waf_prefix}-generic-detect-sqli"

  match_tuples = [
    {
      text_transform = "HTML_ENTITY_DECODE"

      field_match = {
        type = "BODY"
        data = null
      }
    },
    {
      text_transform = "URL_DECODE"

      field_match = {
        type = "BODY"
        data = null
      }
    },
    {
      text_transform = "HTML_ENTITY_DECODE"

      field_match = {
        type = "URI"
        data = null
      }
    },
    {
      text_transform = "URL_DECODE"

      field_match = {
        type = "URI"
        data = null
      }
    },
    {
      text_transform = "HTML_ENTITY_DECODE"

      field_match = {
        type = "QUERY_STRING"
        data = null
      }
    },
    {
      text_transform = "URL_DECODE"

      field_match = {
        type = "QUERY_STRING"
        data = null
      }
    },
    {
      text_transform = "HTML_ENTITY_DECODE"

      field_match = {
        type = "HEADER"
        data = "cookie"
      }
    },
    {
      text_transform = "URL_DECODE"

      field_match = {
        type = "HEADER"
        data = "cookie"
      }
    }
  ]
}

module "admin_url_byte_match_set" {
  source = "git@ghe.coxautoinc.com:cms-terraform/tf-wafregional.git//byte_match"

  name = "${var.waf_prefix}-generic-match-admin-url"

  match_tuples = [
    {
      text_transform = "URL_DECODE"
      target_string = "/admin"
      positional_constraint = "STARTS_WITH"

      field_match = {
        type = "URI"
        data = null
      }
    }
  ]
}

module "auth_token_byte_match_set" {
  source = "git@ghe.coxautoinc.com:cms-terraform/tf-wafregional.git//byte_match"

  name = "${var.waf_prefix}-generic-match-auth-token"

  match_tuples = [
    {
      text_transform   = "URL_DECODE"
      target_string         = ".TJVA95OrM7E2cBab30RMHrHDcEfxjoYZgeFONFh7HgQ"
      positional_constraint = "ENDS_WITH"

      field_match = {
        type = "HEADER"
        data = "authorization"
      }
    },
    {
      text_transform   = "URL_DECODE"
      target_string         = "example-session-id"
      positional_constraint = "CONTAINS"

      field_match = {
        type = "HEADER"
        data = "cookie"
      }
    }
  ]
}

module "csrf_method_byte_match_set" {
  source = "git@ghe.coxautoinc.com:cms-terraform/tf-wafregional.git//byte_match"

  name = "${var.waf_prefix}-generic-match-csrf-method"

  match_tuples = [
    {
      text_transform = "URL_DECODE"
      target_string         = "post"
      positional_constraint = "EXACTLY"

      field_match = {
        type = "METHOD"
        data = null
      }
    }
  ]
}

module "php_insecure_uri_byte_match_set" {
  source = "git@ghe.coxautoinc.com:cms-terraform/tf-wafregional.git//byte_match"

  name = "${var.waf_prefix}-generic-match-php-insecure-uri"

  match_tuples = [
    {
      text_transform   = "URL_DECODE"
      target_string         = "php"
      positional_constraint = "ENDS_WITH"

      field_match = {
        type = "URI"
        data = null
      }
    },
    {
      text_transform   = "URL_DECODE"
      target_string         = "/"
      positional_constraint = "ENDS_WITH"

      field_match = {
        type = "URI"
        data = null
      }
    }
  ]
}

module "php_insecure_var_byte_match_set" {
  source = "git@ghe.coxautoinc.com:cms-terraform/tf-wafregional.git//byte_match"

  name = "${var.waf_prefix}-generic-match-php-insecure-var-refs"
  match_tuples = [
    {
      text_transform   = "URL_DECODE"
      target_string         = "_ENV["
      positional_constraint = "CONTAINS"

      field_match = {
        type = "QUERY_STRING"
        data = null
      }
    },
    {
      text_transform   = "URL_DECODE"
      target_string         = "auto_append_file="
      positional_constraint = "CONTAINS"

      field_match = {
        type = "QUERY_STRING"
        data = null
      }
    },
    {
      text_transform   = "URL_DECODE"
      target_string         = "disable_functions="
      positional_constraint = "CONTAINS"

      field_match = {
        type = "QUERY_STRING"
        data = null
      }
    },
    {
      text_transform   = "URL_DECODE"
      target_string         = "auto_prepend_file="
      positional_constraint = "CONTAINS"

      field_match = {
        type = "QUERY_STRING"
        data = null
      }
    },
    {
      text_transform   = "URL_DECODE"
      target_string         = "safe_mode="
      positional_constraint = "CONTAINS"

      field_match = {
        type = "QUERY_STRING"
        data = null
      }
    },
    {
      text_transform   = "URL_DECODE"
      target_string         = "_SERVER["
      positional_constraint = "CONTAINS"

      field_match = {
        type = "QUERY_STRING"
        data = null
      }
    },
    {
      text_transform   = "URL_DECODE"
      target_string         = "allow_url_include="
      positional_constraint = "CONTAINS"

      field_match = {
        type = "QUERY_STRING"
        data = null
      }
    },
    {
      text_transform   = "URL_DECODE"
      target_string         = "open_basedir="
      positional_constraint = "CONTAINS"

      field_match = {
        type = "QUERY_STRING"
        data = null
      }
    }
  ]
}

module "rfi_lfi_traversal_byte_match_set" {
  source = "git@ghe.coxautoinc.com:cms-terraform/tf-wafregional.git//byte_match"

  name = "${var.waf_prefix}-generic-match-rfi-lfi-traversal"
  match_tuples = [
    {
      text_transform   = "HTML_ENTITY_DECODE"
      target_string         = "://"
      positional_constraint = "CONTAINS"

      field_match = {
        type = "QUERY_STRING"
        data = null
      }
    },
    {
      text_transform   = "HTML_ENTITY_DECODE"
      target_string         = "../"
      positional_constraint = "CONTAINS"

      field_match = {
        type = "QUERY_STRING"
        data = null
      }
    },
    {
      text_transform   = "URL_DECODE"
      target_string         = "://"
      positional_constraint = "CONTAINS"

      field_match = {
        type = "QUERY_STRING"
        data = null
      }
    },
    {
      text_transform   = "URL_DECODE"
      target_string         = "../"
      positional_constraint = "CONTAINS"

      field_match = {
        type = "QUERY_STRING"
        data = null
      }
    },
    {
      text_transform   = "HTML_ENTITY_DECODE"
      target_string         = "://"
      positional_constraint = "CONTAINS"

      field_match = {
        type = "URI"
        data = null
      }
    },
    {
      text_transform   = "HTML_ENTITY_DECODE"
      target_string         = "../"
      positional_constraint = "CONTAINS"

      field_match = {
        type = "URI"
        data = null
      }
    },
    {
      text_transform   = "URL_DECODE"
      target_string         = "://"
      positional_constraint = "CONTAINS"

      field_match = {
        type = "URI"
        data = null
      }
    },
    {
      text_transform   = "URL_DECODE"
      target_string         = "../"
      positional_constraint = "CONTAINS"

      field_match = {
        type = "URI"
        data = null
      }
    }
  ]
}

module "ssi_byte_match_set" {
  source = "git@ghe.coxautoinc.com:cms-terraform/tf-wafregional.git//byte_match"

  name = "${var.waf_prefix}-generic-match-ssi"
  match_tuples = [
    {
      text_transform   = "LOWERCASE"
      target_string         = ".cfg"
      positional_constraint = "ENDS_WITH"

      field_match = {
        type = "URI"
        data = null
      }
    },
    {
      text_transform   = "LOWERCASE"
      target_string         = ".backup"
      positional_constraint = "ENDS_WITH"

      field_match = {
        type = "URI"
        data = null
      }
    },
    {
      text_transform   = "LOWERCASE"
      target_string         = ".ini"
      positional_constraint = "ENDS_WITH"

      field_match = {
        type = "URI"
        data = null
      }
    },
    {
      text_transform   = "LOWERCASE"
      target_string         = ".conf"
      positional_constraint = "ENDS_WITH"

      field_match = {
        type = "URI"
        data = null
      }
    },
    {
      text_transform   = "LOWERCASE"
      target_string         = ".log"
      positional_constraint = "ENDS_WITH"

      field_match = {
        type = "URI"
        data = null
      }
    },
    {
      text_transform   = "LOWERCASE"
      target_string         = ".bak"
      positional_constraint = "ENDS_WITH"

      field_match = {
        type = "URI"
        data = null
      }
    },
    {
      text_transform   = "LOWERCASE"
      target_string         = ".config"
      positional_constraint = "ENDS_WITH"

      field_match = {
        type = "URI"
        data = null
      }
    },
    {
      text_transform   = "URL_DECODE"
      target_string         = "/includes"
      positional_constraint = "STARTS_WITH"

      field_match = {
        type = "URI"
        data = null
      }
    }
  ]
}

module "xss_match" {
  source = "git@ghe.coxautoinc.com:cms-terraform/tf-wafregional.git//xss_match"

  name = "${var.waf_prefix}-generic-detect-xss"
  match_tuples = [
    {
      text_transform = "HTML_ENTITY_DECODE"

      field_match = {
        type = "BODY"
        data = null
      }
    },
    {
      text_transform = "URL_DECODE"

      field_match = {
        type = "BODY"
        data = null
      }
    },
    {
      text_transform = "HTML_ENTITY_DECODE"

      field_match = {
        type = "URI"
        data = null
      }
    },
    {
      text_transform = "URL_DECODE"

      field_match = {
        type = "URI"
        data = null
      }
    },
    {
      text_transform = "HTML_ENTITY_DECODE"

      field_match = {
        type = "QUERY_STRING"
        data = null
      }
    },
    {
      text_transform = "URL_DECODE"

      field_match = {
        type = "QUERY_STRING"
        data = null
      }
    },
    {
      text_transform = "HTML_ENTITY_DECODE"

      field_match = {
        type = "HEADER"
        data = "cookie"
      }
    },
    {
      text_transform = "URL_DECODE"

      field_match = {
        type = "HEADER"
        data = "cookie"
      }
    }
  ]
}

module "detect_admin_access_rule" {
  source = "git@ghe.coxautoinc.com:cms-terraform/tf-wafregional.git//rule"

  name        = "${var.waf_prefix}-generic-detect-admin-access"
  metric_name = "${var.waf_prefix}genericdetectadminaccess"
  predicates = [
    {
      data_id = module.admin_ipset.ipset_id
      negated = true
      type = "IPMatch"
    },
    {
      data_id = module.admin_url_byte_match_set.byte_match_set_id
      negated = false
      type = "ByteMatch"
    }
  ]
}

module "detect_bad_auth_tokens_rule" {
  source = "git@ghe.coxautoinc.com:cms-terraform/tf-wafregional.git//rule"

  name        = "${var.waf_prefix}-generic-detect-bad-auth-tokens"
  metric_name = "${var.waf_prefix}genericdetectbadauthtokens"
  predicates = [
    {
      data_id = module.auth_token_byte_match_set.byte_match_set_id
      negated = false
      type = "ByteMatch"
    }
  ]
}

module "detect_blacklisted_ips_rule" {
  source = "git@ghe.coxautoinc.com:cms-terraform/tf-wafregional.git//rule"

  name        = "${var.waf_prefix}-generic-detect-blacklisted-ips"
  metric_name = "${var.waf_prefix}genericdetectblacklistedips"
  predicates = [
    {
      data_id = module.blacklisted_ipset.ipset_id
      negated = false
      type = "IPMatch"
    }
  ]
}

module "detect_php_insecure_rule" {
  source = "git@ghe.coxautoinc.com:cms-terraform/tf-wafregional.git//rule"

  name        = "${var.waf_prefix}-generic-detect-php-insecure"
  metric_name = "${var.waf_prefix}genericdetectphpinsecure"
  predicates = [
    {
      data_id = module.php_insecure_uri_byte_match_set.byte_match_set_id
      negated = false
      type = "ByteMatch"
    },
    {
      data_id = module.php_insecure_var_byte_match_set.byte_match_set_id
      negated = false
      type = "ByteMatch"
    }
  ]
}

module "detect_rfi_lfi_traversal_rule" {
  source = "git@ghe.coxautoinc.com:cms-terraform/tf-wafregional.git//rule"

  name        = "${var.waf_prefix}-generic-detect-rfi-lfi-traversal"
  metric_name = "${var.waf_prefix}genericdetectrfilfitraversal"
  predicates = [
    {
      data_id = module.rfi_lfi_traversal_byte_match_set.byte_match_set_id
      negated = false
      type = "ByteMatch"
    }
  ]
}

module "detect_ssi_rule" {
  source = "git@ghe.coxautoinc.com:cms-terraform/tf-wafregional.git//rule"

  name        = "${var.waf_prefix}-generic-detect-ssi"
  metric_name = "${var.waf_prefix}genericdetectssi"
  predicates = [
    {
      data_id = module.ssi_byte_match_set.byte_match_set_id
      negated = false
      type = "ByteMatch"
    }
  ]
}

module "enforce_csrf_rule" {
  source = "git@ghe.coxautoinc.com:cms-terraform/tf-wafregional.git//rule"

  name        = "${var.waf_prefix}-generic-enforce-csrf"
  metric_name = "${var.waf_prefix}genericenforcecsrf"
  predicates = [
    {
      data_id = module.csrf_method_byte_match_set.byte_match_set_id
      negated = false
      type = "ByteMatch"
    },
    {
      data_id = module.csrf_token_size_restrictions.size_contraint_id
      negated = true
      type = "SizeConstraint"
    }
  ]
}

module "mitigate_sqli_rule" {
  source = "git@ghe.coxautoinc.com:cms-terraform/tf-wafregional.git//rule"

  name        = "${var.waf_prefix}-generic-mitigate-sqli"
  metric_name = "${var.waf_prefix}genericmitigatesqli"
  predicates = [
    {
      data_id = module.sql_injection_match_set.sql_injection_match_set_id
      negated = false
      type = "SqlInjectionMatch"
    }
  ]
}

module "mitigate_xss_rule" {
  source = "git@ghe.coxautoinc.com:cms-terraform/tf-wafregional.git//rule"

  name        = "${var.waf_prefix}-generic-mitigate-xss"
  metric_name = "${var.waf_prefix}genericmitigatexss"
  predicates = [
    {
      data_id = module.xss_match.xss_match_set_id
      negated = false
      type = "XssMatch"
    }
  ]
}

module "restrict_sizes_rule" {
  source = "git@ghe.coxautoinc.com:cms-terraform/tf-wafregional.git//rule"

  name        = "${var.waf_prefix}-generic-restrict-sizes"
  metric_name = "${var.waf_prefix}genericrestrictsizes"
  predicates = [
    {
      data_id = module.generic_size_restrictions.size_contraint_id
      negated = false
      type = "SizeConstraint"
    }
  ]
}

module "generic_web_acl" {
  source = "git@ghe.coxautoinc.com:cms-terraform/tf-wafregional.git//web_acl"

  name        = "${var.waf_prefix}-generic-owasp-acl"
  metric_name = "${var.waf_prefix}genericowaspacl"

  default_action = "ALLOW"

  rules = [
    {
      action = {
        type = var.restrict_sizes_rule_action
      }

      priority = 1
      rule_id  = module.restrict_sizes_rule.rule_id
      type     = "REGULAR"
    },
    {
      action = {
        type = var.detect_blacklisted_ips_rule_action
      }

      priority = 2
      rule_id  = module.detect_blacklisted_ips_rule.rule_id
      type     = "REGULAR"
    },
    {
      action = {
        type = var.detect_bad_auth_tokens_rule_action
      }

      priority = 3
      rule_id  = module.detect_bad_auth_tokens_rule.rule_id
      type     = "REGULAR"
    },
    {
      action = {
        type = var.mitigate_sqli_rule_action
      }

      priority = 4
      rule_id  = module.mitigate_sqli_rule.rule_id
      type     = "REGULAR"
    },
    {
      action = {
        type = var.mitigate_xss_rule_action
      }

      priority = 5
      rule_id  = module.mitigate_xss_rule.rule_id
      type     = "REGULAR"
    },
    {
      action = {
        type = var.detect_rfi_lfi_traversal_rule_action
      }

      priority = 6
      rule_id  = module.detect_rfi_lfi_traversal_rule.rule_id
      type     = "REGULAR"
    },
    {
      action = {
        type = var.detect_php_insecure_rule_action
      }

      priority = 7
      rule_id  = module.detect_php_insecure_rule.rule_id
      type     = "REGULAR"
    },
    {
      action = {
        type = var.enforce_csrf_rule_action
      }

      priority = 8
      rule_id  = module.enforce_csrf_rule.rule_id
      type     = "REGULAR"
    },
    {
      action = {
        type = var.detect_ssi_rule_action
      }

      priority = 9
      rule_id  = module.detect_ssi_rule.rule_id
      type     = "REGULAR"
    },
    {
      action = {
        type = var.detect_admin_access_rule_action
      }

      priority = 10
      rule_id  = module.detect_admin_access_rule.rule_id
      type     = "REGULAR"
    }
  ]

  log_destination = "arn:aws:firehose:${var.region}:${data.aws_caller_identity.current.account_id}:deliverystream/aws-waf-logs-${data.aws_caller_identity.current.account_id}"
  log_redacted_fields = var.log_redacted_fields
}