# WAF Regional ETS Security Output
output "admin_ipset_arn" {
  value = module.admin_ipset.ipset_arn
}

output "admin_ipset_id" {
  value = module.admin_ipset.ipset_id
}

output "admin_ipset_name" {
  value = module.admin_ipset.ipset_name
}

output "blacklisted_ipset_arn" {
  value = module.blacklisted_ipset.ipset_arn
}

output "blacklisted_ipset_id" {
  value = module.blacklisted_ipset.ipset_id
}

output "blacklisted_ipset_name" {
  value = module.blacklisted_ipset.ipset_name
}

output "generic_size_restrictions_id" {
  value = module.generic_size_restrictions.size_contraint_id
}

output "generic_size_restrictions_name" {
  value = module.generic_size_restrictions.size_contraint_name
}

output "csrf_token_size_restrictions_id" {
  value = module.csrf_token_size_restrictions.size_contraint_id
}

output "csrf_token_size_restrictions_name" {
  value = module.csrf_token_size_restrictions.size_contraint_name
}

output "sql_injection_match_set_id" {
  value = module.sql_injection_match_set.sql_injection_match_set_id
}

output "sql_injection_match_set_name" {
  value = module.sql_injection_match_set.sql_injection_match_set_name
}

output "admin_url_byte_match_set_id" {
  value = module.admin_url_byte_match_set.byte_match_set_id
}

output "admin_url_byte_match_set_name" {
  value = module.admin_url_byte_match_set.byte_match_set_name
}

output "auth_token_byte_match_set_id" {
  value = module.auth_token_byte_match_set.byte_match_set_id
}

output "auth_token_byte_match_set_name" {
  value = module.auth_token_byte_match_set.byte_match_set_name
}

output "csrf_method_byte_match_set_id" {
  value = module.csrf_method_byte_match_set.byte_match_set_id
}

output "csrf_method_byte_match_set_name" {
  value = module.csrf_method_byte_match_set.byte_match_set_name
}

output "php_insecure_uri_byte_match_set_id" {
  value = module.php_insecure_uri_byte_match_set.byte_match_set_id
}

output "php_insecure_uri_byte_match_set_name" {
  value = module.php_insecure_uri_byte_match_set.byte_match_set_name
}

output "php_insecure_var_byte_match_set_id" {
  value = module.php_insecure_var_byte_match_set.byte_match_set_id
}

output "php_insecure_var_byte_match_set_name" {
  value = module.php_insecure_var_byte_match_set.byte_match_set_name
}

output "rfi_lfi_traversal_byte_match_set_id" {
  value = module.rfi_lfi_traversal_byte_match_set.byte_match_set_id
}

output "rfi_lfi_traversal_byte_match_set_name" {
  value = module.rfi_lfi_traversal_byte_match_set.byte_match_set_name
}

output "ssi_byte_match_set_id" {
  value = module.ssi_byte_match_set.byte_match_set_id
}

output "ssi_byte_match_set_name" {
  value = module.ssi_byte_match_set.byte_match_set_name
}

output "xss_match_id" {
  value = module.xss_match.xss_match_set_id
}

output "xss_match_name" {
  value = module.xss_match.xss_match_set_name
}

output "detect_admin_access_rule_arn" {
  value = module.detect_admin_access_rule.rule_arn
}

output "detect_admin_access_rule_id" {
  value = module.detect_admin_access_rule.rule_id
}

output "detect_admin_access_rule_name" {
  value = module.detect_admin_access_rule.rule_name
}

output "detect_bad_auth_tokens_rule_arn" {
  value = module.detect_bad_auth_tokens_rule.rule_arn
}

output "detect_bad_auth_tokens_rule_id" {
  value = module.detect_bad_auth_tokens_rule.rule_id
}

output "detect_bad_auth_tokens_rule_name" {
  value = module.detect_bad_auth_tokens_rule.rule_name
}

output "detect_blacklisted_ips_rule_arn" {
  value = module.detect_blacklisted_ips_rule.rule_arn
}

output "detect_blacklisted_ips_rule_id" {
  value = module.detect_blacklisted_ips_rule.rule_id
}

output "detect_blacklisted_ips_rule_name" {
  value = module.detect_blacklisted_ips_rule.rule_name
}

output "detect_php_insecure_rule_arn" {
  value = module.detect_php_insecure_rule.rule_arn
}

output "detect_php_insecure_rule_id" {
  value = module.detect_php_insecure_rule.rule_id
}

output "detect_php_insecure_rule_name" {
  value = module.detect_php_insecure_rule.rule_name
}

output "detect_rfi_lfi_traversal_rule_arn" {
  value = module.detect_rfi_lfi_traversal_rule.rule_arn
}

output "detect_rfi_lfi_traversal_rule_id" {
  value = module.detect_rfi_lfi_traversal_rule.rule_id
}

output "detect_rfi_lfi_traversal_rule_name" {
  value = module.detect_rfi_lfi_traversal_rule.rule_name
}

output "detect_ssi_rule_arn" {
  value = module.detect_ssi_rule.rule_arn
}

output "detect_ssi_rule_id" {
  value = module.detect_ssi_rule.rule_id
}

output "detect_ssi_rule_name" {
  value = module.detect_ssi_rule.rule_name
}

output "enforce_csrf_rule_arn" {
  value = module.enforce_csrf_rule.rule_arn
}

output "enforce_csrf_rule_id" {
  value = module.enforce_csrf_rule.rule_id
}

output "enforce_csrf_rule_name" {
  value = module.enforce_csrf_rule.rule_name
}

output "mitigate_sqli_rule_arn" {
  value = module.mitigate_sqli_rule.rule_arn
}

output "mitigate_sqli_rule_id" {
  value = module.mitigate_sqli_rule.rule_id
}

output "mitigate_sqli_rule_name" {
  value = module.mitigate_sqli_rule.rule_name
}

output "mitigate_xss_rule_arn" {
  value = module.mitigate_xss_rule.rule_arn
}

output "mitigate_xss_rule_id" {
  value = module.mitigate_xss_rule.rule_id
}

output "mitigate_xss_rule_name" {
  value = module.mitigate_xss_rule.rule_name
}

output "restrict_sizes_rule_arn" {
  value = module.restrict_sizes_rule.rule_arn
}

output "restrict_sizes_rule_id" {
  value = module.restrict_sizes_rule.rule_id
}

output "restrict_sizes_rule_name" {
  value = module.restrict_sizes_rule.rule_name
}

output "generic_web_acl_arn" {
  value = module.generic_web_acl.web_acl_arn
}

output "generic_web_acl_id" {
  value = module.generic_web_acl.web_acl_id
}

output "generic_web_acl_name" {
  value = module.generic_web_acl.web_acl_name
}