# ets_security
A standardized WAF module with cogent defaults.

+ [ets_security](#ets_security)
  + [Description](#description)
  + [Usage](#usage)
    + [Example](#example)
    + [Variables](#variables)
      + [Required](#required)
        + [region](#region)
        + [waf_prefix](#waf_prefix)
      + [Optional](#optional)
        + [admin_ipset](#admin_ipset)
        + [blacklisted_ipset](#blacklisted_ipset)
        + [body_max_size](#body_max_size)
        + [detect_admin_access_rule_action](#detect_admin_access_rule_action)
        + [detect_bad_auth_tokens_rule_action](#detect_bad_auth_tokens_rule_action)
        + [detect_blacklisted_ips_rule_action](#detect_blacklisted_ips_rule_action)
        + [detect_php_insecure_rule_action](#detect_php_insecure_rule_action)
        + [detect_rfi_lfi_traversal_rule_action](#detect_rfi_lfi_traversal_rule_action)
        + [detect_ssi_rule_action](#detect_ssi_rule_action)
        + [enforce_csrf_rule_action](#enforce_csrf_rule_action)
        + [header_max_size](#header_max_size)
        + [log_redacted_fields](#log_redacted_fields)
        + [mitigate_sqli_rule_action](#mitigate_sqli_rule_action)
        + [mitigate_xss_rule_action](#mitigate_xss_rule_action)
        + [query_string_max_size](#query_string_max_size)
        + [restrict_sizes_rule_action](#restrict_sizes_rule_action)
        + [uri_max_size](#uri_max_size)
  + [Resources Created](#resources-created)
    + [admin_ipset](#admin_ipset-1)
    + [blacklisted_ipset](#blacklisted_ipset-1)
    + [generic_size_restrictions](#generic_size_restrictions)
    + [csrf_token_size_restrictions](#csrf_token_size_restrictions)
    + [sql_injection_match_set](#sql_injection_match_set)
    + [admin_url_byte_match_set](#admin_url_byte_match_set)
    + [auth_token_byte_match_set](#auth_token_byte_match_set)
    + [csrf_method_byte_match_set](#csrf_method_byte_match_set)
    + [php_insecure_uri_byte_match_set](#php_insecure_uri_byte_match_set)
    + [php_insecure_var_byte_match_set](#php_insecure_var_byte_match_set)
    + [rfi_lfi_traversal_byte_match_set](#rfi_lfi_traversal_byte_match_set)
    + [ssi_byte_match_set](#ssi_byte_match_set)
    + [xss_match](#xss_match)
    + [detect_admin_access_rule](#detect_admin_access_rule)
    + [detect_bad_auth_tokens_rule](#detect_bad_auth_tokens_rule)
    + [detect_blacklisted_ips_rule](#detect_blacklisted_ips_rule)
    + [detect_php_insecure_rule](#detect_php_insecure_rule)
    + [detect_rfi_lfi_traversal_rule](#detect_rfi_lfi_traversal_rule)
    + [detect_ssi_rule](#detect_ssi_rule)
    + [enforce_csrf_rule](#enforce_csrf_rule)
    + [mitigate_sqli_rule](#mitigate_sqli_rule)
    + [mitigate_xss_rule](#mitigate_xss_rule)
    + [restrict_sizes_rule](#restrict_sizes_rule)
    + [generic_web_acl](#generic_web_acl)

## Description
The ETS security sub-module is based on the templates outlined [here](https://ghe.coxautoinc.com/ETS-Security/AWS-WAF-TF-Examples).

## Usage

### Example

```hcl
module "ets_security_waf" {
  source = "git@ghe.coxautoinc.com:cms-terraform/tf-wafregional.git//ets_security"
  
  waf_prefix = "example_ets_waf"
  region = "us-west-2"
  admin_ipset = "10.134.59.16/24"
  blacklisted_ipset = "1.1.1.1/24"
}
```

### Variables

#### Required

* [region](#region)
* [waf_prefix](#waf_prefix)

<sub>[TOC](#ets_security)</sub>
----

##### region 
> __Required__: True  
> __Type__: string        
> __Description__: The region to be used for logging.                    
> 
> __Example__  
> ```hcl
> module "ets_security_waf" {
>   source = "git@ghe.coxautoinc.com:cms-terraform/tf-wafregional.git//ets_security"
>   ...
>   region = ""
>   ...
> }
> ```
>
> [TOC](#ets_security)
----

##### waf_prefix 
> __Required__: True  
> __Type__: string        
> __Description__: The prefix to append for the name of items created.   
> 
> __Example__  
> ```hcl
> module "ets_security_waf" {
>   source = "git@ghe.coxautoinc.com:cms-terraform/tf-wafregional.git//ets_security"
>   ...
>   waf_prefix = ""
>   ...
> }
> ```
>
> [TOC](#ets_security)
----

#### Optional

* [admin_ipset](#admin_ipset)
* [blacklisted_ipset](#blacklisted_ipset)
* [body_max_size](#body_max_size)
* [detect_admin_access_rule_action](#detect_admin_access_rule_action)
* [detect_bad_auth_tokens_rule_action](#detect_bad_auth_tokens_rule_action)
* [detect_blacklisted_ips_rule_action](#detect_blacklisted_ips_rule_action)
* [detect_php_insecure_rule_action](#detect_php_insecure_rule_action)
* [detect_rfi_lfi_traversal_rule_action](#detect_rfi_lfi_traversal_rule_action)
* [detect_ssi_rule_action](#detect_ssi_rule_action)
* [enforce_csrf_rule_action](#enforce_csrf_rule_action)
* [header_max_size](#header_max_size)
* [log_redacted_fields](#log_redacted_fields)
* [mitigate_sqli_rule_action](#mitigate_sqli_rule_action)
* [mitigate_xss_rule_action](#mitigate_xss_rule_action)
* [query_string_max_size](#query_string_max_size)
* [restrict_sizes_rule_action](#restrict_sizes_rule_action)
* [uri_max_size](#uri_max_size)

##### admin_ipset 
> __Required__: False  
> __Default__: []  
> __Type__: list(object)  
> __Description__: IP range(s) that will be used for admin purposes.     
> 
> __Example__  
> ```hcl
> module "ets_security_waf" {
>   source = "git@ghe.coxautoinc.com:cms-terraform/tf-wafregional.git//ets_security"
>   ...
>   admin_ipset = ""
>   ...
> }
> ```
>
> [TOC](#ets_security)
----

##### blacklisted_ipset 
> __Required__: False  
> __Default__: []  
> __Type__: list(object)  
> __Description__: IP range(s) that are blacklisted from access.         
> 
> __Example__  
> ```hcl
> module "ets_security_waf" {
>   source = "git@ghe.coxautoinc.com:cms-terraform/tf-wafregional.git//ets_security"
>   ...
>   blacklisted_ipset = ""
>   ...
> }
> ```
>
> [TOC](#ets_security)
----

##### body_max_size
> __Required__: False    
> __Default__: 4096    
> __Type__: string    
> __Description__: The maximum size of the request body that is allowed.                                                                     
>
> __Example__  
> ```hcl
> module "ets_security_waf" {
>   source = "git@ghe.coxautoinc.com:cms-terraform/tf-wafregional.git//ets_security"
>   ...
>   body_max_size = ""
>   ...
> }
> ```
>
> [TOC](#ets_security)
----

##### detect_admin_access_rule_action
> __Required__: False    
> __Default__: BLOCK    
> __Type__: string    
> __Description__: How you want AWS WAF Regional to respond to requests that match the settings in a rule. Options: ALLOW, BLOCK or COUNT    
>
> __Example__  
> ```hcl
> module "ets_security_waf" {
>   source = "git@ghe.coxautoinc.com:cms-terraform/tf-wafregional.git//ets_security"
>   ...
>   detect_admin_access_rule_action = ""
>   ...
> }
> ```
>
> [TOC](#ets_security)
----

##### detect_bad_auth_tokens_rule_action
> __Required__: False    
> __Default__: BLOCK    
> __Type__: string    
> __Description__: How you want AWS WAF Regional to respond to requests that match the settings in a rule. Options: ALLOW, BLOCK or COUNT    
>
> __Example__  
> ```hcl
> module "ets_security_waf" {
>   source = "git@ghe.coxautoinc.com:cms-terraform/tf-wafregional.git//ets_security"
>   ...
>   detect_bad_auth_tokens_rule_action = ""
>   ...
> }
> ```
>
> [TOC](#ets_security)
----

##### detect_blacklisted_ips_rule_action
> __Required__: False    
> __Default__: BLOCK    
> __Type__: string    
> __Description__: How you want AWS WAF Regional to respond to requests that match the settings in a rule. Options: ALLOW, BLOCK or COUNT    
>
> __Example__  
> ```hcl
> module "ets_security_waf" {
>   source = "git@ghe.coxautoinc.com:cms-terraform/tf-wafregional.git//ets_security"
>   ...
>   detect_blacklisted_ips_rule_action = ""
>   ...
> }
> ```
>
> [TOC](#ets_security)
----

##### detect_php_insecure_rule_action
> __Required__: False    
> __Default__: BLOCK    
> __Type__: string    
> __Description__: How you want AWS WAF Regional to respond to requests that match the settings in a rule. Options: ALLOW, BLOCK or COUNT    
>
> __Example__  
> ```hcl
> module "ets_security_waf" {
>   source = "git@ghe.coxautoinc.com:cms-terraform/tf-wafregional.git//ets_security"
>   ...
>   detect_php_insecure_rule_action = ""
>   ...
> }
> ```
>
> [TOC](#ets_security)
----

##### detect_rfi_lfi_traversal_rule_action
> __Required__: False    
> __Default__: BLOCK    
> __Type__: string    
> __Description__: How you want AWS WAF Regional to respond to requests that match the settings in a rule. Options: ALLOW, BLOCK or COUNT    
>
> __Example__  
> ```hcl
> module "ets_security_waf" {
>   source = "git@ghe.coxautoinc.com:cms-terraform/tf-wafregional.git//ets_security"
>   ...
>   detect_rfi_lfi_traversal_rule_action = ""
>   ...
> }
> ```
>
> [TOC](#ets_security)
----

##### detect_ssi_rule_action
> __Required__: False    
> __Default__: BLOCK    
> __Type__: string    
> __Description__: How you want AWS WAF Regional to respond to requests that match the settings in a rule. Options: ALLOW, BLOCK or COUNT    
>
> __Example__  
> ```hcl
> module "ets_security_waf" {
>   source = "git@ghe.coxautoinc.com:cms-terraform/tf-wafregional.git//ets_security"
>   ...
>   detect_ssi_rule_action = ""
>   ...
> }
> ```
>
> [TOC](#ets_security)
----

##### enforce_csrf_rule_action
> __Required__: False    
> __Default__: BLOCK    
> __Type__: string    
> __Description__: How you want AWS WAF Regional to respond to requests that match the settings in a rule. Options: ALLOW, BLOCK or COUNT    
>
> __Example__  
> ```hcl
> module "ets_security_waf" {
>   source = "git@ghe.coxautoinc.com:cms-terraform/tf-wafregional.git//ets_security"
>   ...
>   enforce_csrf_rule_action = ""
>   ...
> }
> ```
>
> [TOC](#ets_security)
----

##### header_max_size
> __Required__: False    
> __Default__: 4093    
> __Type__: string    
> __Description__: The maximum size of the request header that is allowed.                                                                   
>
> __Example__  
> ```hcl
> module "ets_security_waf" {
>   source = "git@ghe.coxautoinc.com:cms-terraform/tf-wafregional.git//ets_security"
>   ...
>   header_max_size = ""
>   ...
> }
> ```
>
> [TOC](#ets_security)
----

##### log_redacted_fields
> __Required__: False    
> __Default__: []    
> __Type__: list(ob  ject)  
> __Description__: A list(objects) specifying what fields should be redacted from the logs.                                                  
>
> __Example__  
> ```hcl
> module "ets_security_waf" {
>   source = "git@ghe.coxautoinc.com:cms-terraform/tf-wafregional.git//ets_security"
>   ...
>   log_redacted_fields = ""
>   ...
> }
> ```
>
> [TOC](#ets_security)
----

##### mitigate_sqli_rule_action
> __Required__: False    
> __Default__: BLOCK    
> __Type__: string    
> __Description__: How you want AWS WAF Regional to respond to requests that match the settings in a rule. Options: ALLOW, BLOCK or COUNT    
>
> __Example__  
> ```hcl
> module "ets_security_waf" {
>   source = "git@ghe.coxautoinc.com:cms-terraform/tf-wafregional.git//ets_security"
>   ...
>   mitigate_sqli_rule_action = ""
>   ...
> }
> ```
>
> [TOC](#ets_security)
----

##### mitigate_xss_rule_action
> __Required__: False    
> __Default__: BLOCK    
> __Type__: string    
> __Description__: How you want AWS WAF Regional to respond to requests that match the settings in a rule. Options: ALLOW, BLOCK or COUNT    
>
> __Example__  
> ```hcl
> module "ets_security_waf" {
>   source = "git@ghe.coxautoinc.com:cms-terraform/tf-wafregional.git//ets_security"
>   ...
>   mitigate_xss_rule_action = ""
>   ...
> }
> ```
>
> [TOC](#ets_security)
----

##### query_string_max_size
> __Required__: False    
> __Default__: 1024    
> __Type__: string    
> __Description__: The maximum size of the request query string that is allowed.                                                             
>
> __Example__  
> ```hcl
> module "ets_security_waf" {
>   source = "git@ghe.coxautoinc.com:cms-terraform/tf-wafregional.git//ets_security"
>   ...
>   query_string_max_size = ""
>   ...
> }
> ```
>
> [TOC](#ets_security)
----

##### restrict_sizes_rule_action
> __Required__: False    
> __Default__: BLOCK    
> __Type__: string    
> __Description__: How you want AWS WAF Regional to respond to requests that match the settings in a rule. Options: ALLOW, BLOCK or COUNT    
>
> __Example__  
> ```hcl
> module "ets_security_waf" {
>   source = "git@ghe.coxautoinc.com:cms-terraform/tf-wafregional.git//ets_security"
>   ...
>   restrict_sizes_rule_action = ""
>   ...
> }
> ```
>
> [TOC](#ets_security)
----

##### uri_max_size
> __Required__: False    
> __Default__: 512    
> __Type__: string    
> __Description__: The maximum size of the request uri that is allowed.                                                                      
>
> __Example__  
> ```hcl
> module "ets_security_waf" {
>   source = "git@ghe.coxautoinc.com:cms-terraform/tf-wafregional.git//ets_security"
>   ...
>   uri_max_size = ""
>   ...
> }
> ```
>
> [TOC](#ets_security)
----


## Resources Created

+ [admin_ipset](#admin_ipset-1)
+ [blacklisted_ipset](#blacklisted_ipset-1)
+ [generic_size_restrictions](#generic_size_restrictions)
+ [csrf_token_size_restrictions](#csrf_token_size_restrictions)
+ [sql_injection_match_set](#sql_injection_match_set)
+ [admin_url_byte_match_set](#admin_url_byte_match_set)
+ [auth_token_byte_match_set](#auth_token_byte_match_set)
+ [csrf_method_byte_match_set](#csrf_method_byte_match_set)
+ [php_insecure_uri_byte_match_set](#php_insecure_uri_byte_match_set)
+ [php_insecure_var_byte_match_set](#php_insecure_var_byte_match_set)
+ [rfi_lfi_traversal_byte_match_set](#rfi_lfi_traversal_byte_match_set)
+ [ssi_byte_match_set](#ssi_byte_match_set)
+ [xss_match](#xss_match)
+ [detect_admin_access_rule](#detect_admin_access_rule)
+ [detect_bad_auth_tokens_rule](#detect_bad_auth_tokens_rule)
+ [detect_blacklisted_ips_rule](#detect_blacklisted_ips_rule)
+ [detect_php_insecure_rule](#detect_php_insecure_rule)
+ [detect_rfi_lfi_traversal_rule](#detect_rfi_lfi_traversal_rule)
+ [detect_ssi_rule](#detect_ssi_rule)
+ [enforce_csrf_rule](#enforce_csrf_rule)
+ [mitigate_sqli_rule](#mitigate_sqli_rule)
+ [mitigate_xss_rule](#mitigate_xss_rule)
+ [restrict_sizes_rule](#restrict_sizes_rule)
+ [generic_web_acl](#generic_web_acl)


### admin_ipset

> __Terraform Resource__: aws_wafregional_ipset  
> 
> [TOC](#ets_security)

### blacklisted_ipset

> __Terraform Resource__: aws_wafregional_ipset  
> 
> [TOC](#ets_security)

### generic_size_restrictions

> __Terraform Resource__: aws_wafregional_size_constraint_set  
> 
> | Type | Data | Text Transform | Operator | Size | Variable |
> |------|------|----------------|----------|------|----------|
> | BODY | | NONE | GT | 4096 | body_max_size |
> | HEADER | cookie | NONE | GT | 4093 | header_max_size |
> | QUERY_STRING | | NONE | GT | 1024 | query_string_max_size |
> | URI | | NONE | GT | 512 | uri_max_size |
>  
> [TOC](#ets_security)

### csrf_token_size_restrictions

> __Terraform Resource__: aws_wafregional_size_constraint_set  
> 
> | Type | Data | Text Transform | Operator | Size | Variable |
> |------|------|----------------|----------|------|----------|
> | HEADER | x-csrf-token | NONE | EQ | 36 | |
>  
> [TOC](#ets_security)

### sql_injection_match_set

> __Terraform Resource__: aws_wafregional_sql_injection_match_set  
> 
> | Type | Data | Text Transform |
> |------|------|----------------|
> | BODY | | HTML_ENTITY_DECODE |
> | BODY | | URL_DECODE |
> | URI | | HTML_ENTITY_DECODE |
> | URI | | URL_DECODE |
> | QUERY_STRING | | HTML_ENTITY_DECODE |
> | QUERY_STRING | | URL_DECODE |
> | HEADER | cookie | HTML_ENTITY_DECODE |
> | HEADER | cookie | URL_DECODE |
>  
> [TOC](#ets_security)

### admin_url_byte_match_set

> __Terraform Resource__: aws_wafregional_byte_match_set  
> 
> | Type | Data | Text Transform | Positional Constraint | Target String |
> |------|------|----------------|-----------------------|---------------|
> | URI | | URL_DECODE | STARTS_WITH | /admin |
>  
> [TOC](#ets_security)

### auth_token_byte_match_set

> __Terraform Resource__: aws_wafregional_byte_match_set  
> 
> | Type | Data | Text Transform | Positional Constraint | Target String |
> |------|------|----------------|-----------------------|---------------|
> | HEADER | authorization | URL_DECODE | ENDS_WITH | .TJVA95OrM7E2cBab30RMHrHDcEfxjoYZgeFONFh7HgQ |
> | HEADER | cookie | URL_DECODE | CONTAINS | example-session-id |
>  
> [TOC](#ets_security)

### csrf_method_byte_match_set

> __Terraform Resource__: aws_wafregional_byte_match_set  
> 
> | Type | Data | Text Transform | Positional Constraint | Target String |
> |------|------|----------------|-----------------------|---------------|
> | METHOD | | URL_DECODE | EXACTLY | post |
>  
> [TOC](#ets_security)

### php_insecure_uri_byte_match_set

> __Terraform Resource__: aws_wafregional_byte_match_set  
> 
> | Type | Data | Text Transform | Positional Constraint | Target String |
> |------|------|----------------|-----------------------|---------------|
> | URI | | URL_DECODE | ENDS_WITH | php |
> | URI | | URL_DECODE | ENDS_WITH | / |
>  
> [TOC](#ets_security)

### php_insecure_var_byte_match_set

> __Terraform Resource__: aws_wafregional_byte_match_set  
> 
> | Type | Data | Text Transform | Positional Constraint | Target String |
> |------|------|----------------|-----------------------|---------------|
> | QUERY_STRING | | URL_DECODE | CONTAINS | _ENV[ |
> | QUERY_STRING | | URL_DECODE | CONTAINS | auto_append_file= |
> | QUERY_STRING | | URL_DECODE | CONTAINS | disable_functions= |
> | QUERY_STRING | | URL_DECODE | CONTAINS | auto_prepend_file= |
> | QUERY_STRING | | URL_DECODE | CONTAINS | safe_mode= |
> | QUERY_STRING | | URL_DECODE | CONTAINS | _SERVER[ |
> | QUERY_STRING | | URL_DECODE | CONTAINS | allow_url_include= |
> | QUERY_STRING | | URL_DECODE | CONTAINS | open_basedir= |
>  
> [TOC](#ets_security)

### rfi_lfi_traversal_byte_match_set

> __Terraform Resource__: aws_wafregional_byte_match_set  
> 
> | Type | Data | Text Transform | Positional Constraint | Target String |
> |------|------|----------------|-----------------------|---------------|
> | QUERY_STRING | | HTML_ENTITY_DECODE | CONTAINS | :// |
> | QUERY_STRING | | HTML_ENTITY_DECODE | CONTAINS | ../ |
> | QUERY_STRING | | URL_DECODE | CONTAINS | :// |
> | QUERY_STRING | | URL_DECODE | CONTAINS | ../ |
> | URI | | HTML_ENTITY_DECODE | CONTAINS | :// |
> | URI | | HTML_ENTITY_DECODE | CONTAINS | ../ |
> | URI | | URL_DECODE | CONTAINS | :// |
> | URI | | URL_DECODE | CONTAINS | ../ |
>  
> [TOC](#ets_security)

### ssi_byte_match_set

> __Terraform Resource__: aws_wafregional_byte_match_set  
> 
> | Type | Data | Text Transform | Positional Constraint | Target String |
> |------|------|----------------|-----------------------|---------------|
> | URI |  | LOWERCASE | ENDS_WITH | .cfg |
> | URI |  | LOWERCASE | ENDS_WITH | .backup |
> | URI |  | LOWERCASE | ENDS_WITH | .ini |
> | URI |  | LOWERCASE | ENDS_WITH | .conf |
> | URI |  | LOWERCASE | ENDS_WITH | .log |
> | URI |  | LOWERCASE | ENDS_WITH | .bak |
> | URI |  | LOWERCASE | ENDS_WITH | .config |
> | URI |  | URL_DECODE | STARTS_WITH | /includes |
>  
> [TOC](#ets_security)

### xss_match

> __Terraform Resource__: aws_wafregional_xss_match_set  
> 
> | Type | Data | Text Transform |
> |------|------|----------------|
> | BODY |  | HTML_ENTITY_DECODE |
> | BODY |  | URL_DECODE |
> | URI |  | HTML_ENTITY_DECODE |
> | URI |  | URL_DECODE |
> | QUERY_STRING |  | HTML_ENTITY_DECODE |
> | QUERY_STRING |  | URL_DECODE |
> | HEADER | cookie | HTML_ENTITY_DECODE |
> | HEADER | cookie | URL_DECODE |
>  
> [TOC](#ets_security)

### detect_admin_access_rule

> __Terraform Resource__: aws_wafregional_rule  
> 
> | Type | Negated | Data ID |
> |------|---------|---------|
> | IPMatch | True | module.admin_ipset.ipset_id |
> | ByteMatch | False | module.admin_url_byte_match_set.byte_match_set_id |
>  
> [TOC](#ets_security)

### detect_bad_auth_tokens_rule

> __Terraform Resource__: aws_wafregional_rule  
> 
> | Type | Negated | Data ID |
> |------|---------|---------|
> | ByteMatch | False | module.auth_token_byte_match_set.byte_match_set_id |
>  
> [TOC](#ets_security)

### detect_blacklisted_ips_rule

> __Terraform Resource__: aws_wafregional_rule  
> 
> | Type | Negated | Data ID |
> |------|---------|---------|
> | IPMatch | False | module.blacklisted_ipset.ipset_id |
>  
> [TOC](#ets_security)

### detect_php_insecure_rule

> __Terraform Resource__: aws_wafregional_rule  
> 
> | Type | Negated | Data ID |
> |------|---------|---------|
> | ByteMatch | False | module.php_insecure_uri_byte_match_set.byte_match_set_id |
> | ByteMatch | False | module.php_insecure_var_byte_match_set.byte_match_set_id |
>  
> [TOC](#ets_security)

### detect_rfi_lfi_traversal_rule

> __Terraform Resource__: aws_wafregional_rule  
> 
> | Type | Negated | Data ID |
> |------|---------|---------|
> | ByteMatch | False | module.rfi_lfi_traversal_byte_match_set.byte_match_set_id |
>  
> [TOC](#ets_security)

### detect_ssi_rule

> __Terraform Resource__: aws_wafregional_rule  
> 
> | Type | Negated | Data ID |
> |------|---------|---------|
> | ByteMatch | False | module.ssi_byte_match_set.byte_match_set_id |
>  
> [TOC](#ets_security)

### enforce_csrf_rule

> __Terraform Resource__: aws_wafregional_rule  
> 
> | Type | Negated | Data ID |
> |------|---------|---------|
> | ByteMatch | False | module.csrf_method_byte_match_set.byte_match_set_id |
> | SizeConstraint | True | module.csrf_token_size_restrictions.size_contraint_id |
>  
> [TOC](#ets_security)

### mitigate_sqli_rule

> __Terraform Resource__: aws_wafregional_rule  
> 
> | Type | Negated | Data ID |
> |------|---------|---------|
> | SqlInjectionMatch | False | module.sql_injection_match_set.sql_injection_match_set_id |
>  
> [TOC](#ets_security)

### mitigate_xss_rule

> __Terraform Resource__: aws_wafregional_rule  
> 
> | Type | Negated | Data ID |
> |------|---------|---------|
> | XssMatch | False | module.xss_match.xss_match_set_id |
>  
> [TOC](#ets_security)

### restrict_sizes_rule

> __Terraform Resource__: aws_wafregional_rule  
> 
> | Type | Negated | Data ID |
> |------|---------|---------|
> | SizeConstraint | False | module.generic_size_restrictions.size_contraint_id |
>  
> [TOC](#ets_security)

### generic_web_acl

> __Terraform Resource__: aws_wafregional_web_acl  
> 
> | Action | Priority | Type | Rule ID |
> |--------|----------|------|---------|
> | BLOCK | 1 | REGULAR | module.restrict_sizes_rule.rule_id |
> | BLOCK | 2 | REGULAR | module.detect_blacklisted_ips_rule.rule_id |
> | BLOCK | 3 | REGULAR | module.detect_bad_auth_tokens_rule.rule_id |
> | BLOCK | 4 | REGULAR | module.mitigate_sqli_rule.rule_id |
> | BLOCK | 5 | REGULAR | module.mitigate_xss_rule.rule_id |
> | BLOCK | 6 | REGULAR | module.detect_rfi_lfi_traversal_rule.rule_id |
> | BLOCK | 7 | REGULAR | module.detect_php_insecure_rule.rule_id |
> | BLOCK | 8 | REGULAR | module.enforce_csrf_rule.rule_id |
> | BLOCK | 9 | REGULAR | module.detect_ssi_rule.rule_id |
> | BLOCK | 10 | REGULAR | module.detect_admin_access_rule.rule_id |
>  
> [TOC](#ets_security)