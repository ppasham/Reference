# WAF Regional XSS Match Set Output
output "xss_match_set_id" {
  value = aws_wafregional_xss_match_set.xss_match_set.id
}

output "xss_match_set_name" {
  value = aws_wafregional_xss_match_set.xss_match_set.name
}