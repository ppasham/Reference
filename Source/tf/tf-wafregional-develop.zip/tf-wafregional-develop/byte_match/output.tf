# WAF Regional Byte Match Output
output "byte_match_set_id" {
  value = aws_wafregional_byte_match_set.byte_match_set.id
}

output "byte_match_set_name" {
  value = aws_wafregional_byte_match_set.byte_match_set.name
}