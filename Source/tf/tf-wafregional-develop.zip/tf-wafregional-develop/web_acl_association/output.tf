# WAF Regional Web ACL Association Outputs
output "web_acl_association_id" {
  value = aws_wafregional_web_acl_association.web_acl_association.id
}