# Terraform WAF Regional Web ACL Association Instance Module
#
##########################################################################################
# Module maintainer: CMS Platform Engineering Services                                   #
# Contact: CMS-SuperSmashCrew@coxautoinc.com                                             #
#                                                                                        #
# Description: WAF Creation                                                              #
# README: https://ghe.coxautoinc.com/cms-terraform/tf-wafregional/blob/master/README.md  #
# ___________________                                                                    #
#                                                                                        #
#  Copyright 2019 Cox Automotive Incorporated                                            #
#  All Rights Reserved.                                                                  #
#                                                                                        #
##########################################################################################

terraform {
  required_version = ">= 0.12"
}

# Variables
variable "resource_arn" {
  default = ""
}

variable "web_acl_id" {
  default = ""
}

# Resources
resource "aws_wafregional_web_acl_association" "web_acl_association" {
  resource_arn = var.resource_arn
  web_acl_id = var.web_acl_id
}