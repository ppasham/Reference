# Terraform WAF Regional Rule Group Instance Module
#
##########################################################################################
# Module maintainer: CMS Platform Engineering Services                                   #
# Contact: CMS-SuperSmashCrew@coxautoinc.com                                             #
#                                                                                        #
# Description: WAF Creation                                                              #
# README: https://ghe.coxautoinc.com/cms-terraform/tf-wafregional/blob/master/README.md  #
# ___________________                                                                    #
#                                                                                        #
#  Copyright 2019 Cox Automotive Incorporated                                            #
#  All Rights Reserved.                                                                  #
#                                                                                        #
##########################################################################################

terraform {
  required_version = ">= 0.12"
}

# Variables
variable "name" {
  default = ""
}

variable "metric_name" {
  default = ""
}

variable "activated_rules" {
  type = list(object({
    action_type = string
    priority = number
    rule_id = string
  }))
}

resource "aws_wafregional_rule_group" "rule_group" {
  metric_name = var.metric_name
  name = var.name

  dynamic "activated_rule" {
    for_each = var.activated_rules
    content {
      action {
        type = activated_rule.value["action_type"]
      }

      priority = activated_rule.value["priority"]
      rule_id = activated_rule.value["rule_id"]
    }
  }
}