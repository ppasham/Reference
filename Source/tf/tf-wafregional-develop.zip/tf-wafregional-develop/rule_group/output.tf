# WAF Regional Rule Group Output
output "rule_group_id" {
  value = aws_wafregional_rule_group.rule_group.id
}

output "rule_group_arn" {
  value = aws_wafregional_rule_group.rule_group.arn
}

output "rule_group_name" {
  value = aws_wafregional_rule_group.rule_group.name
}