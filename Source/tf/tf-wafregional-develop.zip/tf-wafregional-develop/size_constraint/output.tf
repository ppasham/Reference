# WAF Regional Size Constraint Outputs
output "size_contraint_id" {
  value = aws_wafregional_size_constraint_set.size_constraint_set.id
}

output "size_contraint_name" {
  value = aws_wafregional_size_constraint_set.size_constraint_set.name
}