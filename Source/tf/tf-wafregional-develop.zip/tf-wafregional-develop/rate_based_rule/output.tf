# WAF Regional Rate Based Rule Output
output "rate_based_rule_id" {
  value = aws_wafregional_rate_based_rule.rate_based_rule.id
}

output "rate_based_rule_name" {
  value = aws_wafregional_rate_based_rule.rate_based_rule.name
}