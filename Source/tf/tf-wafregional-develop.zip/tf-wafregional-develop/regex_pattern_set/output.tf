# WAF Regional Regex Pattern Set Output
output "regex_pattern_set_id" {
  value = aws_wafregional_regex_pattern_set.regex_pattern_set.id
}

output "regex_pattern_set_name" {
  value = aws_wafregional_regex_pattern_set.regex_pattern_set.name
}