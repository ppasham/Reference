# WAF Regional Geo Match Output
output "geo_match_set_id" {
  value = aws_wafregional_geo_match_set.geo_match_set.id
}

output "geo_match_set_name" {
  value = aws_wafregional_geo_match_set.geo_match_set.name
}