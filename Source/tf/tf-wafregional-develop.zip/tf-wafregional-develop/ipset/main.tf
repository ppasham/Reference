# Terraform WAF Regional IPSet Instance Module
#
##########################################################################################
# Module maintainer: CMS Platform Engineering Services                                   #
# Contact: CMS-SuperSmashCrew@coxautoinc.com                                             #
#                                                                                        #
# Description: WAF Creation                                                              #
# README: https://ghe.coxautoinc.com/cms-terraform/tf-wafregional/blob/master/README.md  #
# ___________________                                                                    #
#                                                                                        #
#  Copyright 2019 Cox Automotive Incorporated                                            #
#  All Rights Reserved.                                                                  #
#                                                                                        #
##########################################################################################

terraform {
  required_version = ">= 0.12"
}

# Variables
variable "name" {
  default = ""
}

variable "set_descriptors" {
  type = list(object({
    type = string
    value = string
  }))
}

# Resources
resource "aws_wafregional_ipset" "ipset" {
  name = var.name

  dynamic "ip_set_descriptor" {
    for_each = var.set_descriptors
    content {
      type = ip_set_descriptor.value["type"]
      value = ip_set_descriptor.value["value"]
    }
  }
}