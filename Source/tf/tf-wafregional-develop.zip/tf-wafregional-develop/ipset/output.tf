# WAF Regional IPSet Output
output "ipset_id" {
  value = aws_wafregional_ipset.ipset.id
}

output "ipset_arn" {
  value = aws_wafregional_ipset.ipset.arn
}

output "ipset_name" {
  value = aws_wafregional_ipset.ipset.name
}