# WAF Regional Module

terraform {
  required_version = ">= 0.12"
}

# Variables
variable "region" {
  default = "us-west-2"
}

variable "byte_match_set_name" {
  default = "wafregional_byte_match_set_example"
}

variable "geo_match_set_name" {
  default = "wafregional_get_match_set_example"
}

variable "admin_remote_ipset_name" {
  default = "wafregional_ipset_example"
}

variable "rate_based_rule_name" {
  default = "wafregional_rate_based_rule_example"
}

variable "rate_based_rule_metric_name" {
  default = "tfWAFRule"
}

variable "rate_based_rule_rate_key" {
  default = "IP"
}

variable "rate_based_rule_rate_limit" {
  default = 100
}

variable "regex_match_name" {
  default = "wagregional_regex_match"
}

variable "regex_pattern_name" {
  default = "wafregional_regex_pattern_example"
}

variable "rule_name" {
  default = "wafregional_rule_example"
}

variable "rule_metric_name" {
  default = "tfWAFRule"
}

variable "rule_group_name" {
  default = "wagregional_rule_group_example"
}

variable "rule_group_metric_name" {
  default = "wagregionalrulegroupmetricnameexample"
}

variable "size_constraint_name" {
  default = "wafregional_size_constraint_example"
}

variable "sql_injection_match_name" {
  default = "wagregional_sql_injection_match_example"
}

variable "web_acl_name" {
  default = "wafregional_web_acl_example"
}

variable "web_acl_metric_name" {
  default = "tfWebACL"
}

variable "web_acl_default_action" {
  default = "ALLOW"
}

variable "web_acl_association_resource_arn" {
  default = ""
}

variable "xss_match_name" {
  default = "wafregional_xss_match_example"
}

variable "admin_remote_ipset" {
  default = [
    {
      type = "IPV4"
      value = "0.0.0.0/24"
    }
  ]
}

variable "byte_match_set_tuples" {
  default = [
    {
      text_transform = "URL_DECODE"
      target_string = "/admin"
      positional_constraint = "STARTS_WITH"
      field_match = {
        type = "URI"
        data = null
      }
    },
    {
      text_transform = "URL_DECODE"
      target_string = "example-session-id"
      positional_constraint = "CONTAINS"
      field_match = {
        type = "HEADER"
        data = "cookie"
      }
    }
  ]
}

variable "geo_match_set_matches" {
  default = [
    {
      type = "Country"
      value = "US"
    },
    {
      type = "Country"
      value = "CA"
    }
  ]
}

variable "regex_pattern_strings" {
  default = [
    "one",
    "two"
  ]
}

variable "size_constraints" {
  default = [
    {
      text_transform = "NONE"
      comparison_operator = "EQ"
      size = "4096"

      field_match = {
        type = "HEADER"
        data = "x-key"
      }
    }
  ]
}

variable "sql_injection_match_tuples" {
  default = [
    {
      text_transform = "URL_DECODE"

      field_match = {
        type = "QUERY_STRING"
        data = ""
      }
    }
  ]
}

variable "xss_match_tuples" {
  default = [
    {
      text_transform = "NONE"
      field_match = {
        type = "QUERY_STRING"
        data = ""
      }
    }
  ]
}

variable "log_redacted_fields" {
  type = list(object({
    data = string
    type = string
  }))

  default = []
}

# Data
data "aws_caller_identity" "current" {}

# Providers
provider "aws" {
  region = var.region
}

provider "alks" {
  url = "https://alks.coxautoinc.com/rest"
}

# Modules
module "byte_match_set" {
  source = "git@ghe.coxautoinc.com:cms-terraform/tf-wafregional.git//byte_match"

  name = var.byte_match_set_name
  match_tuples = var.byte_match_set_tuples
}

module "geo_matches" {
  source = "git@ghe.coxautoinc.com:cms-terraform/tf-wafregional.git//geo_match"

  name = var.geo_match_set_name
  geo_matches = var.geo_match_set_matches
}

module "admin_ipset" {
  source = "git@ghe.coxautoinc.com:cms-terraform/tf-wafregional.git//ipset"

  name = var.admin_remote_ipset_name
  set_descriptors = var.admin_remote_ipset
}

module "rate_based_rule" {
  source = "git@ghe.coxautoinc.com:cms-terraform/tf-wafregional.git//rate_based_rule"

  metric_name = var.rate_based_rule_metric_name
  name = var.rate_based_rule_name
  rate_key = var.rate_based_rule_rate_key
  rate_limit = var.rate_based_rule_rate_limit

  predicates = [
    {
      data_id = module.admin_ipset.ipset_id
      negated = false
      type = "IPMatch"
    }
  ]
}

module "regex_pattern" {
  source = "git@ghe.coxautoinc.com:cms-terraform/tf-wafregional.git//regex_pattern_set"

  name = var.regex_pattern_name
  pattern_strings = var.regex_pattern_strings
}

module "regex_match_set" {
  source = "git@ghe.coxautoinc.com:cms-terraform/tf-wafregional.git//regex_match"

  name = var.regex_match_name
  match_tuples = [
    {
      regex_pattern_set_id = module.regex_pattern.regex_pattern_set_id
      text_transform = "NONE"

      field_match = {
        data = "User-Agent"
        type = "HEADER"
      }
    }
  ]
}

module "rule" {
  source = "git@ghe.coxautoinc.com:cms-terraform/tf-wafregional.git//rule"

  name = var.rule_name
  metric_name = var.rule_metric_name

  predicates = [
    {
      data_id = module.admin_ipset.ipset_id
      negated = false
      type = "IPMatch"
    }
  ]
}

module "rule_group" {
  source = "git@ghe.coxautoinc.com:cms-terraform/tf-wafregional.git//rule_group"

  name = var.rule_group_name
  metric_name = var.rule_group_metric_name

  activated_rules = [
    {
      action_type = "COUNT"
      priority = 10
      rule_id = module.rule.rule_id
    }
  ]
}

module "size_constraint" {
  source = "git@ghe.coxautoinc.com:cms-terraform/tf-wafregional.git//size_constraint"

  name = var.size_constraint_name

  size_constraints = var.size_constraints
}

module "sql_injection_match" {
  source = "git@ghe.coxautoinc.com:cms-terraform/tf-wafregional.git//sql_injection_match"

  name = var.sql_injection_match_name
  match_tuples = var.sql_injection_match_tuples
}

module "web_acl" {
  source = "git@ghe.coxautoinc.com:cms-terraform/tf-wafregional.git//web_acl"

  name = var.web_acl_name
  metric_name = var.web_acl_metric_name
  default_action = var.web_acl_default_action

  region = var.region

  rules = [
    {
      action = {
        type = "BLOCK"
      }

      priority = 10
      rule_id = module.rule.rule_id
      type = "REGULAR"
    }
  ]

  log_destination = "arn:aws:firehose:${var.region}:${data.aws_caller_identity.current.account_id}:deliverystream/aws-waf-logs-${data.aws_caller_identity.current.account_id}"
  log_redacted_fields = var.log_redacted_fields
}

module "web_acl_association" {
  source = "git@ghe.coxautoinc.com:cms-terraform/tf-wafregional.git//web_acl_association"

  resource_arn = var.web_acl_association_resource_arn
  web_acl_id = module.web_acl.web_acl_id
}

module "xss_match" {
  source = "git@ghe.coxautoinc.com:cms-terraform/tf-wafregional.git//xss_match"

  name = var.xss_match_name
  match_tuples = var.xss_match_tuples
}