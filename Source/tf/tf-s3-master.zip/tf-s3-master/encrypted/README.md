# encrypted

<!-- BEGIN_TF_DOCS -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >= 0.14 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [aws_s3_bucket.s3_bucket](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket) | resource |
| [aws_s3_bucket_accelerate_configuration.s3_bucket_accelerate_configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket_accelerate_configuration) | resource |
| [aws_s3_bucket_acl.s3_bucket_acl](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket_acl) | resource |
| [aws_s3_bucket_ownership_controls.bucket_ownership_controls](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket_ownership_controls) | resource |
| [aws_s3_bucket_policy.bucket_policy](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket_policy) | resource |
| [aws_s3_bucket_public_access_block.s3_bucket_public_access_block](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket_public_access_block) | resource |
| [aws_s3_bucket_server_side_encryption_configuration.example](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket_server_side_encryption_configuration) | resource |
| [aws_s3_bucket_versioning.s3_bucket_versioning](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket_versioning) | resource |
| [aws_kms_key.managed_key](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/kms_key) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_acceleration_status"></a> [acceleration\_status](#input\_acceleration\_status) | Sets the accelerate configuration of an existing bucket. Can be Enabled or Suspended | `string` | `"Enabled"` | no |
| <a name="input_bucket_name"></a> [bucket\_name](#input\_bucket\_name) | Name of s3 bucket. Passing null will assign a random, unique name | `string` | n/a | yes |
| <a name="input_canned_acl"></a> [canned\_acl](#input\_canned\_acl) | The canned ACL to apply. Valid values are private, public-read, public-read-write, aws-exec-read, authenticated-read, and log-delivery-write. Defaults to private | `string` | `"private"` | no |
| <a name="input_kms_key"></a> [kms\_key](#input\_kms\_key) | KMS Key name to decrypt bucket | `string` | `"alias/cai-basic-data-kms-key"` | no |
| <a name="input_lifecycle_rule"></a> [lifecycle\_rule](#input\_lifecycle\_rule) | List of maps containing configuration of object lifecycle management. | `any` | `[]` | no |
| <a name="input_tags"></a> [tags](#input\_tags) | A mapping of tags to assign to the object | `map(string)` | `{}` | no |
| <a name="input_versioning_enabled"></a> [versioning\_enabled](#input\_versioning\_enabled) | Flag to indicate if versioning on the bucket should be enabled | `bool` | `true` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_encrypted_s3_bucket_arn"></a> [encrypted\_s3\_bucket\_arn](#output\_encrypted\_s3\_bucket\_arn) | s3 ARN resource output |
| <a name="output_encrypted_s3_bucket_domain_name"></a> [encrypted\_s3\_bucket\_domain\_name](#output\_encrypted\_s3\_bucket\_domain\_name) | s3 domain name output |
| <a name="output_encrypted_s3_bucket_hosted_zone_id"></a> [encrypted\_s3\_bucket\_hosted\_zone\_id](#output\_encrypted\_s3\_bucket\_hosted\_zone\_id) | s3 hosted zone ID output |
| <a name="output_encrypted_s3_bucket_id"></a> [encrypted\_s3\_bucket\_id](#output\_encrypted\_s3\_bucket\_id) | s3 ID resource output |
| <a name="output_encrypted_s3_bucket_region"></a> [encrypted\_s3\_bucket\_region](#output\_encrypted\_s3\_bucket\_region) | s3 region output |
| <a name="output_encrypted_s3_bucket_regional_domain_name"></a> [encrypted\_s3\_bucket\_regional\_domain\_name](#output\_encrypted\_s3\_bucket\_regional\_domain\_name) | s3 regional domain name output |
<!-- END_TF_DOCS -->
