# Terraform Encrypted S3 Bucket
#
##########################################################################################
# Module maintainer: CMS Platform Engineering Services                                   #
# Contact: CMS-SuperSmashCrew@coxautoinc.com                                             #
#                                                                                        #
# Description: Encrypted S3 bucket Creation                                              #
# README: https://ghe.coxautoinc.com/cms-terraform/tf-s3/blob/master/README.md           #
# ___________________                                                                    #
#                                                                                        #
#  Copyright 2019 Cox Automotive Incorporated                                            #
#  All Rights Reserved.                                                                  #
#                                                                                        #
##########################################################################################

terraform {
  required_version = ">= 0.14"
}

variable "bucket_name" {
  type        = string
  description = "Name of s3 bucket. Passing null will assign a random, unique name"
}

variable "kms_key" {
  type        = string
  default     = "alias/cai-basic-data-kms-key"
  description = "KMS Key name to decrypt bucket"
}

variable "tags" {
  type        = map(string)
  default     = {}
  description = "A mapping of tags to assign to the object"
}

variable "lifecycle_rule" {
  type        = any
  default     = []
  description = "List of maps containing configuration of object lifecycle management."
}

variable "canned_acl" {
  type        = string
  default     = "private"
  description = "The canned ACL to apply. Valid values are private, public-read, public-read-write, aws-exec-read, authenticated-read, and log-delivery-write. Defaults to private"
  validation {
    condition     = contains(["private", "public-read", "public-read-write", "aws-exec-read", "authenticated-read", "log-delivery-write"], var.canned_acl)
    error_message = "The canned ACL must be private, public-read, public-read-write, aws-exec-read, authenticated-read, or log-delivery-write."
  }
}

variable "versioning_enabled" {
  type        = bool
  default     = true
  description = "Flag to indicate if versioning on the bucket should be enabled"
}

variable "acceleration_status" {
  type        = string
  default     = "Enabled"
  description = "Sets the accelerate configuration of an existing bucket. Can be Enabled or Suspended"
  validation {
    condition     = contains(["Enabled", "Suspended"], var.acceleration_status)
    error_message = "Accelerate configuration must be one of Enabled or Suspended."
  }
}

# Data Sources
# Pulls KMS information
data "aws_kms_key" "managed_key" {
  key_id = var.kms_key
}

# S3 Bucket creation
resource "aws_s3_bucket_versioning" "s3_bucket_versioning" {
  bucket = aws_s3_bucket.s3_bucket.id
  versioning_configuration {
    status = var.versioning_enabled ? "Enabled" : "Disabled"
  }
}

resource "aws_s3_bucket_acl" "s3_bucket_acl" {
  bucket     = aws_s3_bucket.s3_bucket.id
  acl        = var.canned_acl
  depends_on = [aws_s3_bucket_ownership_controls.bucket_ownership_controls]
}

resource "aws_s3_bucket_accelerate_configuration" "s3_bucket_accelerate_configuration" {
  bucket = aws_s3_bucket.s3_bucket.id
  status = var.acceleration_status
}

resource "aws_s3_bucket_server_side_encryption_configuration" "example" {
  bucket = aws_s3_bucket.s3_bucket.id
  rule {
    apply_server_side_encryption_by_default {
      kms_master_key_id = data.aws_kms_key.managed_key.arn
      sse_algorithm     = "aws:kms"
    }
  }
}

resource "aws_s3_bucket" "s3_bucket" {
  bucket = var.bucket_name
  tags   = var.tags
}

resource "aws_s3_bucket_ownership_controls" "bucket_ownership_controls" {
  bucket = aws_s3_bucket.s3_bucket.id
  rule {
    object_ownership = "BucketOwnerPreferred"
  }
}

#Block Public Access
resource "aws_s3_bucket_public_access_block" "s3_bucket_public_access_block" {
  bucket = aws_s3_bucket.s3_bucket.id

  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true
}
#S3 Policy

resource "aws_s3_bucket_policy" "bucket_policy" {
  bucket = aws_s3_bucket.s3_bucket.id

  policy = jsonencode({
    Version = "2008-10-17"
    Id      = "PutObjPolicy"
    Statement = [
      {
        #DenyStorageWithoutKMSEncryption
        Sid : "DenyStorageWithoutKMSEncryption",
        Effect : "Deny",
        Principal : {
          "AWS" : "*"
        },
        Action : "s3:PutObject",
        Resource = [
          join("", [aws_s3_bucket.s3_bucket.arn, "/*"])
        ],
        Condition : {
          "Null" : {
            "s3:x-amz-server-side-encryption" : "false"
          },
          "StringNotEquals" : {
            "s3:x-amz-server-side-encryption" : "aws:kms"
          }
        }
      },
      {
        Sid : "RequireCMSKey",
        Effect : "Deny",
        Principal : {
          "AWS" : "*"
        },
        Action : "s3:PutObject",
        Resource : [
          join("", [aws_s3_bucket.s3_bucket.arn, "/*"])
        ],
        Condition : {
          "StringEquals" : {
            "s3:x-amz-server-side-encryption" : "aws:kms"
          },
          "StringNotEquals" : {
            "s3:x-amz-server-side-encryption-aws-kms-key-id" : data.aws_kms_key.managed_key.arn
          }
        }
      }
    ]
  })
}
