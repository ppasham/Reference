# Terraform S3 Bucket Logging
#
##########################################################################################
# Module maintainer: CMS Platform Engineering Services                                   #
# Contact: CMS-SuperSmashCrew@coxautoinc.com                                             #
#                                                                                        #
# Description: S3 bucket Logging                                                         #
# README: https://ghe.coxautoinc.com/cms-terraform/tf-s3/blob/master/README.md           #
# ___________________                                                                    #
#                                                                                        #
#  Copyright 2019 Cox Automotive Incorporated                                            #
#  All Rights Reserved.                                                                  #
#                                                                                        #
##########################################################################################

terraform {
  required_version = ">= 0.14"
}

variable "bucket_name" {
  type        = string
  description = "Name of s3 bucket. Passing null will assign a random, unique name"
}

variable "log_bucket_name" {
  type        = string
  default     = ""
  description = "Log bucket name"
}

variable "log_path" {
  type        = string
  default     = ""
  description = "Path to logs"
}

variable "lifecycle_rule" {
  type        = any
  default     = []
  description = "List of maps containing configuration of object lifecycle management."
}

# Data Sources
# Gets Log Bucket arn
data "aws_s3_bucket" "log_bucket" {
  bucket = var.log_bucket_name
}

resource "aws_s3_bucket_logging" "s3_bucket_logging" {
  bucket        = var.bucket_name
  target_bucket = data.aws_s3_bucket.log_bucket.id
  target_prefix = var.log_path
}

resource "aws_s3_bucket_lifecycle_configuration" "s3_bucket_lifecycle_rule" {
  bucket = var.bucket_name

  dynamic "rule" {
    for_each = var.lifecycle_rule
    content {
      id     = lookup(rule.value, "id", null)
      status = lookup(rule.value, "enabled", true) ? "Enabled" : "Disabled"
      dynamic "transition" {
        for_each = lookup(rule.value, "transition", [])

        content {
          date          = lookup(transition.value, "date", null)
          days          = lookup(transition.value, "days", null)
          storage_class = transition.value.storage_class
        }
      }
      # Max 1 block - noncurrent_version_expiration
      dynamic "noncurrent_version_expiration" {
        for_each = length(keys(lookup(rule.value, "noncurrent_version_expiration", {}))) == 0 ? [] : [lookup(rule.value, "noncurrent_version_expiration", {})]

        content {
          noncurrent_days = lookup(noncurrent_version_expiration.value, "days", null)
        }
      }

      # Several blocks - noncurrent_version_transition
      dynamic "noncurrent_version_transition" {
        for_each = lookup(rule.value, "noncurrent_version_transition", [])

        content {
          noncurrent_days = lookup(noncurrent_version_transition.value, "days", null)
          storage_class   = noncurrent_version_transition.value.storage_class
        }
      }
      # Max 1 block - expiration
      dynamic "expiration" {
        for_each = length(keys(lookup(rule.value, "expiration", {}))) == 0 ? [] : [lookup(rule.value, "expiration", {})]

        content {
          date                         = lookup(expiration.value, "date", null)
          days                         = lookup(expiration.value, "days", null)
          expired_object_delete_marker = lookup(expiration.value, "expired_object_delete_marker", null)
        }
      }
    }
  }
}
