# Terraform S3 Bucket
#
##########################################################################################
# Module maintainer: CMS Platform Engineering Services                                   #
# Contact: CMS-SuperSmashCrew@coxautoinc.com                                             #
#                                                                                        #
# Description: Non-Encrypted S3 bucket Creation                                          #
# README: https://ghe.coxautoinc.com/cms-terraform/tf-s3/blob/master/README.md           #
# ___________________                                                                    #
#                                                                                        #
#  Copyright 2019 Cox Automotive Incorporated                                            #
#  All Rights Reserved.                                                                  #
#                                                                                        #
##########################################################################################

terraform {
  required_version = ">= 0.14"
}

variable "bucket_name" {
  type        = string
  description = "Name of s3 bucket. Passing null will assign a random, unique name"
}

variable "tags" {
  type        = map(string)
  default     = {}
  description = "A mapping of tags to assign to the object"
}

variable "acceleration_status" {
  type        = string
  default     = "Enabled"
  description = "Sets the accelerate configuration of an existing bucket. Can be Enabled or Suspended"
  validation {
    condition     = contains(["Enabled", "Suspended"], var.acceleration_status)
    error_message = "Accelerate configuration must be one of Enabled or Suspended."
  }
}

variable "canned_acl" {
  type        = string
  default     = "private"
  description = "The canned ACL to apply. Valid values are private, public-read, public-read-write, aws-exec-read, authenticated-read, and log-delivery-write. Defaults to private"
  validation {
    condition     = contains(["private", "public-read", "public-read-write", "aws-exec-read", "authenticated-read", "log-delivery-write"], var.canned_acl)
    error_message = "The canned ACL must be private, public-read, public-read-write, aws-exec-read, authenticated-read, or log-delivery-write."
  }
}

variable "versioning_enabled" {
  type        = bool
  default     = true
  description = "Flag to indicate if versioning on the bucket should be enabled"
}

# S3 Bucket Creation
resource "aws_s3_bucket_versioning" "s3_bucket_versioning" {
  bucket = aws_s3_bucket.s3_bucket.id
  versioning_configuration {
    status = var.versioning_enabled ? "Enabled" : "Disabled"
  }
}

resource "aws_s3_bucket_accelerate_configuration" "s3_bucket_accelerate_configuration" {
  bucket = aws_s3_bucket.s3_bucket.id
  status = var.acceleration_status
}

# S3 Bucket creation
resource "aws_s3_bucket" "s3_bucket" {
  bucket = var.bucket_name
  tags   = var.tags
}

#Block Public Access
resource "aws_s3_bucket_public_access_block" "s3_bucket_public_access_block" {
  bucket = aws_s3_bucket.s3_bucket.id

  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true
}
