# tf-s3
AWS S3 Bucket Terraform Module

## Description
Terraform module which creates encrypted and non-encrypted S3 buckets on AWS.

**Note: Ensure the `logging` is enabled on the S3 bucket where logs will live. In `Properties` ensure `Server Access Logging` is `enabled`**

## Module READMEs

### [encrypted](./encrypted/README.md)

### [non-encrypted](./non-encrypted/README.md)

### [logging](./logging/README.md)

### [example](./example/README.md)

## Usage

### Encrypted S3 Bucket

```hcl
module "my-encrypted-s3-bucket" {
  source          = "git@ghe.coxautoinc.com:cms-terraform/tf-s3.git//encrypted"
  kms_key         = var.kms_key
  bucket_name     = var.encrypted_bucket_name
  tags            = var.encrypted_tags
}

module "my-encrypted-s3-bucket-logging" {
  source          = "git@ghe.coxautoinc.com:cms-terraform/tf-s3.git//logging"
  bucket_name     = var.encrypted_bucket_name
  log_bucket_name = var.log_bucket_name
  log_path        = var.encrypted_s3_log_path
  # Move files into cold storage after var.archive_after_days days
  lifecycle_rule = [
    {
      id      = "archive_after"
      enabled = true
      transition = [
        {
          days          = var.archive_after_days
          storage_class = "GLACIER"
        }
      ]
    }
  ]
}
```

### Non-Encrypted S3 Bucket

```hcl
module "my-non-encrypted-s3-bucket" {
  source          = "git@ghe.coxautoinc.com:cms-terraform/tf-s3.git//non-encrypted"
  bucket_name     = var.non_encrypted_bucket_name
  tags            = var.non_encrypted_tags
}

module "my-non-encrypted-s3-bucket-logging" {
  source          = "git@ghe.coxautoinc.com:cms-terraform/tf-s3.git//logging"
  bucket_name     = var.non_encrypted_bucket_name
  log_bucket_name = var.log_bucket_name
  log_path        = var.non_encrypted_s3_log_path
  # delete files and all versions after var.delete_after_days
  lifecycle_rule = [
    {
      id      = "delete_after"
      enabled = true
      expiration = {
        days = var.delete_after_days
      }
      noncurrent_version_expiration = {
        days = var.delete_after_days
      }
    }
  ]
}
```

This would create/manage 2 S3 buckets: `encrypted_bucket_name`, and `non_encrypted_bucket_name`

Conditions applied in this module have the following set:

Condition             | Setting        | Description
--------------------- | -------------- | -------------
`acl`                 | private        | Access Control Level. This can be overridden with `var.canned_acl` variable
`versioning`          | enabled = true | Enable versioning. Once you version-enable a bucket, it can never return to an unversioned state. You can, however, suspend versioning on that bucket. This can be overridden with `var.versioning_enabled` variable
`acceleration_status` | Enabled        | Sets the accelerate configuration of an existing bucket. This can be overridden with `var.acceleration_status` variable
`logging`             | Enabled        | Enables server access logging for an Amazon S3 bucket. This can be controlled with `var.log_bucket_name` and `var.log_path` variables
`block_public_acls`   | true           | Public ACL blocked
`block_public_policy` | true           | Public Policy blocked
`ignore_public_acls`  | true           | Public ACL ignored
`restrict_public_buckets` | true       | Public Buckets restricted

### Terraform AWS Provider Version 5.8.0

[Terraform AWS Provider Version 5.8.0](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/guides/version-5-upgrade#provider-version-configuration) Lifecycle management of AWS resources, including EC2, Lambda, EKS, ECS, VPC, S3, RDS, DynamoDB, and more.

## References
* [Terraform Resource](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket)
