# Terraform s3 Bucket Deployment Script

terraform {
  required_version = ">= 0.14"
}

provider "aws" {
  region = var.region
}

# S3 Backend
/* terraform {
  backend "s3" {
  }
} */

# Variables
variable "region" {
  type        = string
  default     = "us-west-2"
  description = "AWS Region"
}

variable "kms_key" {
  type        = string
  default     = "alias/cai-basic-data-kms-key"
  description = "KMS Key name to decrypt bucket"
}

variable "encrypted_bucket_name" {
  type        = string
  default     = "my-encrypted-bucket"
  description = "Name of s3 bucket"
}

variable "non_encrypted_bucket_name" {
  type        = string
  default     = "my-non-encrypted-bucket"
  description = "Name of s3 bucket"
}

variable "encrypted_tags" {
  type = map(string)
  default = {
    Name        = "my-encrypted-bucket"
    Environment = "Test"
    Owner       = "Me_Myself_I"
  }
  description = "A mapping of tags to assign to the object"
}

variable "non_encrypted_tags" {
  type = map(string)
  default = {
    Name        = "my-non-encrypted-bucket"
    Environment = "Test"
    Owner       = "Me_Myself_I"
  }
  description = "A mapping of tags to assign to the object"
}

variable "log_bucket_name" {
  type        = string
  default     = "sepe-logs-np"
  description = "logging bucket name"
}

variable "encrypted_s3_log_path" {
  type        = string
  default     = "/my-encrypted-bucket/logs/"
  description = "Path to logs"
}

variable "non_encrypted_s3_log_path" {
  type        = string
  default     = "my-non-encrypted-bucket/logs/"
  description = "Path to logs"
}

variable "delete_after_days" {
  type        = number
  default     = 60
  description = "How many days to keep files before deleting"
}

variable "archive_after_days" {
  type        = number
  default     = 60
  description = "How many days to keep files before archiving"
}

variable "website" {
  type        = map(string)
  default     = {}
  description = "Map containing static web-site hosting or redirect configuration."
}

resource "random_string" "random" {
  length  = 6
  special = false
  upper   = false
}

# Encrypted s3 bucket creation
module "my-encrypted-s3-bucket" {
  /* source      = "git@ghe.coxautoinc.com:cms-terraform/tf-s3.git//encrypted" */
  source      = "../encrypted"
  kms_key     = var.kms_key
  bucket_name = "${var.encrypted_bucket_name}-${random_string.random.result}"
  tags        = var.encrypted_tags
}

module "my-encrypted-s3-bucket-logging" {
  /* source          = "git@ghe.coxautoinc.com:cms-terraform/tf-s3.git//logging" */
  source          = "../logging"
  bucket_name     = module.my-encrypted-s3-bucket.encrypted_s3_bucket_id
  log_bucket_name = var.log_bucket_name
  log_path        = var.encrypted_s3_log_path
  # Move files into cold storage after var.archive_after_days days
  lifecycle_rule = [
    {
      id      = "archive_after"
      enabled = true
      transition = [
        {
          days          = var.archive_after_days
          storage_class = "GLACIER"
        }
      ]
    }
  ]
}

resource "aws_s3_bucket_website_configuration" "s3_bucket_website_configuration" {
  bucket = module.my-encrypted-s3-bucket.encrypted_s3_bucket_id

  index_document {
    suffix = "index.html"
  }

  error_document {
    key = "error.html"
  }
}

# Non-ecrypted s3 bucket creation
module "my-non-encrypted-s3-bucket" {
  /* source      = "git@ghe.coxautoinc.com:cms-terraform/tf-s3.git//non-encrypted" */
  source      = "../non-encrypted"
  bucket_name = "${var.non_encrypted_bucket_name}-${random_string.random.result}"
  tags        = var.non_encrypted_tags
}

module "my-non-encrypted-s3-bucket-logging" {
  /* source          = "git@ghe.coxautoinc.com:cms-terraform/tf-s3.git//logging" */
  source          = "../logging"
  bucket_name     = module.my-non-encrypted-s3-bucket.s3_bucket_id
  log_bucket_name = var.log_bucket_name
  log_path        = var.non_encrypted_s3_log_path
  # delete files and all versions after var.delete_after_days
  lifecycle_rule = [
    {
      id      = "delete_after"
      enabled = true
      expiration = {
        days = var.delete_after_days
      }
      noncurrent_version_expiration = {
        days = var.delete_after_days
      }
    }
  ]
}
