# example

<!-- BEGIN_TF_DOCS -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >= 0.14 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | 5.22.0 |
| <a name="provider_random"></a> [random](#provider\_random) | 3.5.1 |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_my-encrypted-s3-bucket"></a> [my-encrypted-s3-bucket](#module\_my-encrypted-s3-bucket) | ../encrypted | n/a |
| <a name="module_my-encrypted-s3-bucket-logging"></a> [my-encrypted-s3-bucket-logging](#module\_my-encrypted-s3-bucket-logging) | ../logging | n/a |
| <a name="module_my-non-encrypted-s3-bucket"></a> [my-non-encrypted-s3-bucket](#module\_my-non-encrypted-s3-bucket) | ../non-encrypted | n/a |
| <a name="module_my-non-encrypted-s3-bucket-logging"></a> [my-non-encrypted-s3-bucket-logging](#module\_my-non-encrypted-s3-bucket-logging) | ../logging | n/a |

## Resources

| Name | Type |
|------|------|
| [aws_s3_bucket_website_configuration.s3_bucket_website_configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket_website_configuration) | resource |
| [random_string.random](https://registry.terraform.io/providers/hashicorp/random/latest/docs/resources/string) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_archive_after_days"></a> [archive\_after\_days](#input\_archive\_after\_days) | How many days to keep files before archiving | `number` | `60` | no |
| <a name="input_delete_after_days"></a> [delete\_after\_days](#input\_delete\_after\_days) | How many days to keep files before deleting | `number` | `60` | no |
| <a name="input_encrypted_bucket_name"></a> [encrypted\_bucket\_name](#input\_encrypted\_bucket\_name) | Name of s3 bucket | `string` | `"my-encrypted-bucket"` | no |
| <a name="input_encrypted_s3_log_path"></a> [encrypted\_s3\_log\_path](#input\_encrypted\_s3\_log\_path) | Path to logs | `string` | `"/my-encrypted-bucket/logs/"` | no |
| <a name="input_encrypted_tags"></a> [encrypted\_tags](#input\_encrypted\_tags) | A mapping of tags to assign to the object | `map(string)` | <pre>{<br>  "Environment": "Test",<br>  "Name": "my-encrypted-bucket",<br>  "Owner": "Me_Myself_I"<br>}</pre> | no |
| <a name="input_kms_key"></a> [kms\_key](#input\_kms\_key) | KMS Key name to decrypt bucket | `string` | `"alias/cai-basic-data-kms-key"` | no |
| <a name="input_log_bucket_name"></a> [log\_bucket\_name](#input\_log\_bucket\_name) | logging bucket name | `string` | `"sepe-logs-np"` | no |
| <a name="input_non_encrypted_bucket_name"></a> [non\_encrypted\_bucket\_name](#input\_non\_encrypted\_bucket\_name) | Name of s3 bucket | `string` | `"my-non-encrypted-bucket"` | no |
| <a name="input_non_encrypted_s3_log_path"></a> [non\_encrypted\_s3\_log\_path](#input\_non\_encrypted\_s3\_log\_path) | Path to logs | `string` | `"my-non-encrypted-bucket/logs/"` | no |
| <a name="input_non_encrypted_tags"></a> [non\_encrypted\_tags](#input\_non\_encrypted\_tags) | A mapping of tags to assign to the object | `map(string)` | <pre>{<br>  "Environment": "Test",<br>  "Name": "my-non-encrypted-bucket",<br>  "Owner": "Me_Myself_I"<br>}</pre> | no |
| <a name="input_region"></a> [region](#input\_region) | AWS Region | `string` | `"us-west-2"` | no |
| <a name="input_website"></a> [website](#input\_website) | Map containing static web-site hosting or redirect configuration. | `map(string)` | `{}` | no |

## Outputs

No outputs.
<!-- END_TF_DOCS -->
