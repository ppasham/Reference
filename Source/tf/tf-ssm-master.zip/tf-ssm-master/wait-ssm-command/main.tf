terraform {
  required_version = ">= 0.12"
}

# Variables
variable "association_id" {
  type        = string
  description = "SSM Association ID"
}

variable "timeout" {
  type        = number
  default     = 5
  description = "Timeout in minutes"
}

resource "null_resource" "configure_python" {
  triggers = {
    association_id = var.association_id
  }

  provisioner "local-exec" {
    command = "pip3 install boto3"
  }
}

resource "null_resource" "wait_ssm_command" {
  triggers = {
    association_id = var.association_id
  }

  depends_on = [null_resource.configure_python]

  provisioner "local-exec" {
    command = "python3 ${path.module}/files/wait_for_command.py ${var.association_id} ${var.timeout}"
  }
}