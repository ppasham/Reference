import boto3, sys, time, json

SUCCESS = 'Success'
FAILED = 'Failed'


def wait_for_success(assoc_id, timeout_length):
    ssm_client = boto3.client("ssm")

    ssm_association_description = ssm_client.describe_association(AssociationId=assoc_id)

    ssm_association_status = None

    if ssm_association_description['AssociationDescription'] and \
            ssm_association_description['AssociationDescription']['Overview'] and \
            ssm_association_description['AssociationDescription']['Overview']['Status']:
        ssm_association_status = ssm_association_description['AssociationDescription']['Overview']['Status']
    else:
        sys.exit(f"error: no SSM Association was found with the ID: {assoc_id}")

    timedout = False
    timeout = time.time() + 60 * timeout_length
    while ssm_association_status != SUCCESS and time.time() < timeout:
        time.sleep(10)
        if time.time() > timeout:
            timedout = True
        ssm_association_description = ssm_client.describe_association(AssociationId=assoc_id)
        ssm_association_status = ssm_association_description['AssociationDescription']['Overview']['Status']

    if timedout and ssm_association_status != 'Success':
        sys.exit(f"error: SSM association did not complete in the timeout window")


def wait_for_success_v2(assoc_id, timeout_length):
    ssm_client = boto3.client('ssm')
    ssm_execution_description = ssm_client.describe_association_executions(AssociationId=assoc_id)

    if len(ssm_execution_description['AssociationExecutions']) <= 0:
        ssm_execution_description = ssm_client.describe_association_executions(AssociationId=assoc_id)

    if len(ssm_execution_description['AssociationExecutions']) <= 0:
        sys.exit("error: the association could not be found.")

    execution_ids = []
    execution_results = {}

    for execution in ssm_execution_description['AssociationExecutions']:
        execution_ids.append(execution['ExecutionId'])

    for execution_id in execution_ids:
        exec_description = ssm_client.describe_association_executions(AssociationId=assoc_id, Filters=[
            {'Key': 'ExecutionId', 'Value': execution_id, 'Type': 'EQUAL'}])
        exec_status = exec_description['AssociationExecutions'][0]['Status']

        timedout = False
        timeout = time.time() + 60 * timeout_length
        while exec_status != SUCCESS and exec_status != FAILED and time.time() < timeout:
            time.sleep(2)
            if (time.time() > timeout):
                timedout = True
            exec_description = ssm_client.describe_association_executions(AssociationId=assoc_id, Filters=[
                {'Key': 'ExecutionId', 'Value': execution_id, 'Type': 'EQUAL'}])
            exec_status = exec_description['AssociationExecutions'][0]['Status']

        execution_results[execution_id] = {'status': exec_status, 'timed_out': timedout}

    errors_found = False
    error_string = "error: not all executions succeeded ["
    for exec_id in execution_results.keys():
        if execution_results[exec_id]['status'] == FAILED or execution_results[exec_id]['timed_out'] == True:
            errors_found = True
            error_string = f"{error_string}({exec_id}:{execution_results[exec_id]['status']}:{execution_results[exec_id]['timed_out']})"

    error_string = f"{error_string}]"

    if errors_found:
        sys.exit(error_string)


def main():
    ssm_association_id = sys.argv[1]
    timeout_length = 5
    if sys.argv[2]:
        timeout_length = float(sys.argv[2])

    wait_for_success(ssm_association_id, timeout_length)


if __name__ == "__main__":
    main()
