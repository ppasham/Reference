
variable "name" {
  type        = string
  description = "The name of the Web Application Firewall."

  validation {
    condition     = var.name != ""
    error_message = "Name cannot be empty."
  }
}

variable "description" {
  type        = string
  description = "Friendly description of the WebACL"
  default     = "CAI Security compliant firewall that uses AWS managed rules to scan and block malicious requests."
}

variable "tags" {
  type        = map(string)
  default     = {}
  description = "Tags to add to all resources."
}

variable "scope" {
  type        = string
  default     = "REGIONAL"
  description = <<EOF
Specifies whether this is for an AWS CloudFront distribution or for a regional application.
Valid values are CLOUDFRONT or REGIONAL. To work with CloudFront, you must also specify the
region us-east-1 (N. Virginia) on the AWS provider.
EOF

  validation {
    condition     = contains(["REGIONAL", "CLOUDFRONT"], var.scope)
    error_message = "Scope must be one of REGIONAL or CLOUDFRONT."
  }
}

variable "default_action" {
  type        = string
  description = "The action to perform if none of the rules contained in the WebACL match."
  default     = "allow"
  validation {
    condition     = contains(["allow", "block"], var.default_action)
    error_message = "Default action type must be one of allow or block."
  }
}

variable "admin_ip_set" {
  type        = list(string)
  description = <<EOF
An array of strings that specify one or more IP addresses or blocks of
IP addresses in Classless Inter-Domain Routing (CIDR) notation in IPv4 format.
EOF
  default     = []
}

variable "rate_limit" {
  default     = 15000
  type        = number
  description = <<EOF
Rate limit on number of request from a given IP in any evaluation window
time span (defaults to 5 minutes. see evaluation_window_sec variable).
Set it to zero to disable rate limiting.
EOF
}

variable "evaluation_window_sec" {
  default     = 300
  type        = number
  description = "Evaluation windows for IP rate limiting in seconds"
}

variable "default_aws_rule_group_config" {
  type        = map(bool)
  default     = {}
  description = <<EOF
Boolean map to optionally exclude one of more base AWS rule groups. For example to remove rule group that scans
for linux vulnerabilities use: { 'AWSManagedRulesLinuxRuleSet': false }
EOF
  validation {
    condition     = alltrue([for k in keys(var.default_aws_rule_group_config) : strcontains(k, "AWS")])
    error_message = "Keys of the list must be an AWS ruleset."
  }
  validation {
    condition     = can([for v in values(var.default_aws_rule_group_config) : tobool(v)])
    error_message = "Values of the list must be true or false."
  }

}

variable "additional_aws_rule_groups" {
  type = list(object({
    name            = string
    priority        = number
    override_action = string
    excluded_rules  = list(string)
  }))
  description = "List of additional AWS Managed WAF rule groups."
  default     = []
  validation {
    condition     = alltrue([for i in var.additional_aws_rule_groups : contains(["none", "count"], i.override_action)])
    error_message = "Value for override_action must be one of: count or none."
  }
}

variable "rule_groups" {
  type = list(object({
    name            = string
    arn             = string
    priority        = number
    override_action = string
    excluded_rules  = list(string)
  }))
  description = "List of additional WAFv2 Rule Groups."
  default     = []
}


variable "sampled_requests_enabled" {
  type        = bool
  default     = true
  description = "Turns on request sampling for the firewall and all rule groups."
}
variable "cloudwatch_metrics_enabled" {
  type        = bool
  default     = true
  description = "Turns on cloudwatch metrics for the firewall and all rule groups."
}
