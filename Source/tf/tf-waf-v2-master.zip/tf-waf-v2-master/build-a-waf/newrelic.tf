resource "newrelic_one_dashboard" "dashboard" {
  name        = "WAF Monitor"
  permissions = "public_read_only"

  page {
    name = "waf-monitor"

    widget_area {
      title          = "Total Requests"
      row            = 1
      column         = 1
      width          = 6
      height         = 3
      legend_enabled = true

      nrql_query {
        query = "SELECT count(`aws.wafv2.BlockedRequests`) FROM Metric WHERE `aws.accountId`IN (${data.aws_caller_identity.current.account_id}, '${data.aws_caller_identity.current.account_id}') SINCE 60 MINUTES AGO TIMESERIES"
      }

      nrql_query {
        query = "SELECT count(`aws.wafv2.AllowedRequests`) FROM Metric WHERE `aws.accountId` IN (${data.aws_caller_identity.current.account_id}, '${data.aws_caller_identity.current.account_id}') SINCE 60 MINUTES AGO TIMESERIES"
      }

      nrql_query {
        query = "SELECT count(`aws.wafv2.CountedRequests`) FROM Metric WHERE `aws.accountId` IN (${data.aws_caller_identity.current.account_id}, '${data.aws_caller_identity.current.account_id}') SINCE 60 MINUTES AGO TIMESERIES"
      }

      nrql_query {
        query = "SELECT count(`aws.wafv2.PassedRequests`) FROM Metric WHERE `aws.accountId` IN (${data.aws_caller_identity.current.account_id}, '${data.aws_caller_identity.current.account_id}') SINCE 60 MINUTES AGO TIMESERIES"
      }
    }

    widget_area {
      title          = "Percentage Blocked"
      row            = 1
      column         = 7
      width          = 6
      height         = 3
      legend_enabled = true

      nrql_query {
        query = "SELECT count(`aws.wafv2.BlockedRequests`) FROM Metric FACET `aws.accountId`,`aws.wafv2.Region` WHERE `aws.accountId` IN (${data.aws_caller_identity.current.account_id}, '${data.aws_caller_identity.current.account_id}') SINCE 30 MINUTES AGO TIMESERIES"
      }
    }

    widget_area {
      title          = "Total Blocked Requests"
      row            = 4
      column         = 1
      width          = 4
      height         = 3
      legend_enabled = true

      nrql_query {
        query = "SELECT count(`aws.wafv2.BlockedRequests`) FROM Metric FACET `aws.accountId`,`aws.wafv2.Region` WHERE `aws.accountId` IN (${data.aws_caller_identity.current.account_id}, '${data.aws_caller_identity.current.account_id}') SINCE 30 MINUTES AGO TIMESERIES"
      }
    }

    widget_area {
      title          = "Total Allowed Requests"
      row            = 4
      column         = 5
      width          = 4
      height         = 3
      legend_enabled = true

      nrql_query {
        query = "SELECT count(`aws.wafv2.AllowedRequests`) FROM Metric FACET `aws.accountId`, `aws.wafv2.Region` WHERE `aws.accountId` IN (${data.aws_caller_identity.current.account_id}, '${data.aws_caller_identity.current.account_id}') SINCE 30 MINUTES AGO TIMESERIES"
      }
    }

    widget_area {
      title          = "Total Counted Requests"
      row            = 4
      column         = 9
      width          = 4
      height         = 3
      legend_enabled = true

      nrql_query {
        query = "SELECT count(`aws.wafv2.CountedRequests`) FROM Metric FACET `aws.accountId`,`aws.wafv2.Region` WHERE `aws.accountId` IN (${data.aws_caller_identity.current.account_id}, '${data.aws_caller_identity.current.account_id}') SINCE 30 MINUTES AGO TIMESERIES"
      }
    }

    widget_area {
      title          = "Blocked by WebACL"
      row            = 7
      column         = 1
      width          = 4
      height         = 3
      legend_enabled = true

      nrql_query {
        query = "SELECT sum(`aws.wafv2.BlockedRequests`) FROM Metric FACET `aws.wafv2.WebACL`, `aws.wafv2.Region`  \nWHERE `aws.accountId` IN (${data.aws_caller_identity.current.account_id}, '${data.aws_caller_identity.current.account_id}') \nSINCE 30 MINUTES AGO TIMESERIES"
      }
    }

    widget_area {
      title          = "Allowed by WebACL"
      row            = 7
      column         = 5
      width          = 4
      height         = 3
      legend_enabled = true

      nrql_query {
        query = "SELECT sum(`aws.wafv2.AllowedRequests`) FROM Metric FACET `aws.wafv2.Region`,`aws.wafv2.WebACL` WHERE `aws.accountId` IN (${data.aws_caller_identity.current.account_id}, '${data.aws_caller_identity.current.account_id}') SINCE 30 MINUTES AGO TIMESERIES"
      }
    }

    widget_area {
      title          = "Counted By WebACL"
      row            = 7
      column         = 9
      width          = 4
      height         = 3
      legend_enabled = true

      nrql_query {
        query = "SELECT sum(`aws.wafv2.CountedRequests`) FROM Metric FACET `aws.wafv2.Region`,`aws.wafv2.WebACL` WHERE `aws.accountId` IN (${data.aws_caller_identity.current.account_id}, '${data.aws_caller_identity.current.account_id}') SINCE 30 MINUTES AGO TIMESERIES"
      }
    }

    widget_area {
      title          = "Blocked By Rule"
      row            = 10
      column         = 1
      width          = 4
      height         = 3
      legend_enabled = true

      nrql_query {
        query = "SELECT sum(`aws.wafv2.BlockedRequests`) FROM Metric FACET `aws.wafv2.Region`,`aws.wafv2.Rule`  WHERE `aws.accountId` IN (${data.aws_caller_identity.current.account_id}, '${data.aws_caller_identity.current.account_id}') SINCE 30 MINUTES AGO TIMESERIES"
      }
    }

    widget_area {
      title          = "Allowed By Rule"
      row            = 10
      column         = 5
      width          = 4
      height         = 3
      legend_enabled = true

      nrql_query {
        query = "SELECT sum(`aws.wafv2.AllowedRequests`) FROM Metric FACET `aws.wafv2.Region`,`aws.wafv2.Rule` WHERE `aws.accountId` IN (${data.aws_caller_identity.current.account_id}, '${data.aws_caller_identity.current.account_id}') SINCE 30 MINUTES AGO TIMESERIES"
      }
    }

    widget_area {
      title          = "Counted By Rule"
      row            = 10
      column         = 9
      width          = 4
      height         = 3
      legend_enabled = true

      nrql_query {
        query = "SELECT sum(`aws.wafv2.CountedRequests`) FROM Metric FACET `aws.wafv2.Region`,`aws.wafv2.Rule` WHERE `aws.accountId` IN (${data.aws_caller_identity.current.account_id}, '${data.aws_caller_identity.current.account_id}') SINCE 30 MINUTES AGO TIMESERIES"
      }
    }
  }
}