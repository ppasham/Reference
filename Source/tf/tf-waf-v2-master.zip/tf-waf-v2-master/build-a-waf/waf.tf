/*
ERS PSE WAF template
version 0.1.4
2024-3-14

Ci-Id: CI2363491
Date Generated: Tue Jul 09 19:30:01 GMT 2024
anonymous IP protection: false
block: true
description: Sample Description
geoBlock: false
hostingIpProtection: false
enableCloudwatch: true
osProtection: Mixed or Unknown
nixProtection: true
phpProtection: false
rateLimit: 10000
scope: REGIONAL
wafName: firewall_name
windowsProtection: true
wordpressProtection: false

*/

data "aws_region" "current" {}
data "aws_caller_identity" "current" {}

locals {
  rate_limit              = 10000
  enable_cloudwatch       = true
  wafName                 = "firewall_name"
  log_destination_configs = "arn:aws:s3:::aws-waf-logs-awssecdatalake-us-east-1-waf-logs-raw"

  blocked_countries = [
    { "AF" = "Afghanistan" },
    { "BY" = "Belarus" },
    { "CD" = "Congo, Democratic Republic of the Congo (formerly Zaire)" },
    { "CF" = "Central African Republic" },
    { "CI" = "CÃÂ´te d'Ivoire" },
    { "CN" = "China" },
    { "CO" = "Colombia" },
    { "CU" = "Cuba" },
    { "CY" = "Cyprus" },
    { "ER" = "Eritrea" },
    { "FJ" = "Fiji" },
    { "HK" = "China (Hong Kong)" },
    { "HT" = "Haiti" },
    { "IQ" = "Iraq" },
    { "IR" = "Iran, Islamic Republic of" },
    { "KG" = "Kyrgyzstan" },
    { "KP" = "Korea, Democratic People`s Republic of" },
    { "LB" = "Lebanon" },
    { "LK" = "Sri Lanka" },
    { "LR" = "Liberia" },
    { "LY" = "Libya" },
    { "ME" = "Montenegro" },
    { "MM" = "Myanmar" },
    { "RS" = "Serbia" },
    { "RU" = "Russian Federation" },
    { "SD" = "Sudan" },
    { "SO" = "Somalia" },
    { "SY" = "Syrian Arab Republic" },
    { "UA" = "Ukraine" },
    { "VE" = "Venezuela, Bolivarian Republic of" },
    { "VN" = "Vietnam" },
    { "YE" = "Yemen" },
    { "ZW" = "Zimbabwe" }
  ]

  // this includes the name of the WAF to make these rules unique
  rule_prefix           = "CAI-ERS-Managed-Rules-firewall_name"
  std_allowlist_comment = "Provided by CAI Production Security Engineering. Allows Qualys, Whitehat, Veracode, etc."

  qualys_v4_ips = ["64.39.96.0/20", "139.87.112.0/23"]
  qualys_v6_ips = [
    "2602:FDAA:0:2108::/64", "2600:0C02:1020:2881::/64", "2600:C08:2015:4400::/64", "2600:0C02:1020:2111::/64",
    "2600:0C02:1020:2224::/64"
  ]

  white_hat_non_eu_ips = [
    "52.204.38.40/32", "64.244.165.6/32", "162.223.124.0/27", "162.244.4.2/32", "162.244.4.3/32", "162.244.4.5/32",
    "162.244.4.6/32", "162.244.5.2/32", "162.244.5.3/32", "162.244.5.5/32", "162.244.5.6/32"
  ]
  white_hat_eu_ips = ["54.93.186.146/32", "54.229.46.147/32", "148.253.176.50/32", "194.46.129.108/32"]
  veracode_ips     = ["34.195.146.191/32", "35.156.203.105/32"]
  nonamesec_ips    = ["34.226.151.229/32", "34.205.10.75/32", "52.1.149.40/32"]
  epc_ips          = ["34.226.88.208/32", "34.203.163.56/32"]
  burp_ips         = ["3.221.162.161/32", "3.227.196.210/32", "35.172.46.56/32"]
  cybersec         = ["192.153.76.0/24", "199.201.127.0/24"]
  allowlist_v4_ips = concat(local.qualys_v4_ips, local.white_hat_non_eu_ips, local.white_hat_eu_ips, local.veracode_ips, local.nonamesec_ips, local.epc_ips, local.burp_ips, local.cybersec)
  allowlist_v6_ips = local.qualys_v6_ips
}

resource "aws_wafv2_web_acl" "waf_acl" {
  name        = "firewall_name"
  description = "Sample Description"
  scope       = "REGIONAL"
  default_action {
    allow {}
  }
  tags = {
    "coxauto:ci-id" = "CI2363491"
  }

  visibility_config {
    cloudwatch_metrics_enabled = local.enable_cloudwatch
    metric_name                = "waf-${local.wafName}"
    sampled_requests_enabled   = true
  }

  rule {
    name     = "${local.rule_prefix}-IPv4AllowList"
    priority = 1
    action {
      allow {}
    }
    statement {
      ip_set_reference_statement {
        arn = aws_wafv2_ip_set.cai_ers_ipv4_allowlist.arn
      }
    }
    visibility_config {
      cloudwatch_metrics_enabled = true
      metric_name                = "${local.rule_prefix}-ipv4-allowlist-rule-metrics"
      sampled_requests_enabled   = true
    }
  }
  rule {
    name     = "${local.rule_prefix}-IPv6AllowList"
    priority = 2
    action {
      allow {}
    }
    statement {
      ip_set_reference_statement {
        arn = aws_wafv2_ip_set.cai_ers_ipv6_allowlist.arn
      }
    }
    visibility_config {
      cloudwatch_metrics_enabled = true
      metric_name                = "${local.rule_prefix}-ipv6-allowlist-rule-metrics"
      sampled_requests_enabled   = true
    }
  }

  rule {
    name     = "${local.rule_prefix}-ip-rate-based-rule"
    priority = 5
    action {
      block {}
    }
    statement {
      rate_based_statement {
        limit              = local.rate_limit
        aggregate_key_type = "IP"
      }
    }
    visibility_config {
      cloudwatch_metrics_enabled = true
      metric_name                = "${local.rule_prefix}-ip-rate-based-rule"
      sampled_requests_enabled   = true
    }
  }

  rule {
    name     = "AWSManagedRulesAnonymousIpList"
    priority = 11
    override_action {
      none {}
    }
    statement {
      managed_rule_group_statement {
        name        = "AWSManagedRulesAnonymousIpList"
        vendor_name = "AWS"
        rule_action_override {
          name = "AnonymousIPList"
          action_to_use {
            count {}
          }
        }
        rule_action_override {
          name = "HostingProviderIPList"
          action_to_use {
            count {}
          }
        }
      }
    }
    visibility_config {
      cloudwatch_metrics_enabled = true
      metric_name                = "rule-amazon-ip-reputation-list"
      sampled_requests_enabled   = true
    }
  }
  rule {
    name     = "AWSManagedRulesCommonRuleSet"
    priority = 101
    override_action {
      none {}
    }
    statement {
      managed_rule_group_statement {
        name        = "AWSManagedRulesCommonRuleSet"
        vendor_name = "AWS"
        version     = "Version_1.11"
        rule_action_override {
          action_to_use {
            count {}
          }
          name = "NoUserAgent_HEADER"
        }
        rule_action_override {
          action_to_use {
            count {}
          }
          name = "SizeRestrictions_BODY"
        }
        rule_action_override {
          action_to_use {
            count {}
          }
          name = "SizeRestrictions_QUERYSTRING"
        }
      }
    }
    visibility_config {
      cloudwatch_metrics_enabled = local.enable_cloudwatch
      metric_name                = "waf-${local.wafName}-AWSManagedRulesCommonRuleSet"
      sampled_requests_enabled   = true
    }
  }
  rule {
    name     = "AWSManagedRulesAdminProtectionRuleSet"
    priority = 102
    override_action {
      none {}
    }
    statement {
      managed_rule_group_statement {
        name        = "AWSManagedRulesAdminProtectionRuleSet"
        vendor_name = "AWS"
        version     = "Version_1.1"
      }
    }
    visibility_config {
      cloudwatch_metrics_enabled = local.enable_cloudwatch
      metric_name                = "waf-${local.wafName}-AWSManagedRulesAdminProtectionRuleSet"
      sampled_requests_enabled   = true
    }
  }
  rule {
    name     = "AWSManagedRulesKnownBadInputsRuleSet"
    priority = 103
    override_action {
      none {}
    }
    statement {
      managed_rule_group_statement {
        name        = "AWSManagedRulesKnownBadInputsRuleSet"
        vendor_name = "AWS"
        version     = "Version_1.21"
      }
    }
    visibility_config {
      cloudwatch_metrics_enabled = local.enable_cloudwatch
      metric_name                = "waf-${local.wafName}-AWSManagedRulesKnownBadInputsRuleSet"
      sampled_requests_enabled   = true
    }
  }
  rule {
    name     = "AWSManagedRulesUnixRuleSet"
    priority = 110
    override_action {
      none {}
    }
    statement {
      managed_rule_group_statement {
        name        = "AWSManagedRulesUnixRuleSet"
        vendor_name = "AWS"
        version     = "Version_2.1"
      }
    }
    visibility_config {
      cloudwatch_metrics_enabled = local.enable_cloudwatch
      metric_name                = "waf-${local.wafName}-AWSManagedRulesUnixRuleSet"
      sampled_requests_enabled   = true
    }
  }
  rule {
    name     = "AWSManagedRulesLinuxRuleSet"
    priority = 111
    override_action {
      none {}
    }
    statement {
      managed_rule_group_statement {
        name        = "AWSManagedRulesLinuxRuleSet"
        vendor_name = "AWS"
        version     = "Version_2.2"
      }
    }
    visibility_config {
      cloudwatch_metrics_enabled = local.enable_cloudwatch
      metric_name                = "waf-${local.wafName}-AWSManagedRulesLinuxRuleSet"
      sampled_requests_enabled   = true
    }
  }
  rule {
    name     = "AWSManagedRulesWindowsRuleSet"
    priority = 120
    override_action {
      none {}
    }
    statement {
      managed_rule_group_statement {
        name        = "AWSManagedRulesWindowsRuleSet"
        vendor_name = "AWS"
        version     = "Version_2.0"
      }
    }
    visibility_config {
      cloudwatch_metrics_enabled = local.enable_cloudwatch
      metric_name                = "waf-${local.wafName}-AWSManagedRulesWindowsRuleSet"
      sampled_requests_enabled   = true
    }
  }
  rule {
    name     = "AWSManagedRulesSQLiRuleSet"
    priority = 130
    override_action {
      none {}
    }
    statement {
      managed_rule_group_statement {
        name        = "AWSManagedRulesSQLiRuleSet"
        vendor_name = "AWS"
        version     = "Version_2.0"
      }
    }
    visibility_config {
      cloudwatch_metrics_enabled = local.enable_cloudwatch
      metric_name                = "waf-${local.wafName}-AWSManagedRulesSQLiRuleSet"
      sampled_requests_enabled   = true
    }
  }
  /* Account Takeover Protections (Needs configured to your apps login flow)
    rule {
      name     = "atp-rule-1"
      priority = 1

      override_action {
        count {}
      }

      statement {
        managed_rule_group_statement {
          name        = "AWSManagedRulesATPRuleSet"
          vendor_name = "AWS"

          managed_rule_group_configs {
            aws_managed_rules_atp_rule_set {
              login_path = "/api/1/signin"

              request_inspection {
                password_field {
                  identifier = "/password"
                }

                payload_type = "JSON"

                username_field {
                  identifier = "/email"
                }
              }

              response_inspection {
                status_code {
                  failure_codes = ["403"]
                  success_codes = ["200"]
                }
              }
            }
          }
        }
      }

      visibility_config {
        cloudwatch_metrics_enabled = false
        metric_name                = "friendly-rule-metric-name"
        sampled_requests_enabled   = false
      }
    }
    */

  /*
    rule {
      name     = "AWSManagedRulesBotControlRuleSet"
      priority = 13

      override_action {
        count {}
      }

      statement {
        managed_rule_group_statement {
          name        = "AWSManagedRulesBotControlRuleSet"
          vendor_name = "AWS"
        }
      }

      visibility_config {
        cloudwatch_metrics_enabled = true
        metric_name                = "AWSManagedRulesBotControlRuleSet"
        sampled_requests_enabled   = true
      }

    }
    */
}

resource "aws_wafv2_web_acl_logging_configuration" "waf_acl" {
  resource_arn            = aws_wafv2_web_acl.waf_acl.arn
  log_destination_configs = ["arn:aws:s3:::aws-waf-logs-awssecdatalake-us-east-1-waf-logs-raw"]
}

// ERS allow list
resource "aws_wafv2_ip_set" "cai_ers_ipv4_allowlist" {
  name               = "${local.rule_prefix}-IPv4AllowList"
  description        = local.std_allowlist_comment
  scope              = "REGIONAL"
  ip_address_version = "IPV4"
  addresses          = local.allowlist_v4_ips
  tags = {
    "coxauto:ci-id" = "CI2363491"
  }
}

resource "aws_wafv2_ip_set" "cai_ers_ipv6_allowlist" {
  name               = "${local.rule_prefix}-IPv6AllowList"
  description        = local.std_allowlist_comment
  scope              = "REGIONAL"
  ip_address_version = "IPV6"
  addresses          = local.allowlist_v6_ips
  tags = {
    "coxauto:ci-id" = "CI2363491"
  }
}

/* linking your newly created web acl to your resource
resource "aws_wafv2_web_acl_association" "lb_waf_association" {
web_acl_arn = data.aws_wafv2_web_acl.waf_acl.arn
resource_arn = aws_alb.yourloadbalancer.arn
}
*/
