
resource "aws_api_gateway_rest_api" "sample-api" {
  body        = <<EOF
{
  "openapi" : "3.0.1",
  "info" : {
    "title" : "test-waf-${random_string.random.result}",
    "version" : "1.0"
  },
  "paths" : {
    "/{proxy+}" : {
      "x-amazon-apigateway-any-method" : {
        "parameters" : [ {
          "name" : "proxy",
          "in" : "path",
          "required" : true,
          "schema" : {
            "type" : "string"
          }
        } ],
        "x-amazon-apigateway-integration" : {
          "httpMethod" : "ANY",
          "uri" : "http://postman-echo.com/{proxy}",
          "responses" : {
            "default" : {
              "statusCode" : "200"
            }
          },
          "requestParameters" : {
            "integration.request.path.proxy" : "method.request.path.proxy"
          },
          "passthroughBehavior" : "when_no_match",
          "cacheNamespace" : "5w7duy",
          "cacheKeyParameters" : [ "method.request.path.proxy" ],
          "type" : "http_proxy"
        }
      }
    }
  },
  "components" : { }
}
EOF
  description = "Echo API for testing WAF"
  name        = "test-waf-${random_string.random.result}"
}

resource "aws_api_gateway_deployment" "sample-api" {
  rest_api_id = aws_api_gateway_rest_api.sample-api.id
  triggers = {
    redeployment = sha1(jsonencode(aws_api_gateway_rest_api.sample-api.body))
  }
  lifecycle {
    create_before_destroy = true
  }
}

resource "aws_api_gateway_stage" "sample-api" {
  deployment_id = aws_api_gateway_deployment.sample-api.id
  rest_api_id   = aws_api_gateway_rest_api.sample-api.id
  stage_name    = "test"
}

resource "aws_wafv2_web_acl_association" "sample-api" {
  resource_arn = aws_api_gateway_stage.sample-api.arn
  web_acl_arn  = module.waf_simple.waf_arn
}