terraform {
  required_version = ">= 0.14"
}

provider "aws" {
  region = "us-east-1"
  default_tags {
    tags = {
      Owner   = "SSC"
      Email   = "CMS-SuperSmashCrew@coxautoinc.com"
      Purpose = "Testing Terraform Module"
    }
  }
}

data "aws_region" "current" {}

resource "random_string" "random" {
  length  = 5
  upper   = false
  numeric = false
  special = false
}

module "waf_simple" {
  source                   = "../"
  name                     = "waf-example-default-${random_string.random.result}"
  sampled_requests_enabled = true
}

module "waf_global" {
  source = "../"
  name   = "waf-example-global-${random_string.random.result}"
  additional_aws_rule_groups = [{
    name            = "AWSManagedRulesWordPressRuleSet"
    priority        = 200
    override_action = "count"
    excluded_rules  = ["WordPressExploitablePaths_URIPATH"]
  }]
  admin_ip_set               = ["10.10.10.10/32"]
  cloudwatch_metrics_enabled = true
  default_action             = "block"
  rule_groups = [{
    name            = "custom-rules"
    priority        = 300
    arn             = aws_wafv2_rule_group.waf-example-global-rule.arn
    excluded_rules  = []
    override_action = "none"
  }]
  default_aws_rule_group_config = {
    "AWSManagedRulesAdminProtectionRuleSet" = false
  }
  description              = "Test WAF"
  sampled_requests_enabled = true
  scope                    = "CLOUDFRONT"
  tags = {
    Tag1 = "Hey"
  }
}

resource "aws_wafv2_rule_group" "waf-example-global-rule" {
  name     = "waf-example-global-geo-rule-group-${random_string.random.result}"
  scope    = "CLOUDFRONT"
  capacity = 2

  rule {
    name     = "waf-example-global-geo-rule-${random_string.random.result}"
    priority = 1

    action {
      allow {}
    }
    rule_label {
      name = "xaxaxaxax"
    }

    statement {

      geo_match_statement {
        country_codes = ["US", "NL"]
      }
    }

    visibility_config {
      cloudwatch_metrics_enabled = false
      metric_name                = "waf-example-global-geo-rule-${random_string.random.result}"
      sampled_requests_enabled   = false
    }
  }

  visibility_config {
    cloudwatch_metrics_enabled = false
    metric_name                = "waf-example-global-geo-rule-group-${random_string.random.result}"
    sampled_requests_enabled   = false
  }
}

output "waf_simple" {
  value = module.waf_simple.*
}

output "waf_global" {
  value = module.waf_global.*
}

output "waf_id" {
  value = module.waf_simple.waf_id
}

output "waf_region" {
  value = data.aws_region.current.name
}

output "global_waf_id" {
  value = module.waf_global.waf_id
}

