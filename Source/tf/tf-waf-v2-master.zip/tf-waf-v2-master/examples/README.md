# Example

To deploy the example just run the `terraform init` followed by `terraform apply`.

To validate compliance of the firewall with [CAI Product Security best practices](https://ghe.coxautoinc.com/Product-Security-Engineering/AWS-WAF-Cookbook/blob/main/BestPractices.md#aws-waf-best-practices-at-cai):

1. Install [WAF Compliance Scanner](https://ghe.coxautoinc.com/Product-Security-Engineering/aws-waf-compliance-scanner). Run `pip install waftoolkit --extra-index-url https://artifactory.coxautoinc.com:443/artifactory/api/pypi/cai-pypi/simple`
2. Run following
```
terraform apply -auto-approve && python -m aws_waf_compliance_scanner --webacl=$(terraform output -raw waf_id) --region=$(terraform output -raw waf_region)
```