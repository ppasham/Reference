output "waf_arn" {
  description = "Amazon Resource Name (ARN) of WAF WebACL"
  value       = aws_wafv2_web_acl.v2_waf.arn
}

output "waf_capacity" {
  description = "The web ACL capacity units (WCUs) currently being used by this web ACL"
  value       = aws_wafv2_web_acl.v2_waf.capacity
}

output "waf_id" {
  description = "The ID of the WAF WebACL"
  value       = aws_wafv2_web_acl.v2_waf.id
}