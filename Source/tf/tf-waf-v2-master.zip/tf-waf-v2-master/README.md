# Terraform AWS WAF v2 Module

## Description

Terraform module for easy creation of AWS Web Application Firewall.

Default configuration of this module is based on CAI Security published [Best Practices for Configuring AWS Web Application Firewall](https://ghe.coxautoinc.com/Product-Security-Engineering/AWS-WAF-Cookbook/blob/main/BestPractices.md#aws-waf-best-practices-at-cai) and [AWS WAF cookbook](https://ghe.coxautoinc.com/Product-Security-Engineering/AWS-WAF-Cookbook)

## Usage
This module is intended to bootstrap creation of a base OWASP Top 10 firewall. In addition, it can be customized via variables to:
* use additional [AWS managed rule groups](https://docs.aws.amazon.com/waf/latest/developerguide/aws-managed-rule-groups-list.html)
* include custom user defined WAF rules
* allow set of admin IPs to send any requests

The resulting firewall can either be regional or global. This is controlled with `scope` variable. The regional firewalls can be used by AWS API Gateway APIs and Application Load Balancers. For CloudFront distribution you must create a global firewall.

Basic usage with defaults will create an OWASP firewall in the same region as the AWS provider.
```hcl
module "waf_simple" {
  source = "git@ghe.coxautoinc.com:cms-terraform/tf-waf-v2.git"
  name   = "my-waf"
}
```

More advanced usage:

```hcl
module "waf_global" {
  source = "git@ghe.coxautoinc.com:cms-terraform/tf-waf-v2.git"
  name   = "waf-example"
  additional_aws_rule_groups = [{
    name            = "AWSManagedRulesWordPressRuleSet"
    priority        = 200
    override_action = "count"
    excluded_rules  = ["WordPressExploitablePaths_URIPATH"]
  }]
  admin_ip_set               = ["10.10.10.10/32"]
  default_aws_rule_group_config = {
    "AWSManagedRulesAdminProtectionRuleSet" = false
  }
  description              = "Test WAF"
  scope                    = "CLOUDFRONT"
}
```
After the WAF is created you still need to associate it with your web resource. Use [wafv2_web_acl_association](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/wafv2_web_acl_association) resource and the `waf_arn` output of the module.
```hcl
resource "aws_wafv2_web_acl_association" "connect" {
  resource_arn = "ARN of the resource to protect"
  web_acl_arn  = module.waf_global.waf_arn
}
```

<!-- BEGIN_TF_DOCS -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >= 0.14 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [aws_wafv2_ip_set.admin_ips](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/wafv2_ip_set) | resource |
| [aws_wafv2_ip_set.cai_ers_ipv4_allowlist](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/wafv2_ip_set) | resource |
| [aws_wafv2_ip_set.cai_ers_ipv6_allowlist](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/wafv2_ip_set) | resource |
| [aws_wafv2_web_acl.v2_waf](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/wafv2_web_acl) | resource |
| [aws_wafv2_web_acl_logging_configuration.logging](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/wafv2_web_acl_logging_configuration) | resource |
| [aws_caller_identity.current](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/caller_identity) | data source |
| [aws_region.current](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/region) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_additional_aws_rule_groups"></a> [additional\_aws\_rule\_groups](#input\_additional\_aws\_rule\_groups) | List of additional AWS Managed WAF rule groups. | <pre>list(object({<br>    name            = string<br>    priority        = number<br>    override_action = string<br>    excluded_rules  = list(string)<br>  }))</pre> | `[]` | no |
| <a name="input_admin_ip_set"></a> [admin\_ip\_set](#input\_admin\_ip\_set) | An array of strings that specify one or more IP addresses or blocks of<br>IP addresses in Classless Inter-Domain Routing (CIDR) notation in IPv4 format. | `list(string)` | `[]` | no |
| <a name="input_cloudwatch_metrics_enabled"></a> [cloudwatch\_metrics\_enabled](#input\_cloudwatch\_metrics\_enabled) | Turns on cloudwatch metrics for the firewall and all rule groups. | `bool` | `true` | no |
| <a name="input_default_action"></a> [default\_action](#input\_default\_action) | The action to perform if none of the rules contained in the WebACL match. | `string` | `"allow"` | no |
| <a name="input_default_aws_rule_group_config"></a> [default\_aws\_rule\_group\_config](#input\_default\_aws\_rule\_group\_config) | Boolean map to optionally exclude one of more base AWS rule groups. For example to remove rule group that scans<br>for linux vulnerabilities use: { 'AWSManagedRulesLinuxRuleSet': false } | `map(bool)` | `{}` | no |
| <a name="input_description"></a> [description](#input\_description) | Friendly description of the WebACL | `string` | `"CAI Security compliant firewall that uses AWS managed rules to scan and block malicious requests."` | no |
| <a name="input_evaluation_window_sec"></a> [evaluation\_window\_sec](#input\_evaluation\_window\_sec) | Evaluation windows for IP rate limiting in seconds | `number` | `300` | no |
| <a name="input_name"></a> [name](#input\_name) | The name of the Web Application Firewall. | `string` | n/a | yes |
| <a name="input_rate_limit"></a> [rate\_limit](#input\_rate\_limit) | Rate limit on number of request from a given IP in any evaluation window<br>time span (defaults to 5 minutes. see evaluation\_window\_sec variable).<br>Set it to zero to disable rate limiting. | `number` | `15000` | no |
| <a name="input_rule_groups"></a> [rule\_groups](#input\_rule\_groups) | List of additional WAFv2 Rule Groups. | <pre>list(object({<br>    name            = string<br>    arn             = string<br>    priority        = number<br>    override_action = string<br>    excluded_rules  = list(string)<br>  }))</pre> | `[]` | no |
| <a name="input_sampled_requests_enabled"></a> [sampled\_requests\_enabled](#input\_sampled\_requests\_enabled) | Turns on request sampling for the firewall and all rule groups. | `bool` | `true` | no |
| <a name="input_scope"></a> [scope](#input\_scope) | Specifies whether this is for an AWS CloudFront distribution or for a regional application.<br>Valid values are CLOUDFRONT or REGIONAL. To work with CloudFront, you must also specify the<br>region us-east-1 (N. Virginia) on the AWS provider. | `string` | `"REGIONAL"` | no |
| <a name="input_tags"></a> [tags](#input\_tags) | Tags to add to all resources. | `map(string)` | `{}` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_waf_arn"></a> [waf\_arn](#output\_waf\_arn) | Amazon Resource Name (ARN) of WAF WebACL |
| <a name="output_waf_capacity"></a> [waf\_capacity](#output\_waf\_capacity) | The web ACL capacity units (WCUs) currently being used by this web ACL |
| <a name="output_waf_id"></a> [waf\_id](#output\_waf\_id) | The ID of the WAF WebACL |
<!-- END_TF_DOCS -->

## Logging

The Web Application Firewalls created by this module send the logs to SDL via common s3 Bucket as described in [Security Data Lake WAF Logging](https://coxautoinc.sharepoint.com/sites/service-technology-communications/SitePages/WAF-Logging.aspx) Fuel page.

Logs can be accessed via [Metabase](https://coxautoinc.sharepoint.com/sites/service-technology-communications/SitePages/WAF-Logging.aspx#metabase-access-and-usage-instructions) or [Athena](https://coxautoinc.sharepoint.com/sites/service-technology-communications/SitePages/WAF-Logging.aspx#athena-schema-definitions-and-query-usage)

## Additional Considerations

The WAF will not be created/updated properly under any of the following scenarios:

- Duplicate priority values across any rule/rule group within a WAF Web ACL
- Duplicate AWS managed rule groups within the same WAF Web ACL. This may occur if `additional_aws_rule_groups` includes a rule inside the base AWS rule groups.
