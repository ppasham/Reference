terraform {
  required_version = ">= 0.14"
}


data "aws_region" "current" {}
data "aws_caller_identity" "current" {}

locals {
  # List of AWS Managed WAF rule groups.
  # AWS WAF processes rules with lower priority first.
  base_aws_rule_groups = [
    // Core Rule Set
    {
      name            = "AWSManagedRulesCommonRuleSet",
      priority        = 103
      override_action = "none"
      excluded_rules  = ["SizeRestrictions_BODY", "NoUserAgent_HEADER", "SizeRestrictions_QUERYSTRING"]
    },
    // Admin Protection
    {
      name            = "AWSManagedRulesAdminProtectionRuleSet",
      priority        = 104
      override_action = "none"
      excluded_rules  = []
    },
    // Known Bad Inputs
    {
      name            = "AWSManagedRulesKnownBadInputsRuleSet",
      priority        = 105
      override_action = "none"
      excluded_rules  = []
    },
    // SQL Injection
    {
      name            = "AWSManagedRulesSQLiRuleSet",
      priority        = 106
      override_action = "none"
      excluded_rules  = []
    },
    // Linux(Vuln Protections)
    {
      name            = "AWSManagedRulesLinuxRuleSet",
      priority        = 107
      override_action = "none"
      excluded_rules  = []
    },
    {
      name            = "AWSManagedRulesUnixRuleSet",
      priority        = 108
      override_action = "none"
      excluded_rules  = []
    },
    // Windows
    {
      name            = "AWSManagedRulesWindowsRuleSet",
      priority        = 109
      override_action = "none"
      excluded_rules  = []
    },
    {
      name            = "AWSManagedRulesAmazonIpReputationList",
      priority        = 120
      override_action = "none"
      excluded_rules  = []
    },
    {
      name            = "AWSManagedRulesAnonymousIpList",
      priority        = 125
      override_action = "none"
      excluded_rules  = ["HostingProviderIPList", "AnonymousIPList"]
    }
  ]
  filtered_base_aws_rule_groups = [for rule in local.base_aws_rule_groups : rule if lookup(var.default_aws_rule_group_config, rule.name, true) != false]

  // standard whitelisted IPs
  std_allowlist_comment = "Provided by CAI Production Security Engineering. Allows Qualys, Whitehat, Veracode, etc."
  qualys_v4_ips         = ["64.39.96.0/20", "139.87.112.0/23"]
  qualys_v6_ips = [
    "2602:FDAA:0:2108::/64", "2600:0C02:1020:2881::/64", "2600:C08:2015:4400::/64", "2600:0C02:1020:2111::/64",
    "2600:0C02:1020:2224::/64"
  ]
  white_hat_non_eu_ips = [
    "52.204.38.40/32", "64.244.165.6/32", "162.223.124.0/27", "162.244.4.2/32", "162.244.4.3/32", "162.244.4.5/32",
    "162.244.4.6/32", "162.244.5.2/32", "162.244.5.3/32", "162.244.5.5/32", "162.244.5.6/32"
  ]
  white_hat_eu_ips = ["54.93.186.146/32", "54.229.46.147/32", "148.253.176.50/32", "194.46.129.108/32"]
  veracode_ips     = ["34.195.146.191/32", "35.156.203.105/32"]
  nonamesec_ips    = ["34.226.151.229/32", "34.205.10.75/32", "52.1.149.40/32"]
  epc_ips          = ["34.226.88.208/32", "34.203.163.56/32"]
  burp_ips         = ["3.221.162.161/32", "3.227.196.210/32", "35.172.46.56/32"]
  cybersec         = ["192.153.76.0/24", "199.201.127.0/24"]
  allowlist_v4_ips = concat(local.qualys_v4_ips, local.white_hat_non_eu_ips, local.white_hat_eu_ips, local.veracode_ips, local.nonamesec_ips, local.epc_ips, local.burp_ips, local.cybersec)
  allowlist_v6_ips = local.qualys_v6_ips
}


resource "aws_wafv2_web_acl" "v2_waf" {
  name        = var.name
  scope       = var.scope
  description = var.description

  default_action {
    dynamic "allow" {
      for_each = var.default_action == "allow" ? [1] : []
      content {}
    }
    dynamic "block" {
      for_each = var.default_action == "block" ? [1] : []
      content {}
    }
  }

  # Conditionally create base AWS rules
  dynamic "rule" {
    for_each = local.filtered_base_aws_rule_groups
    content {
      name     = "AWS-${rule.value.name}"
      priority = rule.value.priority
      # **********************************************************************************
      # this ugly code is necessary have because you must have an 'override_action' or 'action'
      # block in every rule even if does not override the action
      override_action {
        dynamic "none" {
          for_each = rule.value.override_action != "count" ? [1] : []
          content {}
        }
        dynamic "count" {
          for_each = rule.value.override_action == "count" ? [1] : []
          content {}
        }
      }
      # **********************************************************************************
      statement {
        managed_rule_group_statement {
          name        = rule.value.name
          vendor_name = "AWS"
          dynamic "rule_action_override" {
            for_each = rule.value.excluded_rules
            content {
              name = rule_action_override.value
              action_to_use {
                count {}
              }
            }
          }
        }
      }

      visibility_config {
        cloudwatch_metrics_enabled = var.cloudwatch_metrics_enabled
        metric_name                = "AWS-${rule.value.name}"
        sampled_requests_enabled   = var.sampled_requests_enabled
      }
    }
  }

  # Additional AWS Rule Groups
  dynamic "rule" {
    for_each = var.additional_aws_rule_groups
    content {
      name     = "AWS-${rule.value.name}"
      priority = rule.value.priority
      override_action {
        dynamic "none" {
          for_each = rule.value.override_action != "count" ? [1] : []
          content {}
        }
        dynamic "count" {
          for_each = rule.value.override_action == "count" ? [1] : []
          content {}
        }
      }
      statement {
        managed_rule_group_statement {
          name        = rule.value.name
          vendor_name = "AWS"
          dynamic "rule_action_override" {
            for_each = rule.value.excluded_rules
            content {
              name = rule_action_override.value
              action_to_use {
                count {}
              }
            }
          }
        }
      }
      visibility_config {
        cloudwatch_metrics_enabled = var.cloudwatch_metrics_enabled
        metric_name                = "AWS-${rule.value.name}"
        sampled_requests_enabled   = var.sampled_requests_enabled
      }
    }
  }

  # Custom rule groups
  dynamic "rule" {
    for_each = var.rule_groups
    content {
      name     = rule.value.name
      priority = rule.value.priority
      override_action {
        dynamic "none" {
          for_each = rule.value.override_action != "count" ? [1] : []
          content {}
        }
        dynamic "count" {
          for_each = rule.value.override_action == "count" ? [1] : []
          content {}
        }
      }
      statement {
        rule_group_reference_statement {
          arn = rule.value.arn

          dynamic "rule_action_override" {
            for_each = rule.value.excluded_rules
            content {
              name = rule_action_override.value
              action_to_use {
                count {}
              }
            }
          }
        }
      }
      visibility_config {
        cloudwatch_metrics_enabled = var.cloudwatch_metrics_enabled
        metric_name                = "${var.name}-${rule.value.name}"
        sampled_requests_enabled   = var.sampled_requests_enabled
      }
    }
  }

  # Admin IP rule
  dynamic "rule" {
    for_each = length(var.admin_ip_set) > 0 ? [1] : []
    content {
      name     = "${var.name}-admin-ip-set-rule"
      priority = 10
      action {
        allow {}
      }
      rule_label {
        name = "custom:admin-ip-set-rule:allowed"
      }
      statement {
        ip_set_reference_statement {
          arn = aws_wafv2_ip_set.admin_ips.0.arn
        }
      }
      visibility_config {
        cloudwatch_metrics_enabled = var.cloudwatch_metrics_enabled
        metric_name                = "${var.name}-admin-ip-set-rule"
        sampled_requests_enabled   = var.sampled_requests_enabled
      }
    }
  }
  // ERS Admin IPs
  rule {
    name = "${var.name}-ers-admin-ip-set-rule"
    rule_label {
      name = "custom:ers-admin-ip-set-rule:allowed"
    }
    priority = 11
    action {
      allow {}
    }
    statement {
      ip_set_reference_statement {
        arn = aws_wafv2_ip_set.cai_ers_ipv4_allowlist.arn
      }
    }
    visibility_config {
      cloudwatch_metrics_enabled = var.cloudwatch_metrics_enabled
      metric_name                = "${var.name}-ers-admin-ip-set-rule"
      sampled_requests_enabled   = var.sampled_requests_enabled
    }
  }
  rule {
    name = "${var.name}-ers-admin-ipv6-set-rule"
    rule_label {
      name = "custom:ers-admin-ipv6-set-rule:allowed"
    }
    priority = 12
    action {
      allow {}
    }
    statement {
      ip_set_reference_statement {
        arn = aws_wafv2_ip_set.cai_ers_ipv6_allowlist.arn
      }
    }
    visibility_config {
      cloudwatch_metrics_enabled = var.cloudwatch_metrics_enabled
      metric_name                = "${var.name}-ers-admin-ipv6-set-rule"
      sampled_requests_enabled   = var.sampled_requests_enabled
    }
  }

  dynamic "rule" {
    for_each = var.rate_limit != 0 ? [1] : []
    content {
      name = "${var.name}-ip-rate-based-rule"
      rule_label {
        name = "custom:ip-rate-based-rule:throttled"
      }
      priority = 50
      action {
        block {
          custom_response {
            custom_response_body_key = "too-many-requests"
            response_code            = 429

            response_header {
              name  = "Retry-After"
              value = var.evaluation_window_sec
            }
          }
        }
      }
      statement {
        rate_based_statement {
          limit                 = var.rate_limit
          aggregate_key_type    = "IP"
          evaluation_window_sec = var.evaluation_window_sec
        }
      }
      visibility_config {
        cloudwatch_metrics_enabled = var.cloudwatch_metrics_enabled
        metric_name                = "${var.name}-ip-rate-based-rule"
        sampled_requests_enabled   = var.sampled_requests_enabled
      }
    }
  }

  dynamic "rule" {
    for_each = var.rate_limit != 0 ? [1] : []
    content {
      name = "${var.name}-forwarded-ip-rate-based-rule"
      rule_label {
        name = "custom:forwarded-ip-rate-based-rule:throttled"
      }
      priority = 49
      action {
        block {
          custom_response {
            custom_response_body_key = "too-many-requests"
            response_code            = 429

            response_header {
              name  = "Retry-After"
              value = var.evaluation_window_sec
            }
          }
        }
      }
      statement {
        rate_based_statement {
          limit                 = var.rate_limit
          aggregate_key_type    = "FORWARDED_IP"
          evaluation_window_sec = var.evaluation_window_sec
          forwarded_ip_config {
            fallback_behavior = "NO_MATCH"
            header_name       = "X-Forwarded-For"
          }
        }

      }
      visibility_config {
        cloudwatch_metrics_enabled = var.cloudwatch_metrics_enabled
        metric_name                = "${var.name}-forwarded-ip-rate-based-rule"
        sampled_requests_enabled   = var.sampled_requests_enabled
      }
    }
  }

  visibility_config {
    cloudwatch_metrics_enabled = var.cloudwatch_metrics_enabled
    metric_name                = var.name
    sampled_requests_enabled   = var.sampled_requests_enabled
  }

  custom_response_body {
    content = jsonencode(
      {
        message = "Too many requests"
      }
    )
    content_type = "APPLICATION_JSON"
    key          = "too-many-requests"

  }

  tags = var.tags
}

resource "aws_wafv2_ip_set" "admin_ips" {
  count              = length(var.admin_ip_set) > 0 ? 1 : 0
  name               = "${var.name}-admin-ip-set"
  description        = "Admin IPs for WAF: ${var.name}"
  scope              = var.scope
  ip_address_version = "IPV4"
  addresses          = var.admin_ip_set

  tags = var.tags
}

// ERS allow list
resource "aws_wafv2_ip_set" "cai_ers_ipv4_allowlist" {
  name               = "${var.name}-admin-ip-set-ers"
  description        = local.std_allowlist_comment
  scope              = var.scope
  ip_address_version = "IPV4"
  addresses          = local.allowlist_v4_ips
  tags               = var.tags
}

resource "aws_wafv2_ip_set" "cai_ers_ipv6_allowlist" {
  name               = "${var.name}-admin-ipv6-set-ers"
  description        = local.std_allowlist_comment
  scope              = var.scope
  ip_address_version = "IPV6"
  addresses          = local.allowlist_v6_ips
  tags               = var.tags
}

resource "aws_wafv2_web_acl_logging_configuration" "logging" {
  log_destination_configs = ["arn:aws:s3:::aws-waf-logs-awssecdatalake-us-east-1-waf-logs-raw"]
  resource_arn            = aws_wafv2_web_acl.v2_waf.arn

  redacted_fields {
    single_header {
      name = "x-api-key"
    }
  }
  redacted_fields {
    single_header {
      name = "authorization"
    }
  }

}
