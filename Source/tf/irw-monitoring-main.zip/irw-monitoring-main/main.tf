# Terraform IRW Monitoring Module
#
###########################################################################################
# Module maintainer: CMS Platform Engineering Services                                    #
# Contact: CMS-SuperSmashCrew@coxautoinc.com                                              #
#                                                                                         #
# Description: IRW Monitoring Module                                                      #
#                                                                                         #
# ___________________                                                                     #
#                                                                                         #
#  Copyright 2024 Cox Automotive Incorporated                                             #
#  All Rights Reserved.                                                                   #
#                                                                                         #
###########################################################################################

# Requirements
terraform {
  required_version = ">= 1.6.3"
  required_providers {
    newrelic = {
      source = "newrelic/newrelic"
    }
    pagerduty = {
      source = "pagerduty/pagerduty"
    }
  }
}

variable "environment" {
  default     = ""
  type        = string
  description = "The environment for the component"

  validation {
    condition     = alltrue([var.environment != "prd", var.environment != "production"])
    error_message = "Production environment variable must be prod"
  }
}

variable "coxauto_ci_id" {
  default     = ""
  type        = string
  description = "The environment for the component"

  validation {
    condition     = length(var.coxauto_ci_id) > 0
    error_message = "The CIID is required for use in this module"
  }
}

variable "sled_api_key" {
  default     = ""
  description = "The API key used by the HTTP Datasource to query SLED"
}

variable "slack_api_key" {
  default     = ""
  description = "Slack API token to find Channel ID"
}

variable "nrql_query_alerts" {
  default = []
  type = list(object({
    name                           = string
    description                    = string
    type                           = optional(string, "static")
    priority_level                 = optional(string, "")
    runbook_url                    = optional(string, "")
    violation_time_limit_seconds   = optional(string, null)
    fill_option                    = optional(string, "static")
    fill_value                     = optional(string, 1.0)
    aggregation_window             = optional(string, "60")
    aggregation_method             = optional(string, "event_flow")
    aggregation_delay              = optional(string, "120")
    aggregation_timer              = optional(string, "")
    expiration_duration            = optional(string, null)
    nrql_query                     = string
    critical_operator              = string
    critical_threshold             = string
    critical_threshold_duration    = string
    critical_threshold_occurrences = string
    warning_operator               = optional(string)
    warning_threshold              = optional(string)
    warning_threshold_duration     = optional(string)
    warning_threshold_occurrences  = optional(string)
    slide_by                       = optional(string, null)
    baseline_direction             = optional(string, null)
    tags                           = optional(map(string))
  }))
  description = "New Relic Query Alerts"

  validation {
    condition     = alltrue([for o in var.nrql_query_alerts : can(regex("^[-0-9A-Za-z]+$", o.name))])
    error_message = "For New Relic Alerts the name variable can only use the following: -, a-z, A-Z and 0-9."
  }

  validation {
    condition     = alltrue([for o in var.nrql_query_alerts : can(regex("P1|P2|P3|P4|P5|^$", o.priority_level))])
    error_message = "For New Relic Alerts the Priority Level Variable must be blank, P1, P2, P3, P4, P5."
  }
}

variable "newrelic_synthetics_secure_credentials" {
  type = list(object({
    key         = string
    value       = string
    description = string
  }))
  description = "New Relic Secure Credential for Synthetics"
  sensitive   = true
  default     = []
}

variable "newrelic_synthetic_script_monitor" {
  type = list(object({
    name                  = string
    type                  = optional(string, "SCRIPT_API")
    location_public       = optional(list(string), null)
    location_private_guid = optional(list(string), [])
    period                = string
    script_language       = optional(string, "")
    runtime_type          = optional(string, "")
    runtime_type_version  = optional(string, "")
    script_file           = string
    script_variables      = optional(map(string), {})
    tags                  = optional(map(string))
  }))
  description = "New Relic Synthetic that should be created"
  default     = []

  validation {
    condition     = alltrue([for o in var.newrelic_synthetic_script_monitor : can(regex("^[-0-9A-Za-z]+$", o.name))])
    error_message = "For New Relic Synthetics the name variable can only use the following: -, a-z, A-Z and 0-9."
  }
}

variable "newrelic_synthetic_step_monitor" {
  type = list(object({
    name                  = string
    location_public       = optional(list(string), null)
    location_private_guid = optional(list(string), [])
    period                = string
    steps = list(object({
      ordinal = string
      type    = string
      values  = list(string)
    }))
    tags = optional(map(string))
  }))
  description = "New Relic Synthetic that should be created"
  default     = []

  validation {
    condition     = alltrue([for o in var.newrelic_synthetic_step_monitor : can(regex("^[-0-9A-Za-z]+$", o.name))])
    error_message = "For New Relic Synthetics the name variable can only use the following: -, a-z, A-Z and 0-9."
  }
}

variable "newrelic_service_levels" {
  type = list(object({
    name               = string
    description        = string
    valid_events_from  = string
    valid_events_where = string
    bad_events_from    = string
    bad_events_where   = string
    objective_target   = string
    time_window_count  = string
    time_window_unit   = string
  }))
  description = "Optional New Relic SLO/SLI Levels to Create"
  default     = []

  validation {
    condition     = alltrue([for o in var.newrelic_service_levels : can(regex("^[-0-9A-Za-z]+$", o.name))])
    error_message = "For New Relic Service Levels the name variable can only use the following: -, a-z, A-Z and 0-9."
  }
}

#----------------------------------------------------------
# Data Sources
#----------------------------------------------------------
#data "pagerduty_escalation_policy" "escalation" {
#  count = var.environment == "prod" ? 1 : 0
#  name  = local.escalation_policy_name
#}

data "pagerduty_vendor" "newrelic" {
  name = "New Relic"
}

data "pagerduty_vendor" "splunk" {
  name = "Splunk"
}

data "pagerduty_business_service" "cms_service" {
  name = "Collateral Management Services"
}

data "pagerduty_priority" "p1" {
  name = "P1"
}

data "pagerduty_priority" "p2" {
  name = "P2"
}

data "pagerduty_priority" "p3" {
  name = "P3"
}

data "pagerduty_priority" "p4" {
  name = "P4"
}

data "pagerduty_priority" "p5" {
  name = "P5"
}

data "newrelic_account" "account_id" {
  account_id = var.environment != "prod" ? "2767861" : "1842316"
}

data "newrelic_notification_destination" "np_notification_destination" {
  count = var.environment != "prod" ? 1 : 0
  name  = "Cox Automotive"
}

data "http" "sled_response" {
  url    = "https://api.coxauto-awssled.com/hierarchy/component/${var.coxauto_ci_id}"
  method = "GET"

  request_headers = {
    Content-Type = "application/json"
    accept       = "application/vnd.blower.v2+json"
    x-api-key    = var.sled_api_key
  }

  request_body = ""
}

data "http" "slack_response" {
  url    = "https://slack.com/api/search.messages?query=${local.slack_query}&count=1&pretty=1"
  method = "GET"

  request_headers = {
    Content-Type  = "application/json"
    Authorization = var.slack_api_key
  }

  request_body = ""
}

locals {
  sled_response          = jsondecode(data.http.sled_response.response_body)
  slack_response         = jsondecode(data.http.slack_response.response_body)
  workload               = replace(local.sled_response.workload.name, " ", "-")
  component              = replace(local.sled_response.name, " ", "-")
  team_name              = replace(local.sled_response.parents.owner.name, " ", "-")
  component_description  = local.sled_response.description
  component_tier_1_owner = local.sled_response.parents.team_hierarchy[0].name
  component_tier_2_owner = replace(local.sled_response.parents.team_hierarchy[1].name, " ", "-")
  component_tier_3_owner = replace(local.sled_response.parents.team_hierarchy[2].name, " ", "-")
  slack_query            = var.environment == "prod" ? (join("-", [local.component_tier_3_owner, local.team_name, var.environment, "low-priority-alerts-channel"])) : (join("-", [local.component_tier_3_owner, local.team_name, "non-prod-alerts-channel"]))
  slack_channel_id       = local.slack_response.messages.matches[0].channel.id
  service_name           = lower(join("-", [local.component_tier_3_owner, local.workload, local.component, var.environment]))
  # escalation_policy_name = lower(join("-", [local.component_tier_3_owner, local.team_name, "Escalation-Policy"]))
  pagerduty_slack_connection = [
    {
      channel_id = "C048X215PPX"
      urgency    = "high"
      priorities = []
    },
    {
      channel_id = local.slack_channel_id
      urgency    = "low"
      priorities = [data.pagerduty_priority.p5.id]
    }
  ]
}

#-------------------------------------------------------------------------
# Pagerduty Configs
#-------------------------------------------------------------------------
resource "pagerduty_service" "pd_service" {
  count                   = var.environment == "prod" ? 1 : 0
  name                    = lower(join("-", [local.component_tier_2_owner, local.workload, local.component]))
  description             = "IR:${var.coxauto_ci_id}: ${local.component_description} [${local.component_tier_1_owner} - ${local.component_tier_2_owner} - ${local.component_tier_3_owner} - ${local.team_name}]"
  auto_resolve_timeout    = "null"
  acknowledgement_timeout = "null"
  escalation_policy       = "P1YCQOY" #data.pagerduty_escalation_policy.escalation[count.index].id
  alert_creation          = "create_alerts_and_incidents"

  incident_urgency_rule {
    type    = "constant"
    urgency = "severity_based"
  }
}

resource "pagerduty_incident_workflow" "conference_bridge" {
  count       = var.environment == "prod" ? 1 : 0
  name        = "Dynamic-Conference-Bridge-Workflow"
  description = "This Workflow creates a Dynamic Mirosoft Teams Conference Bridge."
  step {
    name   = "Create Conference Bridge in Microsoft Teams"
    action = "pagerduty.com:incident-workflows:create-ms-teams-conference-bridge:3"
    input {
      name  = "Meeting Name"
      value = "{{incident.service.name}}_{{incident.incident_number}}"
    }
    input {
      name  = "Microsoft Teams Organization"
      value = "7c7fea3f-e205-448e-b10a-701c54916e39"
    }
  }
}

resource "pagerduty_incident_workflow_trigger" "high_trigger" {
  count                      = var.environment == "prod" ? 1 : 0
  type                       = "conditional"
  workflow                   = pagerduty_incident_workflow.conference_bridge[count.index].id
  services                   = [pagerduty_service.pd_service[count.index].id]
  condition                  = "incident.urgency matches 'high'"
  subscribed_to_all_services = false
}

resource "pagerduty_service_integration" "newrelic_integration" {
  count   = var.environment == "prod" ? 1 : 0
  name    = lower(join("-", [local.service_name, "NewRelic-Integration"]))
  service = pagerduty_service.pd_service[count.index].id
  vendor  = data.pagerduty_vendor.newrelic.id
}

resource "pagerduty_service_integration" "splunk_integration" {
  count   = var.environment == "prod" ? 1 : 0
  name    = lower(join("-", [local.service_name, "Splunk-Integration"]))
  service = pagerduty_service.pd_service[count.index].id
  vendor  = data.pagerduty_vendor.splunk.id
}

resource "pagerduty_slack_connection" "pagerduty_slack_connection" {
  count             = var.environment == "prod" ? length(local.pagerduty_slack_connection) : 0
  source_id         = join("", pagerduty_service.pd_service[*].id)
  source_type       = "service_reference"
  workspace_id      = "T02LRKTL7"
  channel_id        = local.pagerduty_slack_connection[count.index].channel_id
  notification_type = "responder"
  config {
    events = [
      "incident.triggered",
      "incident.acknowledged",
      "incident.escalated",
      "incident.resolved",
      "incident.reassigned",
      "incident.annotated",
      "incident.unacknowledged",
      "incident.delegated",
      "incident.priority_updated",
      "incident.responder.added",
      "incident.responder.replied",
      "incident.status_update_published",
      "incident.reopened"
    ]
    urgency    = local.pagerduty_slack_connection[count.index].urgency
    priorities = local.pagerduty_slack_connection[count.index].priorities
  }
}

resource "pagerduty_service_dependency" "service_dependency_business" {
  count = var.environment == "prod" ? 1 : 0
  dependency {
    dependent_service {
      id   = data.pagerduty_business_service.cms_service.id
      type = "business_service"
    }
    supporting_service {
      id   = pagerduty_service.pd_service[0].id
      type = "service"
    }
  }
}

resource "pagerduty_event_orchestration_service" "priority_update" {
  count                                  = var.environment == "prod" ? 1 : 0
  service                                = pagerduty_service.pd_service[0].id
  enable_event_orchestration_for_service = true
  set {
    id = "start"
    rule {
      label = "Set any P5 Alerts from New Relic and Splunk to Warning and Create Incident but don't Notify On-Call Team"
      condition {
        expression = "event.custom_details['Description'] matches part 'Priority:P5'"
      }
      condition {
        expression = "event.custom_details.pd_priority matches part 'Priority:P5'"
      }
      actions {
        severity = "warning"
        priority = data.pagerduty_priority.p5.id
      }
    }
  }
  catch_all {
    actions {}
  }
}

#-------------------------------------------------------------------------------
# New Relic Configs
#-------------------------------------------------------------------------------
resource "newrelic_alert_policy" "alert_policy" {
  name                = lower(join("-", [local.service_name, "alert-policy"]))
  incident_preference = "PER_CONDITION"
}

resource "newrelic_notification_channel" "np_notification" {
  count          = var.environment != "prod" ? 1 : 0
  account_id     = data.newrelic_account.account_id.id
  name           = lower(join("-", [local.service_name, "slack-channel"]))
  type           = "SLACK"
  destination_id = data.newrelic_notification_destination.np_notification_destination[count.index].id
  product        = "IINT"

  property {
    key   = "channelId"
    value = local.slack_channel_id
  }

  property {
    key   = "summary"
    value = "{{#each accumulations.conditionName}}{{this}}{{#unless @last}}, {{/unless}}{{/each}}{{#each (json annotations.wildcard)}}{{this}}{{/each}}"
  }

  property {
    key   = "customDetailsSlack"
    value = <<-EOT
            {
            "Description":{{ json accumulations.conditionDescription }},
            "Runbook":"{{#each accumulations.runbookUrl}}{{this}}{{#unless @last}}, {{/unless}}{{/each}}"
            "Query":{{ json accumulations.nrqlQuery }},
            "Total Incidents":{{json totalIncidents}},
            "Component Overview":"${newrelic_workload.workload.permalink}",
            "Details": {
                {{#each accumulations.rawTag}}"{{escape @key}}": {{#if this.[0]}}{{json this.[0]}}{{else}}"empty"{{/if}}{{#unless @last}},{{/unless}}{{/each}}
              }
            }
        EOT
  }
}

resource "newrelic_workflow" "np_workflow" {
  count                 = var.environment != "prod" ? 1 : 0
  name                  = lower(join("-", [local.service_name, "workflow"]))
  muting_rules_handling = "NOTIFY_ALL_ISSUES"

  issues_filter {
    name = "filter-name"
    type = "FILTER"

    predicate {
      attribute = "labels.policyIds"
      operator  = "EXACTLY_MATCHES"
      values    = [newrelic_alert_policy.alert_policy.id]
    }
  }

  destination {
    channel_id = newrelic_notification_channel.np_notification[count.index].id
  }
}

resource "newrelic_notification_destination" "prod_pd_destination" {
  count      = var.environment == "prod" ? 1 : 0
  account_id = data.newrelic_account.account_id.id
  name       = lower(join("-", [local.service_name, "pagerduty-integration"]))
  type       = "PAGERDUTY_SERVICE_INTEGRATION"

  property {
    key   = ""
    value = ""
  }

  auth_token {
    prefix = "Token token="
    token  = pagerduty_service_integration.newrelic_integration[count.index].integration_key
  }
}

resource "newrelic_notification_channel" "prod_pd_notification" {
  count          = var.environment == "prod" ? 1 : 0
  account_id     = data.newrelic_account.account_id.id
  name           = lower(join("-", [local.service_name, "PagerDuty"]))
  type           = "PAGERDUTY_SERVICE_INTEGRATION"
  destination_id = newrelic_notification_destination.prod_pd_destination[count.index].id
  product        = "IINT"

  property {
    key   = "summary"
    value = "{{#each accumulations.conditionName}}{{this}}{{#unless @last}}, {{/unless}}{{/each}}{{#each (json annotations.wildcard)}}{{this}}{{/each}}"
  }

  property {
    key   = "customDetails"
    value = <<-EOT
            {
            "Description":{{ json accumulations.conditionDescription }},
            "Runbook":"{{#each accumulations.runbookUrl}}{{this}}{{#unless @last}}, {{/unless}}{{/each}}"
            "Query":{{ json accumulations.nrqlQuery }},
            "Total Incidents":{{json totalIncidents}},
            "Component Overview":"${newrelic_workload.workload.permalink}",
            "Details": {
                {{#each accumulations.rawTag}}"{{escape @key}}": {{#if this.[0]}}{{json this.[0]}}{{else}}"empty"{{/if}}{{#unless @last}},{{/unless}}{{/each}}
              }
            }
        EOT
  }
}

resource "newrelic_workflow" "prod_pd_workflow" {
  count                 = var.environment == "prod" ? 1 : 0
  name                  = lower(join("-", [local.service_name, "pagerduty-workflow"]))
  muting_rules_handling = "NOTIFY_ALL_ISSUES"

  issues_filter {
    name = "filter-name"
    type = "FILTER"

    predicate {
      attribute = "labels.policyIds"
      operator  = "EXACTLY_MATCHES"
      values    = [newrelic_alert_policy.alert_policy.id]
    }
  }

  destination {
    channel_id = newrelic_notification_channel.prod_pd_notification[count.index].id
  }
}

resource "newrelic_workload" "workload" {
  name              = lower(join("-", [local.service_name, "workload"]))
  description       = "Component Workload for ${local.workload}-${local.component}"
  account_id        = data.newrelic_account.account_id.id
  scope_account_ids = [data.newrelic_account.account_id.id]
  entity_search_query {
    query = "`tags.tags.Environment` = '${var.environment}' AND `tags.tags.coxauto:ci-id` = '${var.coxauto_ci_id}'"
  }

  status_config_automatic {
    enabled = true
    remaining_entities_rule {
      remaining_entities_rule_rollup {
        strategy        = "WORST_STATUS_WINS"
        threshold_type  = "FIXED"
        threshold_value = 1
        group_by        = "ENTITY_TYPE"
      }
    }
  }
}

resource "newrelic_entity_tags" "workload_tag" {
  guid = newrelic_workload.workload.guid

  dynamic "tag" {
    for_each = merge(
      { "coxauto:ci-id" = var.coxauto_ci_id },
      { "team" = local.team_name },
      { "environment" = var.environment }
    )
    content {
      key    = tag.key
      values = [tag.value]
    }
  }
}

resource "newrelic_nrql_alert_condition" "nrql" {
  count                          = length(var.nrql_query_alerts)
  account_id                     = data.newrelic_account.account_id.id
  policy_id                      = newrelic_alert_policy.alert_policy.id
  type                           = var.nrql_query_alerts[count.index].type
  name                           = lower(var.nrql_query_alerts[count.index].name)
  description                    = var.nrql_query_alerts[count.index].priority_level != "" ? join("", [var.nrql_query_alerts[count.index].description, " (", "Priority:", var.nrql_query_alerts[count.index].priority_level, ")"]) : var.nrql_query_alerts[count.index].description
  runbook_url                    = var.nrql_query_alerts[count.index].runbook_url
  enabled                        = true
  violation_time_limit_seconds   = var.nrql_query_alerts[count.index].violation_time_limit_seconds
  fill_option                    = var.nrql_query_alerts[count.index].fill_option
  fill_value                     = var.nrql_query_alerts[count.index].fill_value
  aggregation_window             = var.nrql_query_alerts[count.index].aggregation_window
  aggregation_method             = var.nrql_query_alerts[count.index].aggregation_method
  aggregation_timer              = var.nrql_query_alerts[count.index].aggregation_method == "event_flow" ? var.nrql_query_alerts[count.index].aggregation_timer : null
  aggregation_delay              = var.nrql_query_alerts[count.index].aggregation_method == "event_flow" || var.nrql_query_alerts[count.index].aggregation_method == "cadence" ? var.nrql_query_alerts[count.index].aggregation_delay : null
  expiration_duration            = var.nrql_query_alerts[count.index].expiration_duration
  open_violation_on_expiration   = false
  close_violations_on_expiration = false
  slide_by                       = var.nrql_query_alerts[count.index].slide_by
  baseline_direction             = var.nrql_query_alerts[count.index].baseline_direction

  nrql {
    query = var.nrql_query_alerts[count.index].nrql_query
  }

  critical {
    operator              = var.nrql_query_alerts[count.index].critical_operator
    threshold             = var.nrql_query_alerts[count.index].critical_threshold
    threshold_duration    = var.nrql_query_alerts[count.index].critical_threshold_duration
    threshold_occurrences = var.nrql_query_alerts[count.index].critical_threshold_occurrences
  }

  dynamic "warning" {
    for_each = alltrue([
      var.nrql_query_alerts[count.index].warning_operator != null,
      var.nrql_query_alerts[count.index].warning_threshold != null,
      var.nrql_query_alerts[count.index].warning_threshold_duration != null
    ]) ? [{}] : []
    content {
      operator              = var.nrql_query_alerts[count.index].warning_operator
      threshold             = var.nrql_query_alerts[count.index].warning_threshold
      threshold_duration    = var.nrql_query_alerts[count.index].warning_threshold_duration
      threshold_occurrences = var.nrql_query_alerts[count.index].warning_threshold_occurrences
    }
  }
}

resource "newrelic_entity_tags" "nrql_alert_tag" {
  count = length(var.nrql_query_alerts)
  guid  = newrelic_nrql_alert_condition.nrql[count.index].entity_guid

  dynamic "tag" {
    for_each = merge(
      { "coxauto:ci-id" = var.coxauto_ci_id },
      { "environment" = var.environment },
      tomap(var.nrql_query_alerts[count.index].tags)
    )
    content {
      key    = tag.key
      values = [tag.value]
    }
  }
}

#-----------------------------------------------------------
# Synthetics Monitoring
#-----------------------------------------------------------
resource "newrelic_synthetics_secure_credential" "secure_credential" {
  count       = length(var.newrelic_synthetics_secure_credentials)
  key         = lower(var.newrelic_synthetics_secure_credentials[count.index].key)
  value       = var.newrelic_synthetics_secure_credentials[count.index].value
  description = var.newrelic_synthetics_secure_credentials[count.index].description
}

# No Support for Tagging Secure Credentials yet
#resource "newrelic_entity_tags" "secure_credential_tag" {
#  count = length(var.newrelic_synthetics_secure_credentials)
#  guid  = newrelic_synthetics_secure_credential.secure_credential[count.index].entity_guid

#  tag {
#    key = "coxauto:ciid"
#    values = [var.coxauto_ci_id]
#  }
#}

resource "newrelic_synthetics_script_monitor" "script_monitor" {
  count            = length(var.newrelic_synthetic_script_monitor)
  status           = "ENABLED"
  name             = var.newrelic_synthetic_script_monitor[count.index].name
  type             = var.newrelic_synthetic_script_monitor[count.index].type
  locations_public = var.newrelic_synthetic_script_monitor[count.index].location_public

  dynamic "location_private" {
    for_each = var.newrelic_synthetic_script_monitor[count.index].location_private_guid
    content {
      guid = location_private.value == null ? null : location_private.value
    }
  }

  period = var.newrelic_synthetic_script_monitor[count.index].period

  script = templatefile(var.newrelic_synthetic_script_monitor[count.index].script_file, var.newrelic_synthetic_script_monitor[count.index].script_variables)

  script_language      = var.newrelic_synthetic_script_monitor[count.index].script_language
  runtime_type         = var.newrelic_synthetic_script_monitor[count.index].runtime_type
  runtime_type_version = var.newrelic_synthetic_script_monitor[count.index].runtime_type_version

  dynamic "tag" {
    for_each = merge(
      { "coxauto:ci-id" = var.coxauto_ci_id },
      { "environment" = var.environment },
      tomap(var.newrelic_synthetic_script_monitor[count.index].tags)
    )
    content {
      key    = tag.key
      values = [tag.value]
    }
  }
}

resource "newrelic_synthetics_step_monitor" "step_monitor" {
  count            = length(var.newrelic_synthetic_step_monitor)
  name             = var.newrelic_synthetic_step_monitor[count.index].name
  locations_public = var.newrelic_synthetic_step_monitor[count.index].location_public
  period           = var.newrelic_synthetic_step_monitor[count.index].period
  status           = "ENABLED"

  dynamic "location_private" {
    for_each = var.newrelic_synthetic_step_monitor[count.index].location_private_guid
    content {
      guid = location_private.value == null ? null : location_private.value
    }
  }

  dynamic "steps" {
    for_each = var.newrelic_synthetic_step_monitor[count.index].steps
    content {
      ordinal = steps.value.ordinal
      type    = steps.value.type
      values  = steps.value.values
    }
  }

  dynamic "tag" {
    for_each = merge(
      { "coxauto:ci-id" = var.coxauto_ci_id },
      { "environment" = var.environment },
      tomap(var.newrelic_synthetic_step_monitor[count.index].tags)
    )
    content {
      key    = tag.key
      values = [tag.value]
    }
  }
}

#-------------------------------------------------
# New Relic Muting Rules
#-------------------------------------------------
resource "newrelic_alert_muting_rule" "alert_muting" {
  name    = lower(join("-", [local.service_name, "muting-rule"]))
  enabled = false
  condition {
    conditions {
      attribute = "policyId"
      operator  = "EQUALS"
      values    = [newrelic_alert_policy.alert_policy.id]
    }
    conditions {
      attribute = "targetId"
      operator  = "EQUALS"
      values    = ["Muted"]
    }
    operator = "AND"
  }
}

#-------------------------------------------------------------------------------
# New Relic SLO/SLI Configuration
#-------------------------------------------------------------------------------
resource "newrelic_service_level" "service_level" {
  count       = length(var.newrelic_service_levels)
  guid        = newrelic_workload.workload.guid
  name        = var.newrelic_service_levels[count.index].name
  description = var.newrelic_service_levels[count.index].description

  events {
    account_id = data.newrelic_account.account_id.id
    valid_events {
      from  = var.newrelic_service_levels[count.index].valid_events_from
      where = var.newrelic_service_levels[count.index].valid_events_where
    }
    bad_events {
      from  = var.newrelic_service_levels[count.index].bad_events_from
      where = var.newrelic_service_levels[count.index].bad_events_where
    }
  }

  objective {
    target = var.newrelic_service_levels[count.index].objective_target
    time_window {
      rolling {
        count = var.newrelic_service_levels[count.index].time_window_count
        unit  = var.newrelic_service_levels[count.index].time_window_unit
      }
    }
  }
}

resource "newrelic_entity_tags" "service_level_tags" {
  count = length(var.newrelic_service_levels)
  guid  = newrelic_service_level.service_level[count.index].sli_guid

  dynamic "tag" {
    for_each = merge(
      { "coxauto:ci-id" = var.coxauto_ci_id },
      { "environment" = var.environment }
    )
    content {
      key    = tag.key
      values = [tag.value]
    }
  }
}