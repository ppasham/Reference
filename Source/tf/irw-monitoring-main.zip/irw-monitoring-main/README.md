# CMS Monitoring Terraform Module

This moudule contains a fully-configured monitoring module that leverages PagerDuty, New Relic and Splunk.

This module also ties directly into the [CAI Incident Response Workflow](https://pages.ghe.coxautoinc.com/engineering/handbook/docs/incident-management/incident-response-workflow/)

# Using the Module
* This moudle only needs a few variables to setup the base for IRW Alerting.
  * Variables to create IRW flow without any Alerts
    * CoxAuto CI:ID
    * Environment
    * Sled API Key
    * Slack API Key
  * Optional Variables
    * NRQL Alerts with Tags (CI:ID tagged by default plus any optional tags supplied in the object map)
    * SLO Metrics
    * Synthetics (Step and Script) and Synthetics Credentials
  
## Setup with IRW
Everything will be setup based on guidelines from IRW:
 * One Pagerduty service per CI:ID
 * One New Relic Alert Policy per CI:ID
 * Event Orchestration Rules to route priority alerts
 * Pagerduty Workflows
 * Production alerts go to Slack from Pagerduty, Non-Prod alerts go to Slack from New Relic
 * Dynamic Teams Bridge Per Pagerduty Service with Service Name and Incident Number
 * New Relic Workflows and Notifications
 * New Relic Muting rules to be used to prevent incidents during outage windows

## Validation Inside the Module
Most Variables are Validated to provide feedback to the user to keep naming standard across the accounts
 * Most names can only have letters, numbers and -
 * CI:ID is required
 * Only allow P1-P5 for Priority

## SLED API
This Module leverages the SLED API for the naming of Services and Dependancies
  * Ex. Pagerduty Service = *CAI Tier 2 Team*-*Workload Name*-*Component Name*
  * Ex. PagerDuty Escaltion Policy Name = *CAI Tier 2 Team*-*CAI Team Name*-Escalation-Policy

## Low and High Priority
Based on Prioirty sent from New Relic and Splunk the event Orchestration will route the incident to the correct locations and configurations
* New Relic Setup in NRQL Alert by using priority_level variable:
  * ```tf
    priority_level                 = optional(string, "")

     validation {
      condition     = alltrue([for o in var.nrql_query_alerts : can(regex("P1|P2|P3|P4|P5|^$", o.priority_level))])
      error_message = "For New Relic Alerts the Priority Level Variable must be blank, P1, P2, P3, P4, P5."
    }
    ```
* Low Priority
  * Alerts are sent to Pagerduty and Pagerduty will alert Team based channels with no on-call page to the team
* Priority P4-P1 or Blank
  * Alerts are sent to Pagerduty and Pagerduty will page the on-call team and send notification to BU based Slack channel

## PagerDuty Notifications
This module will forward all tags from the NRQL as details in the Incident Notification
``` tf
property {
      key = "summary"
      value = "{{#each accumulations.conditionName}}{{this}}{{#unless @last}}, {{/unless}}{{/each}}{{#each (json annotations.wildcard)}}{{this}}{{/each}}"
    }
  
    property {
    key   = "customDetails"
    value = <<-EOT
            {
            "Description":{{ json accumulations.conditionDescription }},
            "Runbook":"{{#each accumulations.runbookUrl}}{{this}}{{#unless @last}}, {{/unless}}{{/each}}"
            "Query":{{ json accumulations.nrqlQuery }},
            "Total Incidents":{{json totalIncidents}},
            "Details": {
                {{#each accumulations.rawTag}}"{{escape @key}}": {{#if this.[0]}}{{json this.[0]}}{{else}}"empty"{{/if}}{{#unless @last}},{{/unless}}{{/each}}
              }
            }
        EOT
    }
```

## Terraform Providers

* New Relic Provider
```tf
  provider "newrelic" {
    api_key = ""
  }
```
* PagerDuty Provider
  * **user_token** This token provides access to the PagerDuty Slack connection automation. 
    * In the web app, navigate to User Icon -> My Profile -> User Settings.
    * In the section API Access, click Create API User Token.
    * Enter a Description to help you identify the key later.
    * Click Create Key.
    * Then Token will need approved to create Slack Connection
    * In the web app, navigate to Integrations at the top -> Authorize Integration
    * Use SSO logon -> coxauto as subdomain
```tf
  provider "pagerduty" {
    token      = var.pagerduty_token
    user_token = var.user_token
  }
```

## List Objects
This module leverages list objects to create most resources. These list objects can be used multiple times to create a number of resources:

* ```tf
   variable "newrelic_synthetic_script_monitor_public" {
    type = list(object({
      name                                    = string
      type                                    = optional(string, "SCRIPT_API")
      location_public                         = optional(list(string), ["US_EAST_1","US_WEST_2"])
      period                                  = string
      script_language                         = optional(string, "")
      runtime_type                            = optional(string, "")
      runtime_type_version                    = optional(string, "")
      script_file                             = string
      script_variables                        = optional(map(string), {})
   }))
    description = "New Relic Synthetic that should be created"
    default     = []

    validation {
      condition     = alltrue([for o in var.newrelic_synthetic_script_monitor_public : can(regex("^[-0-9A-Za-z]+$", o.name))])
      error_message = "For New Relic Synthetics the name variable can only use the following: -, a-z, A-Z and 0-9."
    }
  }
   ```
 * Example of useage of list obejcts in deploy.tf file:
   ```tf
   locals{
    newrelic_synthetic_script_monitor_public = [
    {
      name                           = "ncdev-testing-dbarchive-ssis-check"
      period                         = "EVERY_5_MINUTES"
      script_file                    = "synthetic_get.js.template"
      script_variables               = {
                                        token_url = "${var.okta_issuer_uri}/v1/token", 
                                        client_id_credential = upper(local.newrelic_synthetics_secure_credentials[0].key),
                                        client_secret_credential = upper(local.newrelic_synthetics_secure_credentials[1].key),
                                        health_url = local.ssis_url,
                                        correlation_id = var.correlation_id
                                        }
      }
     ]
    }
   ```

## NRQL Alerting
Examples of NRQL Alerts:
```tf
nrql_query_alerts = [
    {
      {
      name                           = "ncdev-testing-db-archive-dlq-alert"
      description                    = "dlq alerts"
      nrql_query                     = "SELECT sum(`aws.sqs.NumberOfMessagesReceived`) FROM Metric WHERE ((`metricName` = 'aws.sqs.NumberOfMessagesReceived') AND (`aws.sqs.QueueName` LIKE '%dlq%') AND (`tags.coxauto:ci-id` = '${var.coxauto_ci_id}') AND (`tags.Environment` = '${var.environment}')) FACET entity.name"
      critical_operator              = "above"
      critical_threshold             = "500"
      critical_threshold_duration    = "600"
      critical_threshold_occurrences = "all"
      tags                           = {dataCenter = "Switch", deployment = "http://cmsbldjenk02.cm.fdielt.com:8080/", splunkLogs = "https://coxauto.splunkcloud.com/en-US/app/dealertrack-cms/tms_500_error_dashboard"}
    }
```

## Priority Levels

| P-Level | PD Urgency | EOC Notified | Official Description                                                                                                                                                                                                                                          |
|---------|------------|--------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| p1      | high       | YES          | Issue causing client or financial impact, where team members or clients have no access or are experiencing severely degraded service. Critical issue that warrants broad business and executive communication.                                                |
| p2      | high       | YES          | Issue causing client or financial impact, where team members or clients ability to utilize a service is impacted. Degradation issue that warrants some business and executive communication.                                                                  |
| p3      | high       | YES          | Issue that needs immediate attention from the system or service owners. A loss in redundancy or capacity that places the stability or availability of a critical service at risk. Limited business impact that warrants business and executive communication. |
| p4      | high       | NO           | Minor issues requiring action, but not affecting client or team member’s ability to utilize services.                                                                                                                                                         |
| p5      | low        | NO           | Cosmetic issues, bugs or warnings that are important to service owners but not causing immediate client or team member impact.     

<!-- BEGIN_TF_DOCS -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >= 1.6.3 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_http"></a> [http](#provider\_http) | n/a |
| <a name="provider_newrelic"></a> [newrelic](#provider\_newrelic) | n/a |
| <a name="provider_pagerduty"></a> [pagerduty](#provider\_pagerduty) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [newrelic_alert_muting_rule.alert_muting](https://registry.terraform.io/providers/newrelic/newrelic/latest/docs/resources/alert_muting_rule) | resource |
| [newrelic_alert_policy.alert_policy](https://registry.terraform.io/providers/newrelic/newrelic/latest/docs/resources/alert_policy) | resource |
| [newrelic_entity_tags.nrql_alert_tag](https://registry.terraform.io/providers/newrelic/newrelic/latest/docs/resources/entity_tags) | resource |
| [newrelic_entity_tags.service_level_tags](https://registry.terraform.io/providers/newrelic/newrelic/latest/docs/resources/entity_tags) | resource |
| [newrelic_entity_tags.workload_tag](https://registry.terraform.io/providers/newrelic/newrelic/latest/docs/resources/entity_tags) | resource |
| [newrelic_notification_channel.np_notification](https://registry.terraform.io/providers/newrelic/newrelic/latest/docs/resources/notification_channel) | resource |
| [newrelic_notification_channel.prod_pd_notification](https://registry.terraform.io/providers/newrelic/newrelic/latest/docs/resources/notification_channel) | resource |
| [newrelic_notification_destination.prod_pd_destination](https://registry.terraform.io/providers/newrelic/newrelic/latest/docs/resources/notification_destination) | resource |
| [newrelic_nrql_alert_condition.nrql](https://registry.terraform.io/providers/newrelic/newrelic/latest/docs/resources/nrql_alert_condition) | resource |
| [newrelic_service_level.service_level](https://registry.terraform.io/providers/newrelic/newrelic/latest/docs/resources/service_level) | resource |
| [newrelic_synthetics_script_monitor.script_monitor](https://registry.terraform.io/providers/newrelic/newrelic/latest/docs/resources/synthetics_script_monitor) | resource |
| [newrelic_synthetics_secure_credential.secure_credential](https://registry.terraform.io/providers/newrelic/newrelic/latest/docs/resources/synthetics_secure_credential) | resource |
| [newrelic_synthetics_step_monitor.step_monitor](https://registry.terraform.io/providers/newrelic/newrelic/latest/docs/resources/synthetics_step_monitor) | resource |
| [newrelic_workflow.np_workflow](https://registry.terraform.io/providers/newrelic/newrelic/latest/docs/resources/workflow) | resource |
| [newrelic_workflow.prod_pd_workflow](https://registry.terraform.io/providers/newrelic/newrelic/latest/docs/resources/workflow) | resource |
| [newrelic_workload.workload](https://registry.terraform.io/providers/newrelic/newrelic/latest/docs/resources/workload) | resource |
| [pagerduty_event_orchestration_service.priority_update](https://registry.terraform.io/providers/pagerduty/pagerduty/latest/docs/resources/event_orchestration_service) | resource |
| [pagerduty_incident_workflow.conference_bridge](https://registry.terraform.io/providers/pagerduty/pagerduty/latest/docs/resources/incident_workflow) | resource |
| [pagerduty_incident_workflow_trigger.high_trigger](https://registry.terraform.io/providers/pagerduty/pagerduty/latest/docs/resources/incident_workflow_trigger) | resource |
| [pagerduty_service.pd_service](https://registry.terraform.io/providers/pagerduty/pagerduty/latest/docs/resources/service) | resource |
| [pagerduty_service_dependency.service_dependency_business](https://registry.terraform.io/providers/pagerduty/pagerduty/latest/docs/resources/service_dependency) | resource |
| [pagerduty_service_integration.newrelic_integration](https://registry.terraform.io/providers/pagerduty/pagerduty/latest/docs/resources/service_integration) | resource |
| [pagerduty_service_integration.splunk_integration](https://registry.terraform.io/providers/pagerduty/pagerduty/latest/docs/resources/service_integration) | resource |
| [pagerduty_slack_connection.pagerduty_slack_connection](https://registry.terraform.io/providers/pagerduty/pagerduty/latest/docs/resources/slack_connection) | resource |
| [http_http.slack_response](https://registry.terraform.io/providers/hashicorp/http/latest/docs/data-sources/http) | data source |
| [http_http.sled_response](https://registry.terraform.io/providers/hashicorp/http/latest/docs/data-sources/http) | data source |
| [newrelic_account.account_id](https://registry.terraform.io/providers/newrelic/newrelic/latest/docs/data-sources/account) | data source |
| [newrelic_notification_destination.np_notification_destination](https://registry.terraform.io/providers/newrelic/newrelic/latest/docs/data-sources/notification_destination) | data source |
| [pagerduty_business_service.cms_service](https://registry.terraform.io/providers/pagerduty/pagerduty/latest/docs/data-sources/business_service) | data source |
| [pagerduty_priority.p1](https://registry.terraform.io/providers/pagerduty/pagerduty/latest/docs/data-sources/priority) | data source |
| [pagerduty_priority.p2](https://registry.terraform.io/providers/pagerduty/pagerduty/latest/docs/data-sources/priority) | data source |
| [pagerduty_priority.p3](https://registry.terraform.io/providers/pagerduty/pagerduty/latest/docs/data-sources/priority) | data source |
| [pagerduty_priority.p4](https://registry.terraform.io/providers/pagerduty/pagerduty/latest/docs/data-sources/priority) | data source |
| [pagerduty_priority.p5](https://registry.terraform.io/providers/pagerduty/pagerduty/latest/docs/data-sources/priority) | data source |
| [pagerduty_vendor.newrelic](https://registry.terraform.io/providers/pagerduty/pagerduty/latest/docs/data-sources/vendor) | data source |
| [pagerduty_vendor.splunk](https://registry.terraform.io/providers/pagerduty/pagerduty/latest/docs/data-sources/vendor) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_coxauto_ci_id"></a> [coxauto\_ci\_id](#input\_coxauto\_ci\_id) | The environment for the component | `string` | `""` | no |
| <a name="input_environment"></a> [environment](#input\_environment) | The environment for the component | `string` | `""` | no |
| <a name="input_newrelic_service_levels"></a> [newrelic\_service\_levels](#input\_newrelic\_service\_levels) | Optional New Relic SLO/SLI Levels to Create | <pre>list(object({<br>    name               = string<br>    description        = string<br>    valid_events_from  = string<br>    valid_events_where = string<br>    bad_events_from    = string<br>    bad_events_where   = string<br>    objective_target   = string<br>    time_window_count  = string<br>    time_window_unit   = string<br>  }))</pre> | `[]` | no |
| <a name="input_newrelic_synthetic_script_monitor"></a> [newrelic\_synthetic\_script\_monitor](#input\_newrelic\_synthetic\_script\_monitor) | New Relic Synthetic that should be created | <pre>list(object({<br>    name                  = string<br>    type                  = optional(string, "SCRIPT_API")<br>    location_public       = optional(list(string), null)<br>    location_private_guid = optional(list(string), [])<br>    period                = string<br>    script_language       = optional(string, "")<br>    runtime_type          = optional(string, "")<br>    runtime_type_version  = optional(string, "")<br>    script_file           = string<br>    script_variables      = optional(map(string), {})<br>    tags                  = optional(map(string))<br>  }))</pre> | `[]` | no |
| <a name="input_newrelic_synthetic_step_monitor"></a> [newrelic\_synthetic\_step\_monitor](#input\_newrelic\_synthetic\_step\_monitor) | New Relic Synthetic that should be created | <pre>list(object({<br>    name                  = string<br>    location_public       = optional(list(string), null)<br>    location_private_guid = optional(list(string), [])<br>    period                = string<br>    steps = list(object({<br>      ordinal = string<br>      type    = string<br>      values  = list(string)<br>    }))<br>    tags = optional(map(string))<br>  }))</pre> | `[]` | no |
| <a name="input_newrelic_synthetics_secure_credentials"></a> [newrelic\_synthetics\_secure\_credentials](#input\_newrelic\_synthetics\_secure\_credentials) | New Relic Secure Credential for Synthetics | <pre>list(object({<br>    key         = string<br>    value       = string<br>    description = string<br>  }))</pre> | `[]` | no |
| <a name="input_nrql_query_alerts"></a> [nrql\_query\_alerts](#input\_nrql\_query\_alerts) | New Relic Query Alerts | <pre>list(object({<br>    name                           = string<br>    description                    = string<br>    type                           = optional(string, "static")<br>    priority_level                 = optional(string, "")<br>    runbook_url                    = optional(string, "")<br>    violation_time_limit_seconds   = optional(string, null)<br>    fill_option                    = optional(string, "static")<br>    fill_value                     = optional(string, 1.0)<br>    aggregation_window             = optional(string, "60")<br>    aggregation_method             = optional(string, "event_flow")<br>    aggregation_delay              = optional(string, "120")<br>    aggregation_timer              = optional(string, "")<br>    expiration_duration            = optional(string, null)<br>    nrql_query                     = string<br>    critical_operator              = string<br>    critical_threshold             = string<br>    critical_threshold_duration    = string<br>    critical_threshold_occurrences = string<br>    warning_operator               = optional(string)<br>    warning_threshold              = optional(string)<br>    warning_threshold_duration     = optional(string)<br>    warning_threshold_occurrences  = optional(string)<br>    slide_by                       = optional(string, null)<br>    baseline_direction             = optional(string, null)<br>    tags                           = optional(map(string))<br>  }))</pre> | `[]` | no |
| <a name="input_slack_api_key"></a> [slack\_api\_key](#input\_slack\_api\_key) | Slack API token to find Channel ID | `string` | `""` | no |
| <a name="input_sled_api_key"></a> [sled\_api\_key](#input\_sled\_api\_key) | The API key used by the HTTP Datasource to query SLED | `string` | `""` | no |

## Outputs

No outputs.
<!-- END_TF_DOCS -->
