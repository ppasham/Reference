# Requirements
terraform {
  required_version = ">= 1.3.0"
  required_providers {
    newrelic = {
      source = "newrelic/newrelic"
    }
    pagerduty = {
      source = "pagerduty/pagerduty"
    }
  }
}

provider "pagerduty" {
}

# Configure the New Relic provider
provider "newrelic" {
}

variable "environment" {
  default     = "dev"
  description = "The environment for the service (ex. dev, qa, pp, prod)"
}

variable "coxauto_ci_id" {
  default     = ""
  description = "The Cox Auto Catalog ID"
}

variable "sled_api_key" {
  default = ""
}

variable "slack_api_key" {
  default = ""
}

locals {
  nrql_query_alerts = [
    {
      name                           = "ncdev-testing-lambda-errors"
      description                    = "lambda error alerts"
      nrql_query                     = "SELECT max(`aws.lambda.Errors.byFunction`) FROM Metric WHERE ((`metricName` = 'aws.lambda.Errors.byFunction') AND (`tags.coxauto:ci-id` = '${var.coxauto_ci_id}') AND (`tags.Environment` = '${var.environment}')) FACET entity.name"
      critical_operator              = "above"
      critical_threshold             = "500"
      critical_threshold_duration    = "600"
      critical_threshold_occurrences = "all"
      priority_level                 = "P5"
      runbook_url                    = "test"
      tags                           = { dataCenter = "Switch", deployment = "http://cmsbldjenk02.cm.fdielt.com:8080/", splunkLogs = "https://coxauto.splunkcloud.com/en-US/app/dealertrack-cms/tms_500_error_dashboard" }
    }
  ]
}

module "monitoring_example" {
  source            = "git@ghe.coxautoinc.com:cms-terraform/irw-monitoring.git"
  environment       = var.environment
  coxauto_ci_id     = var.coxauto_ci_id
  nrql_query_alerts = local.nrql_query_alerts
  sled_api_key      = var.sled_api_key
  slack_api_key     = var.slack_api_key
}