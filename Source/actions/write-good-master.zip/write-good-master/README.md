# write-good docker action

This action lints Markdown files specified in the action in `INPUT_CHANGEDFILES` using [`write-good`](https://github.com/btford/write-good), prints the output and makes a pr comment with suggestions.

## Inputs

### `INPUT_CHANGEDFILES`

Designates files to examine with `write-good`. The default is undefined and requires an input. If this functionality is undesired use https://github.com/tomwhross/write-good-action

## Outputs

### `result`

The output from `write-good`.

## Note

Use with [`add-pr-comment`](https://github.com/marketplace/actions/add-pr-comment) to post results as comments to PR

## Example usage
```yml
name: 'Grammar Action'
on:
  pull_request:
    branches:
      - master
jobs:
  changedfiles:
    runs-on: [self-hosted, linux]
    # Map a step output to a job output
    outputs:
      all: ${{ steps.changes.outputs.all}}
    steps:
        # Make sure we have some code to diff.
      - name: Checkout repository
        uses: actions/checkout@v2
      - name: Get changed files
        id: changes
        # Set outputs using the command.
        run: |
          echo "::set-output name=all::$(git diff --name-only --diff-filter=ACMRT ${{ github.event.pull_request.base.sha }} ${{ github.sha }} | grep .md | xargs)"
  write_good_job:
    runs-on: [self-hosted, linux]
    name: A job to lint Markdown files
    needs: changedfiles
    steps:
    - name: echo changed files
      run: echo ${{needs.changedfiles.outputs.all}}
    - uses: actions/checkout@v2
    - name: write-good action step
      id: write-good
      uses: cms-actions/write-good@v1.6.1
      with:
        changedfiles: ${{needs.changedfiles.outputs.all}}
    # Use the output from the `write-good` step
    - name: Get the write-good output
      run: echo "${{ steps.write-good.outputs.result }}"
    - name: Post comment
      uses: mshick/add-pr-comment@v1
      if: ${{ steps.write-good.outputs.result }}
      with:
        message: |
          <details>
            <summary>Here are some friendly prose warnings from <a href="https://github.com/btford/write-good/">write-good</a>:</summary>

            ${{ steps.write-good.outputs.result }}
          </details>
        repo-token: ${{ secrets.GITHUB_TOKEN }}
        repo-token-user-login: 'github-actions[bot]' # The user.login for temporary GitHub tokens
        allow-repeats: false # This is the default
```
