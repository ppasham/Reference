# file-exists

[![Health Check](https://ghe.coxautoinc.com/cms-actions/file-exists/actions/workflows/test.yaml/badge.svg)](https://ghe.coxautoinc.com/cms-actions/file-exists/actions/workflows/test.yaml)

This action checks if a file or directory exists at the given path.

- [file-exists](#file-exists)
  - [Inputs](#inputs)
    - [`files`](#files)
    - [`fail-on-missing`](#fail-on-missing)
  - [Outputs](#outputs)
    - [`files-exist`](#files-exist)
  - [Usage](#usage)

## Inputs

### `files`

<table border="0">
  <tr>
    <td align="right" style="vertical-align: top;"><b>Required</b>:</td><td>true</td>
  </tr>
  <tr>
    <td align="right" style="vertical-align: top;"><b>Default</b>:</td><td>N/A</td>
  </tr>
  <tr>
    <td align="right" style="vertical-align: top;"><b>Description</b>:</td><td>Comma separated string with paths to files and directories to check for existence.</td>
  </tr>
</table>

### `fail-on-missing`

<table border="0">
  <tr>
    <td align="right" style="vertical-align: top;"><b>Required</b>:</td><td>false</td>
  </tr>
  <tr>
    <td align="right" style="vertical-align: top;"><b>Default</b>:</td><td><code>false</code></td>
  </tr>
  <tr>
    <td align="right" style="vertical-align: top;"><b>Description</b>:</td><td>Fail if any of the files are missing.</td>
  </tr>
</table>

## Outputs

### `files-exist`

True if all files exist, false otherwise.

## Usage

```yaml
- uses: cms-actions/file-exists@v1
  with:
    files: 'README.md,package.json,test.txt'
    fail-on-missing: false
```