const core = require('@actions/core');
const github = require('@actions/github');
const fs = require('fs');

try {
  var filesExist = true;
  
  const failOnMissing = core.getInput('fail-on-missing');
  const rawFilesString = core.getInput('files');
  const files = rawFilesString.split(',');

  for (const file of files) {
    if (!fs.existsSync(file)) {
      filesExist = false;

      if (failOnMissing === 'true') {
        core.setFailed(`File ${file} does not exist`);
      }

      break;
    }
  }

  core.setOutput('files-exist', filesExist);
} catch (error) {
  core.setFailed(error.message);
}