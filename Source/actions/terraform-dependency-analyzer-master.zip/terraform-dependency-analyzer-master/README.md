# terraform-dependency-analyzer

This GitHub Action analyzes a Terraform module and outputs a JSON representation of the module's dependencies, versions, and updates required.

## Inputs

- `terraform_module_path` (required): The path to the Terraform module to analyze.
- `public_github_pat` (optional): A GitHub Personal Access token for accessing github.com.
- `enterprise_github_pat` (optional): A GitHub Personal Access token for accessing a GitHub Enterprise instance.
- `publish_notices` (optional): A boolean value indicating whether or not to publish notices to the action.

## Outputs

- `terraform_module_analysis`: A JSON representation of the Terraform module's dependencies, versions, and updates required.

## Example Usage

```yaml
name: Analyze Terraform Module

on:
  push:
    branches:
      - main

jobs:
  analyze:
    runs-on: ubuntu-latest
    steps:
      - name: Checkout Code
        uses: actions/checkout@v2

      - name: Analyze Terraform Module
        id: analyze
        uses: your-username/terraform-dependency-analyzer@v1
        with:
          terraform_module_path: ./path/to/module
          public_github_pat: ${{ secrets.GITHUB_TOKEN }}

      - name: Print Analysis
        run: echo "${{ steps.analyze.outputs.terraform_module_analysis }}"# terraform-dependency-analyzer