# Requirements
terraform {
  backend "s3" {}
  required_version = ">= 0.14"
  required_providers {
    alks = {
      source = "cox-automotive/alks"
    }
    aws = {
      version = "~> 3.0"
    }
  }
}

# Variables
variable "kms_key" {
  type        = string
  description = "KMS key for EBS and S3 bucket encryption."
  default     = "alias/cai-basic-data-kms-key"
}

variable "domain_name" {
  default     = null
  type        = string
  description = "Domain name. The Route53 zone must already be setup in the account. Defaults to: [aws account alias].com"
}

variable "create_wildcard_certs" {
  default     = true
  type        = bool
  description = "Weather to create ACM cert for the default zone"
}

variable "environment" {
  validation {
    condition     = contains(["Non-Prod", "Pre-Prod", "Prod"], var.environment)
    error_message = "Environment names must be on of: Non-Prod, Pre-Prod, Prod."
  }
  type        = string
  description = "Full Environment Designation: Non-Prod, Pre-Prod, Prod"
}

variable "build_bucket_name" {
  default     = ""
  type        = string
  description = "Name for the shared build bucket. If not provided the name is generated according to format: [account abbreviation]-bld-[environment suffix]."
}

variable "log_bucket_name" {
  default     = ""
  type        = string
  description = "Name for the shared log bucket. If not provided the name is generated according to format: [account abbreviation]-logs-[environment suffix]."
}

variable "log_path" {
  default = "bld-logs"
}

variable "account_abbr" {
  default     = ""
  type        = string
  description = "Account Abbreviation. I.E. FXS, SMX, PQ. Basically the abbreviation of what the account is supposed to be used for. Defaults to the middle part of the account alias. For example, the account abbreviation is `FXS` for 'awscmsfxsnp`, 'awscmsfxspp`, 'awscmsfxs` accounts."
}

variable "service_linked_roles" {
  type        = list(string)
  default     = ["elasticbeanstalk", "ecs", "dax", "elasticache", "ops.apigateway", "wafv2"]
  description = "Service linked roles to create. See https://docs.aws.amazon.com/IAM/latest/UserGuide/reference_aws-services-that-work-with-iam.html"
}

variable "cross_account_role" {
  default     = null
  type        = string
  description = "Role to assume when creating the resources. This is used for cross account provisioning. If you omit this variable it will default to whatever the active role you is in the current AWS session."
}

variable "newrelic_license_key" {
  description = "New Relic Licence Key for log ingestion Lambda function."
  type        = string
  default     = ""
}

variable "enable_shield_protection" {
  default     = true
  type        = bool
  description = "Enable AWS Shield Advanced protection fot the default DNS Zone"
}

variable "coxauto_ci_id" {
  default     = "CI2364478" # CMS Account Instrumentation
  description = "Component Identifier"
}

locals {
  default_newrelic_license_key = local.env_suffix == "prd" ? "ea5b534910c6d7fd685930aa59bab9488b7eeeab" : "ab45142446a2946a064a9202886591a1ed21NRAL"
  newrelic_license_key         = var.newrelic_license_key != "" ? var.newrelic_license_key : local.default_newrelic_license_key
  envs = {
    "non-prod"   = "np"
    "pre-prod"   = "pp"
    "prod"       = "prd"
    "production" = "prd"
  }
  domain_name       = var.domain_name != null ? var.domain_name : "${data.aws_iam_account_alias.current.account_alias}.com"
  env_suffix        = local.envs[lower(var.environment)]
  account_abbr      = var.account_abbr != "" ? var.account_abbr : trimsuffix(trimsuffix(trimprefix(data.aws_iam_account_alias.current.account_alias, "awscms"), "np"), "pp")
  build_bucket_name = var.build_bucket_name != "" ? var.build_bucket_name : lower("${local.account_abbr}-bld-${local.env_suffix}")
  log_bucket_name   = var.log_bucket_name != "" ? var.log_bucket_name : lower("${local.account_abbr}-logs-${local.env_suffix}")
  tags = {
    Team        = "Super Smash Crew"
    Email       = "CMS-SuperSmashCrew@coxautoinc.com"
    Environment = var.environment
    Origin      = "Account Setup"
  }
}

# Providers
provider "aws" {
  region = "us-west-2"
  assume_role {
    role_arn = var.cross_account_role
  }
  default_tags {
    tags = {
      "coxauto:ci-id" = var.coxauto_ci_id
    }
  }
  ignore_tags {
    key_prefixes = ["cai:catalog"]
  }
}

provider "aws" {
  alias  = "us-east-1"
  region = "us-east-1"
  assume_role {
    role_arn = var.cross_account_role
  }
  default_tags {
    tags = {
      "coxauto:ci-id" = var.coxauto_ci_id
    }
  }
  ignore_tags {
    key_prefixes = ["cai:catalog"]
  }
}

provider "alks" {
  url = "https://alks.coxautoinc.com/rest"
  assume_role {
    role_arn = var.cross_account_role
  }
  default_tags {
    tags = {
      "coxauto:ci-id" = var.coxauto_ci_id
    }
  }
  ignore_tags {
    key_prefixes = ["cai:catalog"]
  }
}

# Data Sources
# Route53 data source
data "aws_route53_zone" "zone" {
  name         = local.domain_name
  private_zone = "false"
}

# Pulls KMS information
data "aws_kms_key" "managed_key" {
  key_id = var.kms_key
}

data "aws_iam_account_alias" "current" {}

data "aws_region" "current" {}

data "aws_caller_identity" "current" {}

data "external" "shield_subscription" {
  program = ["aws", "shield", "get-subscription-state"]
}

#EBS volume encryption enabled with basic key
resource "aws_ebs_default_kms_key" "ebs" {
  key_arn = data.aws_kms_key.managed_key.arn
}

#EBS Encryption to be enabled by Default
resource "aws_ebs_encryption_by_default" "ebs" {
  enabled = true
}

# west2 acm creation
module "wildcard_cert" {
  count        = var.create_wildcard_certs ? 1 : 0
  source       = "git@ghe.coxautoinc.com:cms-terraform/tf-acm.git"
  dns_name     = data.aws_route53_zone.zone.name
  private_zone = "false"
  domain_name  = "*.${data.aws_route53_zone.zone.name}"
  tags         = merge({ Name = "Wildcard Cert" }, local.tags)
}

module "wildcard_cert_east" {
  count        = var.create_wildcard_certs ? 1 : 0
  source       = "git@ghe.coxautoinc.com:cms-terraform/tf-acm.git"
  dns_name     = data.aws_route53_zone.zone.name
  private_zone = "false"
  domain_name  = "*.${data.aws_route53_zone.zone.name}"
  tags         = merge({ Name = "Wildcard Cert" }, local.tags)

  providers = {
    aws = aws.us-east-1
  }
}

# S3 Buckets
module "bld_bucket" {
  source          = "git@ghe.coxautoinc.com:cms-terraform/tf-s3.git//encrypted?ref=v.0.6.1"
  kms_key         = data.aws_kms_key.managed_key.id
  bucket_name     = local.build_bucket_name
  log_bucket_name = local.log_bucket_name
  log_path        = var.log_path
  depends_on      = [module.log_bucket]
  tags            = merge({ Purpose = "Shared Build Bucket" }, local.tags)
}

module "log_bucket" {
  source              = "git@ghe.coxautoinc.com:cms-terraform/tf-s3.git//encrypted?ref=v.0.6.1"
  kms_key             = data.aws_kms_key.managed_key.id
  bucket_name         = local.log_bucket_name
  canned_acl          = "log-delivery-write"
  acceleration_status = "Suspended"
  versioning_enabled  = false
  log_bucket_name     = ""
  log_path            = ""
  tags                = merge({ Purpose = "Shared Logs Bucket" }, local.tags)
}

# Setup SES
resource "aws_ses_domain_identity" "ses" {
  domain = data.aws_route53_zone.zone.name
}

resource "aws_route53_record" "amazonses_verification_record" {
  zone_id = data.aws_route53_zone.zone.id
  name    = "_amazonses.${aws_ses_domain_identity.ses.id}"
  type    = "TXT"
  ttl     = "600"
  records = [aws_ses_domain_identity.ses.verification_token]
}

resource "aws_ses_domain_identity_verification" "verification" {
  domain     = aws_ses_domain_identity.ses.id
  depends_on = [aws_route53_record.amazonses_verification_record]
}

resource "aws_ses_domain_dkim" "dkim" {
  domain     = data.aws_route53_zone.zone.name
  depends_on = [aws_ses_domain_identity_verification.verification]
}

resource "aws_route53_record" "amazonses_dkim_record" {
  count   = 3
  zone_id = data.aws_route53_zone.zone.id
  name    = "${element(aws_ses_domain_dkim.dkim.dkim_tokens, count.index)}._domainkey"
  type    = "CNAME"
  ttl     = "600"
  records = ["${element(aws_ses_domain_dkim.dkim.dkim_tokens, count.index)}.dkim.amazonses.com"]
}

# Setup IAM
resource "aws_iam_service_linked_role" "service" {
  for_each         = toset(var.service_linked_roles)
  aws_service_name = "${each.value}.amazonaws.com"
}

module "iam_role" {
  source           = "git@ghe.coxautoinc.com:cms-terraform/tf-iam-role.git?ref=v.0.4.1"
  role_name        = "apigateway-logs-${data.aws_region.current.name}"
  service_type     = "Amazon API Gateway"
  default_policies = true
  alks_access      = false
}

module "iam_policy_attachment" {
  source     = "git@ghe.coxautoinc.com:cms-terraform/tf-iam-policy.git//iam-policy-attachment"
  role_name  = module.iam_role.iam_role_name
  policy_arn = "arn:aws:iam::aws:policy/service-role/AmazonAPIGatewayPushToCloudWatchLogs"
}

module "api_gateway_settings" {
  source              = "git@ghe.coxautoinc.com:cms-terraform/tf-api-gateway.git//api-settings"
  cloudwatch_role_arn = module.iam_role.iam_role_arn
}

data "aws_iam_policy_document" "standard_logging_policy" {
  statement {
    actions = [
      "logs:CreateLogStream",
      "logs:PutLogEvents",
    ]

    resources = ["arn:aws:logs:*:${data.aws_caller_identity.current.account_id}:log-group:*"]
    sid       = "AWSLogDeliveryWrite"

    condition {
      test     = "StringEquals"
      values   = [data.aws_caller_identity.current.account_id]
      variable = "aws:SourceAccount"
    }

    principals {
      identifiers = ["delivery.logs.amazonaws.com"]
      type        = "Service"
    }
    effect = "Allow"
  }
}

resource "aws_cloudwatch_log_resource_policy" "standard_logging_policy" {
  policy_document = data.aws_iam_policy_document.standard_logging_policy.json
  policy_name     = "AWSLogDeliveryWrite20150319"
}

resource "aws_cloudwatch_log_resource_policy" "standard_logging_policy_east" {
  policy_document = data.aws_iam_policy_document.standard_logging_policy.json
  policy_name     = "AWSLogDeliveryWrite20150319"
  provider        = aws.us-east-1
}

resource "alks_iamrole" "newrelic_aws_log_ingestion_role" {
  name                     = "newrelic-log-ingestion-role"
  type                     = "AWS Lambda"
  include_default_policies = true
}

resource "aws_iam_role_policy" "lambda_policy" {
  name = "newrelic-log-ingestion-policy"
  role = alks_iamrole.newrelic_aws_log_ingestion_role.name

  policy = <<EOF
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Action": [
                "lambda:InvokeFunction"
            ],
            "Resource": ["${module.newrelic_log_ingestion_west.function_arn}","${module.newrelic_log_ingestion_east.function_arn}"]
        },
        {
            "Effect": "Allow",
            "Action": [
                "logs:CreateLogStream",
                "logs:DescribeLogGroups",
                "logs:DescribeLogStreams",
                "logs:CreateLogGroup",
                "logs:PutLogEvents"
            ],
            "Resource": "*"
        }
    ]
}
EOF
}

module "newrelic_log_ingestion_west" {
  source             = "github.com/newrelic/aws-log-ingestion"
  nr_license_key     = local.newrelic_license_key
  function_role      = "arn:aws:iam::${data.aws_caller_identity.current.account_id}:role/acct-managed/newrelic-log-ingestion-role"
  nr_logging_enabled = true
  tags               = local.tags
  nr_tags            = ""
  build_lambda       = true
  lambda_archive     = "lambda/newrelic-log-ingestion.zip"
  depends_on         = [alks_iamrole.newrelic_aws_log_ingestion_role]
}

module "newrelic_log_ingestion_east" {
  source             = "github.com/newrelic/aws-log-ingestion"
  nr_license_key     = local.newrelic_license_key
  function_role      = "arn:aws:iam::${data.aws_caller_identity.current.account_id}:role/acct-managed/newrelic-log-ingestion-role"
  tags               = local.tags
  nr_logging_enabled = true
  build_lambda       = false
  lambda_archive     = module.newrelic_log_ingestion_west.lambda_archive
  nr_tags            = ""
  providers = {
    aws = aws.us-east-1
  }
  depends_on = [alks_iamrole.newrelic_aws_log_ingestion_role]
}

module "waf_owasp_west" {
  source     = "git@ghe.coxautoinc.com:cms-terraform/tf-waf-v2.git"
  name       = "cms-owasp-top10-waf"
  depends_on = [aws_iam_service_linked_role.service]
}

module "waf_owasp_east" {
  source = "git@ghe.coxautoinc.com:cms-terraform/tf-waf-v2.git"
  name   = "cms-owasp-top10-waf"
  providers = {
    aws = aws.us-east-1
  }
  depends_on = [aws_iam_service_linked_role.service]
}

module "shield_protection_for_default_zone" {
  count        = data.external.shield_subscription.result.SubscriptionState == "ACTIVE" && var.enable_shield_protection ? 1 : 0
  source       = "git@ghe.coxautoinc.com:cms-terraform/tf-shield-protection.git//shield_protection?ref=v.1.0.0"
  shield_name  = "${data.aws_route53_zone.zone.name}-shield"
  resource_arn = data.aws_route53_zone.zone.arn
  tags         = local.tags
}

output "info" {
  value       = <<EOT
Account resources have been setup. If you ran this manually from a console please backup the state files by running this command:

aws s3 sync . s3://${module.bld_bucket.encrypted_s3_bucket_id}/account-setup/ --exclude "*" --include "*tfstate*"
EOT
  description = "Information about follow up steps after template application."
}

output "sync-command" {
  description = "A sync command to sync the state file into the freshly created build bucket."
  value       = "aws s3 sync . s3://${module.bld_bucket.encrypted_s3_bucket_id}/account-setup/ --exclude \"*\" --include \"*tfstate*\""
}
