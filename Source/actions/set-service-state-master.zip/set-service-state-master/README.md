# Composite Action Template

To get started, click the `Use this template` button on this repository [which will create a new repository based on this template](https://github.blog/2019-06-06-generate-new-repositories-with-repository-templates/).

For info on how to build your first Composite action, see [GitHub Documentation](https://docs.github.com/en/actions/creating-actions/creating-a-composite-action).

## Documentation

<!-- action-docs-description -->
### Description

GitHub action to stop start Windows services on servers. Requires powershell to run.
<!-- action-docs-description -->
<!-- action-docs-inputs -->
### Inputs

| parameter | description | required | default |
| --- | --- | --- | --- |
| services | JSON encoded array with list of service names | `true` | [] |
| servers | JSON encoded array with list of server names | `true` | [] |
| desired-state | Desired state of services. Can be "started" or "stopped" | `true` | running |
| remoting-user | User for logging into servers. If not provided, the commands will use current user credentials. | `false` |  |
| remoting-pass | Password for logging into servers. If not provided, the commands will use current user credentials. | `false` |  |
| error-action | Common Parameter: ErrorAction. Accepted values: Break, Suspend, Ignore, Inquire, Continue, Stop, SilentlyContinue | `false` | Continue |
| timeout | Timeout in seconds | `false` | 30 |
| force-stop-on-timeout | Force stop services if timeout is reached | `false` | false |
<!-- action-docs-inputs -->
<!-- action-docs-outputs -->

<!-- action-docs-outputs -->
<!-- action-docs-runs -->
### Runs

This action is a `composite` action.
<!-- action-docs-runs -->

For more information on all inputs see [action.yml](action.yml)

## Usage

    - uses: cms-actions/set-service-state@v1
      with:
        servers: |
            [ "cmstmsqa09evt01.cm.fdielt.com", "cmstmsqa09evt02.cm.fdielt.com" ]
        services: |
            [ "CMSProcessMonitorService", "FdiEventService" ]
        desired-state: stopped
