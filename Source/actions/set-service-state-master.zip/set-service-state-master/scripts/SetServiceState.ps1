#Requires -Version 3.0

<#
    .SYNOPSIS
        Start/stop specified Windows Service(s) on remote server(s)
    .DESCRIPTION
        Start/stop specified Windows Service(s) on remote server(s).
        Script accepts a list of servers and services along with desired service state.
    .PARAMETER ServiceNames
        Comma or space separated list of Windows service names
    .PARAMETER ServerNames
        Comma or space separated list of server names
    .PARAMETER DesiredState
        The desired state of the services.  Valid values are "running" and "stopped".
    .PARAMETER Username
        Optional username to use when opening remote session to the servers. If not provided, the commands will use current user's credentials.
    .PARAMETER Password
        Optional password to use when opening remote session to the servers. If not provided, the commands will use current user's credentials.
    .PARAMETER Timeout
        The maximum amount of time (in seconds) to wait for services to reach target state (default: 60 seconds).
    .PARAMETER ForceStopOnTimeout
        If set, the script will force stop the service if it does not reach the desired state within the timeout period.
    .EXAMPLE
        SetServiceState.ps1 -ServiceNames "CMSProcessMonitorService,FdiEventService" -ServerNames "cmstmsqa09evt01.cm.fdielt.com,cmstmsqa09evt02.cm.fdielt.com"
    .NOTES
        Required parameters: ServiceNames, ServerNames, DesiredState
#>

[CmdletBinding(DefaultParameterSetName = 'ImplicitCreds')]
Param (

    [Parameter(Mandatory = $true)]
    [string[]]
    $ServiceNames,

    [Parameter(Mandatory = $true)]
    [Alias("ComputerNames")]
    [string[]]
    $ServerNames,

    [Parameter(Mandatory = $true)]
    [ValidateSet("running", "stopped")]
    [string]
    $DesiredState,

    [Parameter(Mandatory = $false)]
    [ValidateNotNullOrEmpty()]
    [string]$Username = $env:REMOTING_USERNAME,

    [Parameter(Mandatory = $false)]
    [ValidateNotNullOrEmpty()]
    [string]$Password = $env:REMOTING_PASSWORD,

    [Parameter(Mandatory = $false)]
    [int]$Timeout = 60,

    [Parameter(Mandatory = $false)]
    [switch]$ForceStopOnTimeout = $false
)



begin {
    # Validate that either both Username and Password parameters are set or none are set
    if (-not((-not$Username -and -not$Password) -or ($Username -and $Password))) {
        throw "Both Username and Password parameters must be set to use alternative credentials or both must be unset to use current user's credentials."
    }

    $ServerSessions = $null

    if ($Username) {
        $Credential = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $Username, $( ConvertTo-SecureString -String $Password -AsPlainText -Force )
        $ServerSessions = New-PSSession -ComputerName $ServerNames -Credential $Credential -Authentication Negotiate
    }
    else {
        $ServerSessions = New-PSSession -ComputerName $ServerNames
    }

    Write-Host "Servers: $ServerNames"
    Write-Host "Services: $ServiceNames"
    Write-Host "Desired State: $DesiredState"
    Write-Host "Timeout: $Timeout"
    Write-Host "Force Stop On Timeout: $ForceStopOnTimeout"
    Write-Host "Error Action: $ErrorActionPreference"
}

process {
    foreach ($Session in $ServerSessions) {
        $Server = $Session.ComputerName
        foreach ($Service in $ServiceNames) {
            Write-Host "Getting status of service $Service from server $Server"
            $ServiceObj = Invoke-Command -Session $Session -ScriptBlock { Get-Service -Name "$Using:Service" }
            if ($null -eq $ServiceObj) {
                Write-Warning "Unable to get service object for $Service on server $Server. Is the service installed?"
                continue
            }
            Write-Host "The status of service $Service on server $Server is:" $ServiceObj.Status

            if ($ServiceObj.Status -ieq $DesiredState) {
                Write-Host "The status" $ServiceObj.Status "of service $Service on server $Server is ALREADY in desired state: $DesiredState"
                continue
            }


            switch ($DesiredState) {
                "stopped" {
                    Write-Host "Stopping service $Service on server $Server"
                    Invoke-Command -Session $Session -ScriptBlock { Stop-Service -Name "$Using:Service" -NoWait }
                }

                "running" {
                    Write-Host "Starting service $Service on server $Server"
                    Invoke-Command -Session $Session -ScriptBlock { Start-Service -Name "$Using:Service" }
                }

                default {
                }
            }

            $Wait = 0
            $Interval = 2
            while ($Wait -lt $Timeout) {
                $ServiceObj = Invoke-Command -Session $Session -ScriptBlock { Get-Service -Name "$Using:Service" }
                if ($ServiceObj.Status -ieq $DesiredState) {
                    Write-Host "The status" $ServiceObj.Status "of service $Service on server $Server is NOW in desired state: $DesiredState"
                    break
                }
                $Wait += $Interval
                Start-Sleep $Interval
            }

            if ($Wait -ge $Timeout) {
                $ServiceObj = Invoke-Command -Session $Session -ScriptBlock { Get-Service -Name "$Using:Service" }

                if ((-not ($ServiceObj.Status -ieq $DesiredState)) -and $ForceStopOnTimeout) {
                    Write-Host "The status of service $Service on server $Server did not reach desired state ($DesiredState) within the timeout period: $Timeout seconds"

                    switch ($DesiredState) {
                        "stopped" {
                            Write-Host "Force stopping service $Service on server $Server"
                            Invoke-Command -Session $Session -ScriptBlock { Stop-Service -Name "$Using:Service" -Force -NoWait }
                        }

                        default {
                        }
                    }
                }
            }
        }
    }
}

end {
    foreach ($Session in $ServerSessions) {
        $Server = $Session.ComputerName
        foreach ($Service in $ServiceNames) {
            $ServiceObj = Invoke-Command -Session $Session -ScriptBlock { Get-Service -Name "$Using:Service" }
            if (-not($null -eq $ServiceObj) -and -not($ServiceObj.Status -ieq $DesiredState)) {
                $err = "The status of service $Service on server $Server does not match desired state: $DesiredState"
                Write-Host $err
                throw $err
            }
        }
    }

    Remove-PSSession $ServerSessions
}
