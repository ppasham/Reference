terraform {
  required_version = ">= 0.12.26"
}

output "hello_world" {
  value = "Hello, ${random_string.random.result}"
}

resource "random_string" "random" {
  length           = 16
  special          = true
  override_special = "/@£$"
}
