terraform {
  required_version = ">= 0.12.26"
}

output "hello_world" {
  value = "Hello, World!"
}

resource "null_resource" "env" {
  provisioner "local-exec" {
    command = "env"
  }
}

module "local" {
  source      = "git@ghe.coxautoinc.com:cms-terraform/tf-null-resources.git//local-exec?ref=v.0.1.0"
  instance_id = uuid()
  command     = "env"
  interpreter = null
}

module "local_2" {
  source      = "git::ssh://git@ghe.coxautoinc.com/cms-terraform/tf-null-resources.git//local-exec?ref=v.0.1.0"
  instance_id = uuid()
  command     = "env"
  interpreter = null
}
