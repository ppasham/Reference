# Validate Terraform Action

This action allows validating format and terraform syntax all in one pass. This action takes the list of folders to validate as inputs and runs terraform `fmt` and `validate` command on those folders.

## Documentation

<!-- action-docs-description -->
### Description

Run Terraform format and validate
<!-- action-docs-description -->
<!-- action-docs-inputs -->
### Inputs

| parameter | description | required | default |
| --- | --- | --- | --- |
| format-folders | Comma separated list of folder(s) with terraform files where to run `terraform fmt` command | `true` | . |
| validate-folders | Comma separated list of folder(s) with terraform files where to run `terraform validate` command | `true` | . |
<!-- action-docs-inputs -->
<!-- action-docs-outputs -->

<!-- action-docs-outputs -->
<!-- action-docs-runs -->
### Runs

This action is a `composite` action.
<!-- action-docs-runs -->

For more information on all inputs see [action.yml](action.yml)

## Prerequisites

* Terrform executable is installed and on the PATH. Use [hashicorp/setup-terraform](https://github.com/hashicorp/setup-terraform) if needed.
* GIT authentication is in place for any modules used if TF files. Use [cms-actions/git-ssh-key](https://ghe.coxautoinc.com/cms-actions/git-ssh-key) for SSH GIT authentication.


## Usage

    - uses: cms-actions/validate-terraform@v1

### Full Example

    name: Check Terraform Files
    on: [pull_request]
    jobs:
      check-terraform:
        runs-on: [self-hosted]
        steps:
          - uses: actions/checkout@v2
          - uses: hashicorp/setup-terraform@v2
            with:
                terraform_wrapper: false
          - uses: cms-actions/git-ssh-key@v1
            with:
                git-private-key: ${{ secrets.CMSJENKINS_PRIVATE_KEY }}
          - name: Check Terraform Files
            uses: cms-actions/validate-terraform@v1
            with:
                  format-folders: .
                  validate-folders: "example,shield_protection,web_acl_association"
