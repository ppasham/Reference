const process = require('process');
const cp = require('child_process');
const path = require('path');
const { version } = require('os');

// shows how the runner will run a javascript action with env / stdout protocol
test('Correct Muting Rule', () => {
  process.env['INPUT_API_KEY'] = process.env.NEW_RELIC_API_KEY;
  process.env['INPUT_ACCOUNT_ID'] = '2767861';
  process.env['INPUT_MUTING_RULE_ID'] = '43391244';
  process.env['INPUT_MUTING_RULE_ENABLED'] = 'false';
  const ip = path.join(__dirname, 'index.js');
  console.log(cp.execSync(`node ${ip}`, {env: process.env}, {stdio: 'inherit'}).toString());
})

test('Fail with Wrong Account ID', () => {
  process.env['INPUT_API_KEY'] = process.env.NEW_RELIC_API_KEY;
  process.env['INPUT_ACCOUNT_ID'] = '111111111';
  process.env['INPUT_MUTING_RULE_ID'] = '43391244';
  process.env['INPUT_MUTING_RULE_ENABLED'] = 'false';
  const ip = path.join(__dirname, 'index.js');
  expect(() => { cp.execSync(`node ${ip}`, {env: process.env}, {stdio: 'inherit'});}).toThrow('failed')
})

test('Fail with Wrong Muting Rule ID', () => {
  process.env['INPUT_API_KEY'] = process.env.NEW_RELIC_API_KEY;
  process.env['INPUT_ACCOUNT_ID'] = '2767861';
  process.env['INPUT_MUTING_RULE_ID'] = '111111111';
  process.env['INPUT_MUTING_RULE_ENABLED'] = 'false';
  const ip = path.join(__dirname, 'index.js');
  expect(() => { cp.execSync(`node ${ip}`, {env: process.env}, {stdio: 'inherit'});}).toThrow('failed')
})

test('Fail with Wrong Input for Muting Rule Enabled', () => {
  process.env['INPUT_API_KEY'] = process.env.NEW_RELIC_API_KEY;
  process.env['INPUT_ACCOUNT_ID'] = '2767861';
  process.env['INPUT_MUTING_RULE_ID'] = '43391244';
  process.env['INPUT_MUTING_RULE_ENABLED'] = 'foo';
  const ip = path.join(__dirname, 'index.js');
  expect(() => { cp.execSync(`node ${ip}`, {env: process.env}, {stdio: 'inherit'});}).toThrow('failed')
 })

test('Fail with Wrong Input for API Key', () => {
  process.env['INPUT_API_KEY'] = 'foo';
  process.env['INPUT_ACCOUNT_ID'] = '2767861';
  process.env['INPUT_MUTING_RULE_ID'] = '43391244';
  process.env['INPUT_MUTING_RULE_ENABLED'] = 'false';
  const ip = path.join(__dirname, 'index.js');
  expect(() => { cp.execSync(`node ${ip}`, {env: process.env}, {stdio: 'inherit'});}).toThrow('failed')
})