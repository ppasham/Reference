const axios = require('axios')
const core = require('@actions/core');

// most @actions toolkit packages have async methods
async function run() {
  try {
    const muting_rule_id = core.getInput('muting_rule_id');
    const account_id = core.getInput('account_id');
    const muting_rule_enabled = core.getInput('muting_rule_enabled')
    const headers = {
       "Content-Type": "application/json",
       "API-Key": core.getInput('api_key')
    };
    const query = ` mutation {
          alertsMutingRuleUpdate(accountId: ${account_id}, rule: {enabled: ${muting_rule_enabled}}, id: ${muting_rule_id}) {
            id
            status
            updatedAt
            schedule {
              startTime
              endTime
            }
            updatedByUser {
              name
            }
          }
        }`;
    const resp = await axios.post("https://api.newrelic.com/graphql", {query: query}, {headers: headers} )
    if (resp.data.errors == null) {
      console.log(JSON.stringify(resp.data))
    }
    else {
      core.setFailed(JSON.stringify(resp.data))
    }
  } catch (err) {
    core.setFailed(err.message);
  }
}

run();
